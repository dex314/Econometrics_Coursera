import pandas as pd
import numpy as np
import re

def clean_text(text):
    ''' Cleans the text to close match SEGMINT cleanse.
        
        params:
        text - can be dataframe, series or list
        
        returns:
        list of cleaned text
    '''
    if type(text) == pd.DataFrame or type(text) == pd.Series:
        text = text.astype(str).values
    
    results = []
    for line in text:
        ## removes phonme numbers (may have to extend)
        res = re.sub(r'((1-\d{3}-\d{3}-\d{4})|(\(\d{3}\) \d{3}-\d{4})|(\d{3}-\d{3}-\d{4}))', '', line)

        ## removes dates and times
        res = re.sub(r"((\d{2}/\d{2}/\d{2})|(\d{2}/\d{2})|(\d{2}:\d{2})|(\d{1}/\d{2}/\d{2})|(\d{1}:\d{2}))", '', res)
        
        ## removes trailing squiggle nums
        res = re.sub(r"((\d+~\d{4})|(~\d{4}))", '', res)
        
        ## removes initial digits otherwise
        res = re.sub(r"^[\d-]*\s*", '', res)
        
        ## removes * CHAR strings
        res = re.sub(r"((\w{2}\*\w\d{2}))", '', res)
        
        ## remove XXXX items
        # res = re.sub(r"((\w{6}\d{4}))", '', res)
        res = re.sub(r"((\sX+\d+)|(XX+))", '', res)

        ## additional numerals -  they dont always do this either
        # res = re.sub(r"((\s\d+))", '', res)

        ## remove state abbrvs? - they dont always do it
        # res = re.sub(r"((\s\w{2}\s))", '', res)

        ## final replacements
        res = res.replace('POS PUR','').replace('PIN PUR','')    
        
        ## remove leading spaces after replacements
        # res = re.sub(r"(\A\s+)", '', res)

        ## remove trailing digits or middling digits
        res = re.sub(r"((\s\d+$)|(\s\d+\s+$)|(\s\d+\s)|(\#\d+\s)|(\d+-\d+)|(\d+\-))", ' ', res)

        ## remove dashes ... maybe add other special charcters
        res = re.sub(r"((\*)|(\-+\s)|(\#)|(\~+))", ' ', res)

        ## they dont remove ON or AT on transfer cleans - but why do we need them?
        ##res = res.replace(' ON  AT', '')
        
        ## remove leading, trailing spaces
        res = re.sub(r"((\A\s+)|(\s+$))", '', res)
        
        ## remove middling spaces
        res = re.sub(r"((\s+))", ' ', res)

        ## amazon always becomes amazon, there appears to be others like this as well
        if 'amazon prime' in res.lower():
            res = 'AMAZON PRIME'
        if 'amzn' in res.lower():
            res = 'AMAZON.COM'
        if 'wm supercenter' in res.lower():
            res = 'WALMART SUPER CENTER'
            
        results.append(res.upper())    
        
    return results