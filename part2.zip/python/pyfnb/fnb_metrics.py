import pandas as pd
from pandas import Series, DataFrame
import numpy as np

import scipy as sp
import scipy.stats.stats as stats
import scipy.stats as sps
from scipy.stats import norm, chisquare, trim_mean
from sklearn.utils import resample
from sklearn.metrics import mean_squared_error
import statsmodels.api as sma

from matplotlib import colors, cm
import matplotlib.pyplot as plt
import seaborn as sns

from pyfnb import tweedie_dist

'''
FNB Metrics Module
2022.04.27
'''

def calc_mape(y, pred):
    '''calculates the mean avg percent error'''
    mape = 1/len(y) * np.sum(np.abs(y - pred)/np.abs(y)) * 100
    return mape


def wape(lny, pred):
    '''wape calculation
       input should be lny and associated prediction for correct Output
    '''
    num = np.fabs(np.exp(pred.values) - np.exp(lny.values)).sum()
    den = np.exp(lny.values).sum()
    return num/den


def smape(actual, pred):
    '''symmetric mean abs pct error'''
    pred = np.array(pred).flatten()
    actual = np.array(actual).flatten()
    num = np.abs(pred - actual).sum()
    den = (actual + pred).sum()
    inner = num / den
    return inner.sum() * 100


def capd(actual, pred):
    '''cumulative avg pct diff'''
    inner = (pred.mean() - actual.mean())/actual.mean()
    return inner * 100


def pseudo_r2(results, norm = sma.robust.norms.HuberT(), center=None):
    """
    calculate the pseudo r^2 for RLM
    Results is the results of a FNB model method
    """
    null_model = sma.RLM(results.model.data.orig_endog, results.model.data.orig_exog.iloc[:,0], norm = norm).fit()
    center = null_model.params["const"] if center is None else np.median(results.model.endog)
    m1 = norm.rho((results.model.endog-center)/results.scale).sum()
    m2 = norm.rho((results.resid)/results.scale).sum()
    return (m1-m2)/m1


def cc_confint(data, mean=0, alpha=0.95):
    '''backtesting confidence interval function'''
    from scipy.special import erfinv
    critVal = np.sqrt(2)*erfinv(alpha)
    lconf = mean-critVal*np.std(data)
    uconf = mean+critVal*np.std(data)
    return(lconf, uconf)


def resample_test_pitwd(y, yhat, holdout_date, ci_alpha=0.95, num_samps=1000,
                        end_prop=0.001, in_sample=True, figsize=None, savefig=None):
    '''
    RESAMPLE TEST FOR PITWD
    We bootstrap the out of sample data and then see where the prediction mean lies.
    end_prop = 0 gives expected distribution
    end_prop > 0 trims the proportion in trim_mean which causes distribution to appear more normal
        end_prop > 0 removes zeros which cannot be predicted anyway so this is reasonable
    in_sample = True uses the insample points for analysis, False is out of sample points post holdout_date
    '''
    hod_p1 = pd.to_datetime(holdout_date) + pd.DateOffset(months=1) ## hold out date + 1
    if in_sample == False:
        ys = y.loc[hod_p1:].values
        pny = pd.concat([yhat, y], axis=1).loc[hod_p1:]
        samptitle = "OutSample Data"
    else:
        ys = y.loc[:holdout_date].values
        pny = pd.concat([yhat, y], axis=1).loc[:holdout_date]
        samptitle = "InSample Data"
    pny.columns = ['pred','y']
    pos = yhat.loc[hod_p1:].values ## out of sample preds
    samps = []
    for i in range(num_samps):
        bootstraps = resample(pny, replace=True)
        ytmp = bootstraps['y'].values if end_prop == 0 else trim_mean(bootstraps['y'].values, proportiontocut=end_prop)
        samps.append(ytmp)
    sarray = np.array(samps)
    li, ui = cc_confint(sarray, np.mean(sarray), alpha=ci_alpha)
    if figsize is not None:
        fig, ax=plt.subplots(1,2,figsize=figsize)
        sns.distplot(pos, ax=ax[0], color='lightgreen');
        sns.distplot(sarray, ax=ax[0], color='pink');
        ax[0].axvline(ys.mean(), c='C0', ls='--');
        ax[0].axvline(pos.mean(), c='C1');
        ax[0].axvline(li, c='k', alpha=0.5, ls='--');
        ax[0].axvline(ui, c='k', alpha=0.5, ls='--');
        ax[0].legend(['y samp mean','pred os mean', 'lwr ci','upr ci','pred os dist','boots']);
        ax[0].set_title("Distribution of Bootstrap Samples @ {}".format(ci_alpha));
        ax[1].plot(sarray, color='pink');
        ax[1].axhline(ys.mean(), c='C0', ls='--');
        ax[1].axhline(pos.mean(), c='C1');
        ax[1].axhline(li, c='k', alpha=0.5, ls='--');
        ax[1].axhline(ui, c='k', alpha=0.5, ls='--');
        ax[1].set_title("Raw Bootstrap Samples : {}".format(samptitle));
        if savefig is not None:
            plt.tight_layout();
            plt.savefig(savefig)
    return ys, pos, li, ui, sarray


def resample_test_defaultcount(y, yhat, holdout_date, ci_alpha=0.95,
                               num_samps=1000, end_prop=0.001,
                               in_sample=True, figsize=None, savefig=None):
    '''
    RESAMPLE TEST FOR DEFAULT COUNT
    We bootstrap the out of sample data and then see where the prediction mean lies.
    end_prop = 0 gives expected distribution
    end_prop > 0 trims the proportion in trim_mean which causes distribution to appear more normal
        end_prop > 0 removes zeros which cannot be predicted anyway so this is reasonable
    in_sample = True uses the insample points for analysis, False is out of sample points post holdout_date
    '''
    hod_p1 = pd.to_datetime(holdout_date) + pd.DateOffset(months=1) ## hold out date + 1
    if in_sample == False:
        ys = y.loc[hod_p1:].values
        pny = pd.concat([yhat, y], axis=1).loc[hod_p1:]
        samptitle = "OutSample Data"
    else:
        ys = y.loc[:holdout_date].values
        pny = pd.concat([yhat, y], axis=1).loc[:holdout_date]
        samptitle = "InSample Data"
    pny.columns = ['pred','y']
    pos = yhat.loc[hod_p1:].values ## out of sample preds
    samps = []
    for i in range(num_samps):
        bootstraps = resample(pny, replace=True)
        ytmp = bootstraps['y'].values if end_prop == 0 else trim_mean(bootstraps['y'].values, proportiontocut=end_prop)
        samps.append(ytmp)
    sarray = np.array(samps)
    li, ui = cc_confint(sarray, np.mean(sarray), alpha=ci_alpha)
    if figsize is not None:
        fig, ax=plt.subplots(1,2,figsize=figsize)
        sns.distplot(pos, ax=ax[0], color='lightgreen');
        sns.distplot(sarray, ax=ax[0], color='pink');
        ax[0].axvline(ys.mean(), c='C0', ls='--');
        ax[0].axvline(pos.mean(), c='C1');
        ax[0].axvline(li, c='k', alpha=0.5, ls='--');
        ax[0].axvline(ui, c='k', alpha=0.5, ls='--');
        ax[0].legend(['y samp mean','pred os mean', 'lwr ci','upr ci','pred os dist','boots']);
        ax[0].set_title("Distribution of Bootstrap Samples @ {}".format(ci_alpha));
        ax[1].plot(sarray, color='pink');
        ax[1].axhline(ys.mean(), c='C0', ls='--');
        ax[1].axhline(pos.mean(), c='C1');
        ax[1].axhline(li, c='k', alpha=0.5, ls='--');
        ax[1].axhline(ui, c='k', alpha=0.5, ls='--');
        ax[1].set_title("Raw Bootstrap Samples : {}".format(samptitle));
        if savefig is not None:
            plt.tight_layout();
            plt.savefig(savefig)
    return ys, pos, li, ui, sarray
