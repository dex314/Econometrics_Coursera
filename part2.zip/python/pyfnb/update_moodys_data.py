from pyfnb import *
from pyfnb.moodys_data import MoodysData
moodys = MoodysData()
moodys.available_baskets

def yaml_metadata(metaframe, path):
    with open(path + '/metadata.yml', 'w') as outfile:
        yaml.dump(metaframe.meta_data, outfile, default_flow_style=False)

path = "../macroeconomic/data/{}"

for key,guid in moodys.available_baskets.items():
    print(key, guid)
    mcf = moodys.retrieve_data(guid)
    mcf.to_pickle(path.format(key))
    mcf.to_csv(path.format(key) + "/data.csv")
    yaml_metadata(mcf, path.format(key))
