import statsmodels as sm
import statsmodels.api as sma
import statsmodels.tsa as tsa
import statsmodels.graphics.tsaplots as tsaplots
from statsmodels.tsa.stattools import adfuller
import statsmodels.discrete as smd

import numpy as np
from matplotlib import colors, cm
import matplotlib.pyplot as plt
import seaborn as sns

import pandas as pd
from pandas import Series, DataFrame
import _pickle as cPickle

import scipy as sp
import scipy.stats.stats as stats
import scipy.stats as sps
from scipy.stats import norm, chisquare, trim_mean
from sklearn.utils import resample
from sklearn.metrics import mean_squared_error

from pyfnb import *
from pyfnb import tweedie_dist
from pyfnb.fnb_metrics import pseudo_r2
from pyfnb.fnb_data import lagDf

 ## TO DO:
 ## can we replace the from pyfnb imports with
## from . import whatever? since its the same package?

'''
===============================================================================
Helper Functions
'''
def results_table(regwrapper):
    params = Series(regwrapper.params)
    pvals = Series(regwrapper.pvalues)
    out = DataFrame( [params, pvals], index = ["coeff", "p-values"])
    return out

import re
def trygroup(x):
    try:
        return int(x.group())
    except:
        return 0

def maxLag(s):
    ret = map(lambda x: re.search("\d+", x), s)
    try:
        groupings = map(lambda x:trygroup(x), ret)
        maxLag = reduce(lambda x, y: max(x,y), groupings)
        return maxLag
    except:
        return 0

def add_c(x, allows_duplicates = False):
    """
    adds a constant to the dataframe consistent with sma.add_constant, but
    does not check the rank before hand.
    constant is added inplace.  This is required because of the use of
    dummy variables in the model.
    Return of this function is the original dataframe passed.
    If `allow_duplicates` is False, raises Exception if column
    is already contained in the DataFrame.
    """
    x.insert(0, "const", 1, allows_duplicates)
    return x

## code in the fnb dfast repo
def arPredict(fit,levels=True,x=None, y=None):
    """1 step ahead predictions
       incorporates ar part of the models
       fit = Autoregression model
       levels = boolean,set to true if the model was predicted differences and a level is desired.
       y = is a pandas series
    """
    if fit.model.k_constant == 0:
        x_copy = fit.model.exog if x is None  else x.copy()
    else:
        x_copy = fit.model.exog if x is None  else sma.add_constant(x.copy())
    ar = fit.model.ar
    eDf = lagDf( DataFrame(fit.resid, columns = ["resid"]), ar).fillna(0)
    yhat_ar = (fit.predict( x_copy ) + eDf[eDf.columns[-ar::]].dot( fit.model.yw_coef))
    yhat_ar = DataFrame(yhat_ar, columns = ["yhat_ar"])
    yhat_ar.index = fit.model.data.orig_exog.index if y is None else y.index
    if levels:
        if (type(y) is pd.core.frame.Series):
            return yhat_ar["yhat_ar"] + y.shift(1)
        else:
            raise Exception("Levels is true, but y either has not been specified or is not of type pandas.core.frame.Series")
    else:
        return yhat_ar["yhat_ar"]

def olsPredict(fit,levels=True,x=None,y=None):
    """1 step ahead predictions
       fit = OLS model
       levels = boolean,set to true if the model was predicted differences and a level is desired.
       y = is a pandas series
    """
    if fit.model.k_constant == 0:
        x_copy = fit.model.exog if x is None  else x.copy()
    else:
        x_copy = fit.model.exog if x is None  else sma.add_constant(x.copy())
    yhat = fit.predict( x_copy )
    yhat = DataFrame(yhat, columns = ["yhat"])
    yhat.index = fit.model.data.orig_exog.index if y is None else y.index
    if levels:
        if (type(y) is pd.core.frame.Series):
            return yhat["yhat"] + y.shift(1)
        else:
            raise Exception("Levels is true, but y either has not been specified or is not of type pandas.core.frame.Series")
    else:
        return yhat["yhat"]

def arForecast(fit, y, x, start=0, cumsum=True):
    """
    use this method for forecasting with Autoregression model.
    fit = Autoregression
    y = pandas.core.frame.Sereis
    x = extends pandas.core.frame.DataFrame
    start = integer or date.  depends on indexing of x and y
    cumsum = boolean, whether or not to convert forecast from differences to levels
    """
    if not (type(x) is pd.core.frame.DataFrame or type(x) is MetaFrame):
        raise Exception("x should be a MetaFrame of DataFrame")
    elif type(fit.model) is not fnbbase.models.Autoregression.Autoregression:
        raise Exception("fit.model is not of type fnbbase.models.Autoregression.Autoregression:".format(type(fit.model)))
    elif not (type(y) is pd.core.frame.Series):
        raise Exception("y should be a Series")
    try:
        x_copy = x.copy()
        if fit.model.k_constant == 0:
            pass
        # print "no constant"
        # print x_copy.index
        else:
            add_c(x_copy)
    except:
        raise Exception("start index {} does not match index type of x".format(start))
    try:
        start_value = y.loc[start]
    except:
        raise Exception("start index {} does not match index type of y".format(start))
        # print x_copy.inardex
    ar = fit.model.ar
    new_shape = x_copy.shape[0] - fit.resid.shape[0]
    temp_error = np.concatenate( [fit.resid.values, np.zeros((new_shape,))])
    eDf = lagDf( DataFrame(temp_error, columns = ["resid"]), ar).fillna(0)
    eDf.index = x_copy.index
    yhat_ar = (fit.predict( x_copy ) + eDf[eDf.columns[-ar::]].dot( fit.model.yw_coef))
    yhat_ar = yhat_ar[yhat_ar.index > start]
    yhat_ar = DataFrame(yhat_ar, columns = ["yhat_ar"])
    if cumsum:
        yhat_ar = yhat_ar.cumsum()
        yhat_ar = (yhat_ar + start_value)
    return yhat_ar["yhat_ar"]


def olsForecast(fit, y, x, start = 0, cumsum = True):
    """
    only use this method if the original model is estimated on 1st difference of y
    fit = Autoregression
    y = pandas.core.frame.Sereis
    x = pandas.core.frame.DataFrame
    start = integer or date.  depends on indexing of x and y
    cumsum = boolean, whether or not to convert forecast from differences to levels
    """
    if not (type(x) is pd.core.frame.DataFrame or type(x) is MetaFrame):
        raise Exception("x should be a MetaFrame of DataFrame")
    elif not (type(y) is pd.core.frame.Series):
        raise Exception("y should be a Series")
    try:
        x_copy = x.copy()
        if fit.model.k_constant == 0:
            pass
        # print "no constant"
        # print x_copy.index
        else:
            add_c(x_copy)
        x_copy = x_copy[x_copy.index > start]
    except:
        raise Exception("start index {} does not match index type of x".format(start))
    try:
        start_value = y.loc[start]
    except:
        raise Exception("start index {} does not match index type of y".format(start))
        # print x_copy.index
    yhat = fit.predict(x_copy)
    yhat = DataFrame(yhat, columns = ["yhat"], index = x_copy.index)
    if cumsum:
        yhat = yhat.cumsum()
        yhat = (yhat + start_value)
    return yhat["yhat"]


def forecast(fit, x, start = 0):
    """
    assumes x is a dataframe with valid datatime index
    the start_date should be less than or equal to the last valid
    observation date on y.  The date is used to set the start of
    y then the forecast function grows y based on the regression eqn.
    There is no check in place for this but the function WILL error out.

    start can either be a date or an int
    """
    if fit.model.d == 0:
        raise Exception("Use fit.predict to forecast")
    elif fit.model.d > 1:
        raise Exception("Not implemented for orders of difference greater than 1")
    elif not (type(fit.model) is fnbbase.models.Autoregression.Autoregression):
        raise Exception("Model {} is not fnbbase.models.Autoregression.Autoregression".format(type(fit.model)))
    elif not (type(x) is pd.core.frame.DataFrame or type(x) is MetaFrame):
        raise Exception("x should be a MetaFrame of DataFrame")

    x_copy = x[x.index > start]

    start_value = fit.model.orig_endog[start]

    if fit.model.k_constant == 0:
        pass
        # print "no constant"
        # print x_copy.index
    else:
        add_c(x_copy)
        # print x_copy.index
    yhat = fit.predict(x_copy)
    yhat = DataFrame(yhat, columns = ["yhat"], index = x_copy.index)
    yhat = yhat.cumsum() if fit.model.d else yhat
    yhat = (yhat + start_value) if fit.model.d else yhat
    return (yhat)["yhat"]




#%%============================================================================
class GLSAR_FNB(sma.GLSAR):
    """
    Wrapper for statsmodels.api.GLSAR
    Used to include some helper functions that handeled
    undifferences the predicted values.
    it is always assumed that y has one more extra observation (at the top) over xDf
    constructor takes arguments
    endog: Pandas.{DataFrame, Series}
    exog: Pandas.{DataFrame}
    rho: Int or List[Double] -> if AR specification is known, but not estimated, provide an Int for
        degree of autocorrelation.  Otherwise provide a list of AR coefficients
    missing = None (not used, but persists due to use in methods)
    addconst: Boolean -> Add a constant to the dataset using sma.add_constant. This function
        does check the rank of the argument before adding the constant.  if the matrix
        has rank < no columns, then it does nothing.  We adding a function at the bottom of this file,
        called add_c, which does not do the rank check.
    difference: Boolean -> if True then difference exog.
    dummy_descriptors: List of descriptions for any dummy variables used in the models, i.e., shifts, acquisitions, etc

    """
    pd.options.display.max_rows = 999
    pd.options.display.max_columns = 999
    pd.set_option('display.precision', 5)
    def __init__(self, endog, exog, rho=0, missing=None, addconst=True, difference = True, dummy_descriptors = None):
        self.difference = difference
        name = endog.columns[0]
        new_name = "d %s" % name if self.difference else name
        self.original_endog = endog
        self.d_endog = endog.diff().dropna() if difference else endog[1:]
        self.d_endog.columns = [new_name]
        self.exog = exog.copy() if addconst==False else sma.add_constant(exog)
        self.rho = rho
        self.hasconst = addconst
        self.missing = missing
        self.dummy_descriptors = dummy_descriptors
        try:
            super(GLSAR_FNB, self).__init__(self.d_endog, self.exog, rho=rho, missing=self.missing, hasconst=self.hasconst)
        except:
            print( " y lenghth %d is not equal to x length %d " % (self.d_endog.shape[0], self.exog.shape[0]))
            print( "check shapes of inputs, y should have 1 extra observation (on top) over x")

    def fit_FNB(self, method='pinv', cov_type="nonrobust", cov_kwds = None, use_t = None, **kwargs):
        return GLSAR_RESULTS_FNB(self.fit(method, cov_type, cov_kwds, use_t, **kwargs), self.original_endog, self.exog, self.difference)

    def fit_FNB_AR(self):
        """ iterative fit for Autoreg coefficients
        """
        #model = sm.api.GLSAR(self.endog, self.exog, self.rho, self.hasconst)
        #results = self.fit()
        #rho_old = self.rho.copy()
        results = self.iterative_fit()
        return GLSAR_RESULTS_FNB(results, self.original_endog, self.exog, self.difference)


class GLSAR_RESULTS_FNB:
    """ helper for GLSAR results
        handles predictions and forecasts
    """
    pd.options.display.max_rows = 999
    pd.options.display.max_columns = 999
    pd.set_option('display.precision', 5)

    def __init__(self, results, endog, exog, difference):
        self.results = results
        self.endog = endog
        self.exog = exog
        self.difference = difference

    def predict(self, x):
        """
        in sample prediction.
        performs 1 step ahead predictions
        """
        x_copy = x.copy()
        name = self.endog.columns[0]
        k_constant = self.results.model.k_constant
        yhat = self.results.predict(x) if k_constant == 0 else self.results.predict( add_c(x_copy))
        yhat = DataFrame(yhat, columns = ["yhat"], index = x.index)
        #yhat = yhat.cumsum().join(self.endog, how="outer")
        yhat = yhat.join(self.endog, how="outer")
        yhat["pred"] = yhat["yhat"] + yhat[name].shift(1) if self.difference else yhat["yhat"]
        yhat.drop(["yhat"], inplace=True, axis = 1)
        return yhat

    def jarque_bera(self, resid = DataFrame()):
        if resid.empty:
            resid = self.results.resid
        jbResults = list(sma.stats.stattools.jarque_bera(resid))
        jbDf = pd.DataFrame( np.array(jbResults).reshape(1, 4), columns = ['Test Statistic', 'Chi^2 two-tail prob.', 'Skew', 'Kurtosis'])
        print( "\n======================================================================")
        print( "Jarque Bera test for normality\n")
        print( jbDf)
        print( "======================================================================\n")
        return jbDf

    def hetero(self, resid = DataFrame(), exog=DataFrame()): # Breush Pagan
        #sma.stats.diagnostic.het_breushpagan
        if resid.empty:
            resid = self.results.resid
            exog = self.results.model.exog
        bp = sma.stats.diagnostic.het_breushpagan(resid, exog)
        #print "Largrange Multiplier", "p-value", "F Statistic", "p-value"
        bpDf =  DataFrame( np.array( [bp[0], bp[1], bp[2], bp[3]]))
        bpDf.index = ["Largrange Multiplier", "p-value", "F Statistic", "p-value"]
        print ("\n======================================================================")
        print ("Breusch Pagan test for Heteroskedasticity\n")
        print (bpDf.T)
        print ("======================================================================\n")
        return bpDf

    def ljung_box(self, resid = DataFrame(), arOrder = 30):
        if resid.empty:
            resid = self.results.resid
        lbResults = []
        ljungbox = sma.stats.diagnostic.acorr_ljungbox(resid, lags=arOrder)
        lbResults = [ [k, v] for k, v in zip(ljungbox[0],ljungbox[1])]
        lbDf = pd.DataFrame( lbResults , columns = ['Ljung Box Statistic', 'p-value'])
        print ("\n======================================================================")
        print ("Ljung Box Test for no Autocorrelation\n")
        print (lbDf.T)
        print ("======================================================================\n")
        return lbDf

    def breush_godfrey(self, arOrder=8):
        """
        wrapped on the statsmodels breush_godfrey which expects a regression result.
        We did not modify it to accept a DataFrame
        """
        bgResults = []
        for p in range(1,arOrder + 1):
            bg = sma.stats.diagnostic.acorr_breush_godfrey(self.results, p, True)
            bgResults.append( [p, bg[0], bg[1], bg[2], bg[3]] )
        bgDf = pd.DataFrame(bgResults, columns = ["Lag", "Largrange Multiplier", "p-value", "F Statistic", "p-value"])
            #labels = ["Largrange Multiplier", "p-value", "F Statistic", "p-value"]
            #print "Lag %d" % p
            #for (k,v) in zip(labels, bg):
            #    print "%s : %3.4f" % (k,v)
        print ("\n======================================================================")
        print ("Breusch Godfrey Lagrange Multiplier tests for residual autocorrelation\n")
        print (bgDf)
        print ("\n***************************WARNING*************************************")
        print ("\nIf you have corrected for autocorrelation - do no rely on these results")
        print ("consult the ljung_box method and plot acf method\n")
        print ("=========================================================================\n")
        return bgDf

    def plot_ACF(self, resid = DataFrame()):
        if resid.empty:
            resid = self.results.resid
        fig0, (ax0, ax0a) = plt.subplots(1,2)
        ax0.plot(resid.index, resid)
        ax0.set_title("Analysis of Residuals")
        tsaplots.plot_acf(resid, ax=ax0a, lags=30)
        ax0a.set_title("Estimated ACF")
        fig0.set_size_inches([12, 6])

    def plot_PACF(self, resid = DataFrame()):
        if resid.empty:
            resid = self.results.resid
        fig0, ax0 = plt.subplots(1,1)
        tsaplots.plot_pacf(resid, ax=ax0, lags=30)
        ax0.set_title("Estimated PACF")
        fig0.set_size_inches([6, 6])

    def forecast(self, x, start_date):
        """
        assumes x is a dataframe with valid datatime index
        the start_date should be less than or equal to the last valid
        observation date on y.  The date is used to set the start of
        y then the forecast function grows y based on the regression eqn.
        There is no check in place for this but the function WILL error out.
        """
        x_copy = x[x.index > start_date]
        start_value = self.endog.loc[start_date][0]
        if self.results.model.k_constant == 0:
            pass
            # print "no constant"
            # print x_copy.index
        else:
            add_c(x_copy)
            # print x_copy.index
        yhat = self.results.predict(x_copy)
        yhat = DataFrame(yhat, columns = ["yhat"], index = x_copy.index)
        yhat = yhat.cumsum() if self.difference else yhat
        yhat = yhat + start_value if self.difference else yhat
        return yhat


class POISSON_FNB(smd.discrete_model.Poisson):
    """
    There was 1 new default count model that was treated as a Poisson Regression.
    A wrapper was created to store some helper functions for fit tests that are
    not standard in the statsmodels implements

    dummy_descriptors:: List of descriptions for any dummy variables used in the models, i.e., shifts, acquisitions, etc
    """
    def __init__(self, endog, exog, offset=None, exposure=None, missing='none', addconst=True, dummy_descriptors=None):
        self.endog = endog.copy()
        self.exog = exog.copy() if addconst==False else sma.add_constant(exog)
        self.ofs = offset
        self.addconst = addconst
        self.expos = exposure
        self.dummy_descriptors = dummy_descriptors
        super(POISSON_FNB, self).__init__(self.endog, self.exog, self.ofs, self.expos)

    def fit_POISSON_FNB(self, start_params=None, method='bfgs', maxiter=35,
                   full_output=1, disp=1):

        results = self.fit(start_params, method, maxiter, full_output, disp)

        results.endog = self.endog
        results.exog = self.exog
        results.expos = self.expos
        results.ofs = self.ofs

        return POISSON_RESULTS_FNB(results)


class POISSON_RESULTS_FNB:
    def __init__(self, results):
        self.results = results

    def predict(self, x):
        yhat = self.results.predict(x)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x.index)
        return yhat

    def forecast(self, x, start_date):
        x0 = x[x.index > start_date]
        yhat = self.results.predict(x0)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x0.index)
        return yhat

    def poisson_stats(self):
        y = self.results.endog
        pred = self.results.predict(self.results.exog, offset=self.results.ofs, exposure=self.results.expos)
        k = self.results.params[-1]
        num = (np.asarray(y).T - np.asarray(pred))**2
        den = np.asarray(pred)
        chi2 = ( num/den ).sum()

        pval = " < 0.001" if sps.chi2.sf(chi2, int(self.results.nobs)) < 0.001 else sps.chi2.sf(chi2, int(self.results.nobs))
        tss1_pvalue = " < 0.001" if self.results.llr_pvalue < 0.001 else self.results.llr_pvalue
        print( "=============================================================\n")
        print( "Type 1 - Sum of Squares (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (self.results.llr, tss1_pvalue, self.results.df_model))
        print( "=============================================================\n")
        print( "Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (chi2, pval, self.results.df_resid))
        print( "=============================================================\n")
        print( "The Pearson Chi Square is defined as the square difference \n")
        print( "between the observed and the predicted, divided by the variance \n")
        print( "of the predicted, and summed over all observations in the model.  \n")
        tar = [ [self.results.llr, tss1_pvalue, self.results.df_model], [chi2, pval, self.results.df_resid]]
        idx = ["Type 1 - Sum of Squares", "Pearson Chi Square Test for Independence"]
        tdf = pd.DataFrame(tar, index=idx, columns=['Value','P-Value','DoF'])
        texstr = ["Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (chi2, pval, self.results.df_resid)]
        ftest = self.results.f_test(self.results.params)
        return chi2, pval, ftest, tdf


class NEGBIN_FNB(smd.discrete_model.NegativeBinomial):
    def __init__(self, endog, exog, loglike_method='nb2', offset=None, exposure=None, missing='none', addconst=True):
        self.endog = endog.copy()
        self.exog = exog.copy() if addconst==False else sma.add_constant(exog)
        self.llm = loglike_method
        self.ofs = offset
        self.addconst = addconst
        self.expos = exposure

        super(NEGBIN_FNB, self).__init__(self.endog, self.exog, self.llm, self.ofs, self.expos)

    def fit_NEGBIN_FNB(self, start_params=None, method='lbfgs', maxiter=1000,
                   full_output=1, disp=1, callback=None, cov_type='nonrobust',
                   cov_kwds=None, use_t=None):

        results = self.fit(start_params, method, maxiter, full_output, disp,
                           callback, cov_type, cov_kwds, use_t)

        results.endog = self.endog
        results.exog = self.exog
        results.expos = self.expos
        results.ofs = self.ofs

        return NEGBIN_RESULTS_FNB(results)


class NEGBIN_RESULTS_FNB:
    def __init__(self, results):
        self.results = results

    def predict(self, x):
        yhat = self.results.predict(x)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x.index)
        return yhat

    def forecast(self, x, start_date):
        x0 = x[x.index > start_date]
        yhat = self.results.predict(x0)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x0.index)
        return yhat

    def negbin_stats(self):
        y = self.results.endog
        pred = self.results.predict(self.results.exog, offset=self.results.ofs, exposure=self.results.expos)
        k = self.results.params[-1]
        num = (np.asarray(y).T - np.asarray(pred))**2
        den = np.asarray(pred) + k*np.asarray(pred)**2
        chi2 = ( num/den ).sum()

        pval = " < 0.001" if sps.chi2.sf(chi2, int(self.results.nobs)) < 0.001 else "%.4f" % sps.chi2.sf(chi2, int(self.results.nobs))
        tss1_pvalue = " < 0.001" if self.results.llr_pvalue < 0.001 else "%.4f" % self.results.llr_pvalue
        ftest = self.results.f_test(self.results.params)
        if np.isnan(self.results.llnull) == True:
            print( "=============================================================\n")
            print( "Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (chi2, pval, self.results.df_resid))
            print( "=============================================================\n")
            print( "The Pearson Chi Square is defined as the square difference \n")
            print( "between the observed and the predicted, divided by the variance \n")
            print( "of the predicted, and summed over all observations in the model.  \n")
            tar = [[chi2, pval, self.results.df_resid]]
            idx = ["Pearson Chi Square Test for Independence"]
            tdf = pd.DataFrame(tar, index=idx, columns=['Value','P-Value','DoF'])
            return chi2, pval, ftest, tdf
        else:
            print( "=============================================================\n")
            print( "Type 1 - Sum of Squares (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (self.results.llr, tss1_pvalue, self.results.df_model))
            print( "=============================================================\n")
            print( "Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (chi2, pval, self.results.df_resid))
            print( "=============================================================\n")
            print( "The Pearson Chi Square is defined as the square difference \n")
            print( "between the observed and the predicted, divided by the variance \n")
            print( "of the predicted, and summed over all observations in the model.  \n")
            tar = [ [self.results.llr, tss1_pvalue, self.results.df_model], [chi2, pval, self.results.df_resid]]
            idx = ["Type 1 - Sum of Squares", "Pearson Chi Square Test for Independence"]
            tdf = pd.DataFrame(tar, index=idx, columns=['Value','P-Value','DoF'])
            return chi2, pval, ftest, tdf


#%%============================================================================
class RLM_FNB(sma.RLM):
    """
    wrapper for sma.RLM written for the same reason as the wrapper for sma.GLSAR.
    Many helper functions included to handle forecasts level data based on predictions
    of the differences

    dummy_descriptors: List of descriptions for any dummy variables used in the models, i.e., shifts, acquisitions, etc
    """
    def __init__(self, endog, exog, M=sma.robust.norms.HuberT(), missing = 'none', addconst=True, difference = True, dummy_descriptors=None):
        """
        M: sma.robust.norms -> This is a robust norm used for RLM.  We default to HuberT
        for remaining parameters see help string for GLSAR_FNB
        """
        self.original_endog = endog
        self.d_endog = endog.diff().dropna() if difference else endog[1:]
        self.difference = difference
        self.missing = missing
        name = endog.columns[0]
        new_name = "d %s" % name if self.difference else name
        self.d_endog.columns = [new_name]
        self.exog = exog.copy() if addconst==False else sma.add_constant(exog)
        self.M = M
        self.hasconst = addconst
        self.dummy_descriptors = dummy_descriptors

        super(RLM_FNB, self).__init__(self.d_endog, self.exog, self.M, missing=self.missing, hasconst=self.hasconst)
    def fit_FNB(self, maxiter=50, tol=1e-8, scale_est="mad", init=None, cov="H1", update_scale=True, conv="dev"):
        self.maxiter = maxiter
        self.tol = tol
        self.scale_est = scale_est
        self.init = init
        self.cov = cov
        self.update_scale = update_scale
        self.conv = conv
        results = self.fit(maxiter, tol, scale_est, init, cov, update_scale, conv)
        return RLM_RESULTS_FNB(results, self.original_endog, self.exog, self.difference)


class RLM_RESULTS_FNB:
    '''WARNING: Do not use - incomplete.'''
    def __init__(self, results, endog, exog, difference):
        self.results = results
        self.endog = endog
        self.exog = exog
        self.difference = difference
    def predict(self, x):
        """
        in sample prediction.
        one step ahead predictions.
        """
        x_copy = x.copy()
        name = self.endog.columns[0]
        k_constant = self.results.model.k_constant
        yhat = self.results.predict(x) if k_constant == 0 else self.results.predict( add_c(x_copy))
        yhat = DataFrame(yhat, columns = ["yhat"], index = x.index)
        #yhat = yhat.cumsum().join(self.endog, how="outer")
        yhat = yhat.join(self.endog, how="outer")
        yhat["pred"] = yhat["yhat"] + yhat[name].shift(1) if self.difference else yhat["yhat"]
        yhat.drop(["yhat"], inplace=True, axis = 1)
        return yhat
    def forecast(self, x, start_date):
        """
        assumes x is a dataframe with valid datatime index
        the start_date should be less than or equal to the last valid
        observation date on y.  The date is used to set the start of
        y then the forecast function grows y based on the regression eqn.
        There is no check in place for this but the function WILL error out.
        """
        x_copy = x[x.index > start_date]
        start_value = self.endog.loc[start_date][0]
        if self.results.model.k_constant == 0:
            pass
            # print "no constant"
            # print x_copy.index
        else:
            add_c(x_copy)
            # print x_copy.index
        yhat = self.results.predict(x_copy)
        yhat = DataFrame(yhat, columns = ["yhat"], index = x_copy.index)
        yhat = yhat.cumsum() if self.difference else yhat
        yhat = yhat + start_value if self.difference else yhat
        return yhat


class TWEEDIE_RESULTS_FNB:
    '''WARNING: Do not use - incomplete.'''
    def __init__(self, results):
        self.results = results

    def predict(self, x):
        yhat = self.results.predict(x)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x.index)
        return yhat

    def forecast(self, x, start_date):
        x0 = x[x.index > start_date]
        yhat = self.results.predict(x0)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x0.index)
        return yhat

    def tweed_stats(self):
        '''Specific to the Tweedie Model'''
        fit = self.results ## specific to the call above
        pc2 = fit.pearson_chi2
        pc2_pval = sps.chi2.sf(pc2,int(fit.nobs))
        pc2_pstr = " < 0.001" if pc2_pval < 0.001 else pc2_pval
        print("Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)" % (pc2, pc2_pstr,
                                                                                                            fit.df_resid))
        if pc2_pval > 0.05:
            print("p-value > 0.05, we reject H0, and the model is a good fit.")
        else:
            print("p-value < 0.05, we accept H0, and the model is not a good fit.")
        print("="*82)

        dev_chk = True if fit.null_deviance > fit.deviance else False
        print("Null Deviance = {:.3f}".format(fit.null_deviance))
        if dev_chk == True:
            print("The model deviance < the null deviance suggesting it is a lift over the intercept only model.")
        else:
            print("The model deviance > the null deviance suggesting it is NOT a lift over the intercept only model.")
        print("="*82)

        out1 = pd.DataFrame(np.array([[pc2], [pc2_pstr], [fit.df_resid]]).reshape(1,3), index=['Pearson Chi2'], columns=['Value','P-Value','DoF'])
        out2 = pd.DataFrame(np.array([[fit.null_deviance], ['True' if dev_chk == 1.0 else 'False']]).reshape(1,2), index=['Lift over Null'], columns=['Null Dev','Null Dev > Model Dev'])
        return out1, out2

'''
============================================================================
Tweedie Power Optimization
Requirements - tweedie_dist from https://github.com/thequackdaddy/tweedie/tree/master/tweedie
============================================================================
'''
def loglike_p(p, res):
    '''return the loglikehood measurement based on the density'''
    return -tweedie_dist.tweedie(mu=res.mu, p=p, phi=res.scale).logpdf(res._endog).sum()

def optm(p, res):
    '''optimization call to minimize scalar'''
    opt = sp.optimize.minimize_scalar(loglike_p, tol=1e-20,
                                      bounds=(1.05, 1.95), args=(res), method='bounded')
    return opt

def tweedie_profile_sm(X, y, p=None, tolf=1e-20, figsize=None):
    ''' Convergence protocol for optimization.
        X = exogenous data (need to add constant if necessary)
        y = endogenous data
        p = power or list of powers to check within
        tolf = scipy.optimize.minimize_scaler() tolerance call
        figsize = None, if not None figsize of power optimiztion
            Note that this figure is not the traditional "arch" for LLF but an examination
            at the optimization pattern.

        scale = 'dev' in statsmodels GLM fit call as this matches closely with R / SAS

        RETURNS: a dataframe of optimized powers per p in power range

        eg
        power_ests = tweedie_profile_sm(statsmodels.add_constant(X),y)
        print(power_ests[power_ests.fval == power_ests.fval.min()]['p_new'])

        comparions with R:
                        R  |  Python
        Fish Data:  1.3969 |  1.3986
        Boston Housing Data:  1.119 | 1.12
        Random Tweedie Dist Samples:
        R Estimate = 1.51837,  Python Estimate = 1.50999
        R Estimate = 1.53571,  Python Estimate = 1.53841
        R Estimate = 1.37959,  Python Estimate = 1.32687
        R Estimate = 1.50816,  Python Estimate = 1.46346
        R Estimate = 1.41429,  Python Estimate = 1.38736
        R Estimate = 1.36224,  Python Estimate = 1.34728
        R Estimate = 1.50102,  Python Estimate = 1.49197
        R Estimate = 1.39694,  Python Estimate = 1.34821
        R Estimate = 1.41429,  Python Estimate = 1.39253
        R Estimate = 1.44286,  Python Estimate = 1.36981
    '''
    pests = []
    if p is None:
        pwrs = np.arange(1.05,1.95,0.05)
    else:
        pwrs = np.array([p])
    for p_i in pwrs:
        p_new = np.round(p_i,2)
        tol0 = 1
        while tol0 > tolf:
            p0 = p_new
            mod = sma.GLM(endog=y, exog=X, family=sma.families.Tweedie(var_power=p_new, eql=True))
            res = mod.fit(maxiter=1000, tol=1e-12, scale='dev')
            optimal = optm(p0,res)
            p_new = optimal.x
            # pests.append(p)
            tol0 = p0 - p_new
        pests.append([np.round(p_i,2), p_new, optimal.fun])

    power_df = pd.DataFrame(pests, columns=['p_init','p_new','fval']).set_index('p_init')
    if figsize is not None:
        minp = power_df[power_df.fval == power_df.fval.min()]['p_new'].values
        locp = power_df[power_df.fval == power_df.fval.min()]['p_new'].index
        fig, ax=plt.subplots(1,1,figsize=figsize)
        power_df.fval.plot(ax=ax)
        ax.axvline(locp, color='r', alpha=0.5)
        ax.legend([f"Optimal P = {minp[0] :.5f}"]);
    return power_df

'''
===============================================================================
model statistics - need replaced / moved into FNB modules - 2022.04.27
'''
def tweed_stats(fit):
    '''Specific to the Tweedie Model'''
    pc2 = fit.pearson_chi2
    pc2_pval = sps.chi2.sf(pc2,int(fit.nobs))
    pc2_pstr = " < 0.001" if pc2_pval < 0.001 else pc2_pval
    print("Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)" % (pc2, pc2_pstr,
                                                                                                        fit.df_resid))
    if pc2_pval > 0.05:
        print("p-value > 0.05, we reject H0, and the model is a good fit.")
    else:
        print("p-value < 0.05, we accept H0, and the model is not a good fit.")
    print("="*82)

    dev_chk = True if fit.null_deviance > fit.deviance else False
    print("Null Deviance = {:.3f}".format(fit.null_deviance))
    if dev_chk == True:
        print("The model deviance < the null deviance suggesting it is a lift over the intercept only model.")
    else:
        print("The model deviance > the null deviance suggesting it is NOT a lift over the intercept only model.")
    print("="*82)

    out1 = pd.DataFrame(np.array([[pc2], [pc2_pstr], [fit.df_resid]]).reshape(1,3), index=['Pearson Chi2'], columns=['Value','P-Value','DoF'])
    out2 = pd.DataFrame(np.array([[fit.null_deviance], ['True' if dev_chk == 1.0 else 'False']]).reshape(1,2), index=['Lift over Null'], columns=['Null Dev','Null Dev > Model Dev'])
    return out1, out2

def robust_stats(fit):
    '''Specific to the Robust Model'''
    y = fit.model.endog
    co_mod = sma.RLM(endog=y, exog=np.ones(len(y)))
    co_fit = co_mod.fit(maxiter=1000, tol=1e-12)
    co_pred = co_fit.predict()
    rmse = np.sqrt(mean_squared_error(y, fit.fittedvalues.values))
    co_rmse = np.sqrt(mean_squared_error(y, co_pred))
    print("="*92)
    print("Model RMSE = {:.5f},   ConstOnly RMSE = {:.5f}".format(rmse, co_rmse))
    if rmse < co_rmse:
        print("The model is a lift over the constant only model.")
    else:
        print("The model is not a lift over the constant only model.")
    print("="*92)

    print("model scale = {:.5f}".format(fit.scale))
    pr2 = pseudo_r2(fit, norm = sma.robust.norms.HuberT())
    print("pseudo r^2 = {:.5f}".format(pr2))
    print("="*92)

    out1 = pd.DataFrame(np.array([[fit.scale], [pr2]]).reshape(1,2), index=['Stats'], columns=['Scale','Pseudo R Square'])
    out2 = pd.DataFrame(np.array([[rmse], [co_rmse], ['True' if rmse < co_rmse else 'False']]).reshape(1,3), index=['Lift over Null'], columns=['RMSE','Null RMSE','Null > Model'])
    return out1, out2, co_mod



#%%============================================================================
class LGD_MODEL_FNB(object):
    '''DEPRECATED - 4.28.2022'''
    """ creates three forecasts for charge off dollars based on 3 user supplied lgds
        the assumpiton is that each lgd corresponds to base, adverve and severely adverse loss given default
        ----- arguments to constructor -----
        default_model: NEGBIN_FNB = unpicked fnb default model that was selected as champion
        default_multiplier: int = the multiplier used to gross up the default counts
        exog_base: pd.DataFrame = pandas dataframe of base fed scenarios
        exog_adv: pd.DataFrame = pandas dataframe of adverse fed scenarios
        exog_sev: pd.DataFrame =  pandas dataframe of severely adverse fed scenarios
        lgd: list(int) = this is a list of lgds corresponds to base, adverse and severely adverse (mean, +1 std, +2 std)
        """

    def __init__(self, default_model, default_multiplier, exog_base, exog_adv, exog_sev, lgd = [None, None, None]):
        """
        default_model = unpicked default model that was selected as champion
        default_multiplier = the multiplier used to gross up the default counts
        exog_base = pandas dataframe of base fed scenarios
        exog_adv = pandas dataframe of adverse fed scenarios
        exog_sev =  pandas dataframe of severely adverse fed scenarios
        lgd = this is a list of lgds corresponds to base, adverse and severely adverse (mean, +1 std, +2 std)
        """
        self.default_model = default_model
        self.default_multiplier = default_multiplier
        self.lgd = lgd # base,adverse and severe lgd percents

        try: ##For the usual FNB Models
            variables = list(default_model.results.params.index.values)
            try:
                variables.remove("alpha")
            except:
                pass
            try:
                variables.remove("const")
            except:
                pass
              ## skips the constant variable and dispersion variable
            lag = maxLag(variables)
        except: ## For the times we used statsmodels models directly
            variables = list(default_model.params.index.values)
            try:
                variables.remove("alpha")
            except:
                pass
            try:
                variables.remove("const")
            except:
                pass
              ## skips the constant variable and dispersion variable
            lag = maxLag(variables)

        xDf_base = lagDf(exog_base,lag);
        xDf_base[variables].dropna(inplace=True)
        xDf_adv = lagDf(exog_adv,lag);
        xDf_adv[variables].dropna(inplace=True)
        xDf_sev = lagDf(exog_sev,lag);
        xDf_sev[variables].dropna(inplace=True)

        self.exog_base = xDf_base[variables]
        self.exog_adv = xDf_adv[variables]
        self.exog_sev = xDf_sev[variables]

        yhat_base = default_model.predict( sma.add_constant(xDf_base[variables]))
        yhat_adv = default_model.predict( sma.add_constant(xDf_adv[variables]))
        yhat_sev = default_model.predict( sma.add_constant(xDf_sev[variables]))
        yhat_base = (yhat_base) * default_multiplier
        yhat_adv = (yhat_adv) * default_multiplier
        yhat_sev = (yhat_sev) * default_multiplier

        yhat_base.columns = ["Base"]
        yhat_base = lgd[0]*yhat_base
        self.yhat_base = yhat_base

        yhat_adv.columns = ["Adverse"]
        yhat_adv = lgd[1]*yhat_adv
        yhat_adv[yhat_adv.index <= "2016-09-01"] = np.nan
        #yhat_adv[yhat_adv.index > "2016-09-01"] = lgd[1]*yhat_adv[yhat_adv.index > "2016-09-01"]
        self.yhat_adv = yhat_adv

        yhat_sev.columns = ["Severe"]
        yhat_sev = lgd[2]*yhat_sev
        yhat_sev[yhat_sev.index <= "2016-09-01"] = np.nan
        #yhat_sev[yhat_sev.index > "2016-09-01"] = lgd[2]*yhat_sev[yhat_sev.index > "2016-09-01"]
        self.yhat_sev = yhat_sev

        self.scenarios = pd.concat( [ self.yhat_base, self.yhat_adv, self.yhat_sev], axis = 1)

'''
===============================================================================
RLM MM ESTIMATOR WRAPPER - 2022.04.27

TO DO : Build another wrapper like above for tests etc.
'''
from statsmodels.robust.norms import RobustNorm
from statsmodels.robust.robust_linear_model import RLM
import scipy.stats as stats
import statsmodels.base.model as base
import statsmodels.base.wrapper as wrap
import statsmodels.regression._tools as reg_tools
import statsmodels.regression.linear_model as lm
import statsmodels.robust.norms as norms
import statsmodels.robust.scale as scale
from statsmodels.tools.decorators import cache_readonly
from statsmodels.tools.sm_exceptions import ConvergenceWarning
from statsmodels.robust.robust_linear_model import _check_convergence
import warnings

class RLM_MM(RLM):
    '''
        RLM - MM Estimator
        Uses a generalized argument from various papers cited below with an attempt
        at recreating the MM method in R MASS under lqs.R.
        Does not converge exactly to R MASS estimates but very close.
        For comparisons to SAS, use the following where, EFF = 0.95 corresponds
        to 95% efficiency or k1 ~ 4.865 (on Boston Housing Data):
            proc robustreg data=boston_test_data method=mm(K0=1.548 EFF=0.95);
            model target = CRIM ZN INDUS CHAS NOX RM AGE DIS RAD TAX PTRATIO B LSTAT;
            run;

        Inherits from statsmodels.robust_linear_model.RLM as parent class.

        Use Case:
        import RLM_MM as rmm_ext
        test = rmm_ext.RLM_MM(exog=sma.add_constant(X), endog=y, M=mnorms.TukeyBiweight())
        results = test.fit_MM(k0=1.548, maxiter=1000, update_scale=False, scale_est='mad', conv='coefs')
        Conversion is not a destabilizer but 'coefs' are recommended.

        k0 refers to the S-Breakdown point and k1 = 4.685 is default for TukeyBiWeight.

        Important! You must call update_scale False as the S-Estimator scale is used
        for the remainder of the Tukey Weighting, this is set as the default.
        Important! This only supports TukeyBiWeight and MAD.

        cite:
        - https://ethz.ch/content/dam/ethz/special-interest/math/statistics/sfs/Education/
            Advanced%20Studies%20in%20Applied%20Statistics/course-material/robust-nonlinear/
            robfitFolien-HT2_Druck.pdf
        - M estimation, S estimation and MM estimation in robust regression. Susanti, Pratiwi, Tengah.
            International Journal of Pure and Applied Mathematics - Mar 2014
        - Comparions Between M-estimation, S-estimation, and MM Estimation Methods of Robust Regression.
            Almetwally, Almongy. IJMA Nov 2018.
        - https://github.com/cran/MASS/blob/master/R/lqs.R
    '''
    def __init__(self, endog, exog, M=None, missing='none', **kwargs):
        '''instantiate an instance of RLM for all the fun properties'''
        super().__init__(endog, exog, M=M, missing=missing, **kwargs)
        self._initialize()
        warnings.warn("Only use M=TukeyBiWeight() or results may not be stable.")

    def chi(self, u, k0):
        '''chi function for MM estimator Tukey weight'''
        u = (u/k0)**2
        return np.where(u < 1, 3*u - 3*u**2 + u**3, 1)

    def psif(self, u, k0):
        '''added for posterity but unused'''
        z = np.abs(u/k0)
        zlt = np.less_equal(1, z)
        return (1 - zlt**2)**2

    def fit_MM(self, k0=1.548, maxiter=50, tol=1e-8, scale_est='mad', init=None, cov='H1',
                update_scale=False, conv='dev', start_params=None):
            """
            Fits the model using iteratively reweighted least squares.
            The IRLS routine runs until the specified objective converges to `tol`
            or `maxiter` has been reached.
            Parameters

            k0 = Tukey CHI k0 argument (default = 1.548) (S-Breakdown)
            ----------
            Argument definitions removed for brevitys sake. For help use:
                help(statsmodels.robust_linear_model.RLM.fit)
            """
            from statsmodels.robust.norms import TukeyBiweight
            from statsmodels.robust.robust_linear_model import RLMResults, RLMResultsWrapper

            if cov.upper() not in ["H1", "H2", "H3"]:
                raise ValueError("Covariance matrix %s not understood" % cov)
            else:
                self.cov = cov.upper()
            conv = conv.lower()
            if conv not in ["weights", "coefs", "dev", "sresid"]:
                raise ValueError("Convergence argument %s not understood" % conv)
            self.scale_est = scale_est

            if start_params is None:
                wls_results = lm.WLS(self.endog, self.exog).fit()
            else:
                start_params = np.asarray(start_params, dtype=np.double).squeeze()
                if (start_params.shape[0] != self.exog.shape[1] or
                        start_params.ndim != 1):
                    raise ValueError('start_params must by a 1-d array with {0} '
                                     'values'.format(self.exog.shape[1]))
                fake_wls = reg_tools._MinimalWLS(self.endog, self.exog,
                                                 weights=np.ones_like(self.endog),
                                                 check_weights=False)
                wls_results = fake_wls.results(start_params)

            if not init:
                self.scale = self._estimate_scale(wls_results.resid)

            history = dict(params=[np.inf], scale=[])
            if conv == 'coefs':
                criterion = history['params']
            elif conv == 'dev':
                history.update(dict(deviance=[np.inf]))
                criterion = history['deviance']
            elif conv == 'sresid':
                history.update(dict(sresid=[np.inf]))
                criterion = history['sresid']
            elif conv == 'weights':
                history.update(dict(weights=[np.inf]))
                criterion = history['weights']

            # done one iteration so update
            history = self._update_history(wls_results, history, conv)
            iteration = 1
            converged = 0
            while not converged:
                if self.scale == 0.0:
                    import warnings
                    warnings.warn('Estimated scale is 0.0 indicating that the most'
                                  ' last iteration produced a perfect fit of the '
                                  'weighted data.', ConvergenceWarning)
                    break

                if iteration == 1:
                    lts = 2
                    beta = 0.5
                    pc = np.shape(self.exog)[1]
                    nl = len(self.endog)
                    quantile = np.ceil(nl/2)
                    k0 = 1.548
                    res = wls_results.resid ## from linear model WLS
                    weights0 = TukeyBiweight(c=k0).weights(res / self.scale) ## weights with k0
                    scale0 = self.scale ## already set to MAD
                    B0 = wls_results.params

                    ind = np.where(np.abs(res) <= 2.5*scale0, 1, 0)
                    s2 = np.sqrt(np.sum(res[ind]**2)/(np.sum(ind) - pc)) ## might be unnecessary
                    max_iters = 1000
                    for i in range(max_iters):
                        tmp = lm.WLS(self.endog, self.exog,
                                     weights=weights0,
                                     check_weights=True).fit(method='qr')

                        chi_res = self.chi(tmp.resid/scale0, k0)
                        s2 = scale0 * np.sqrt(np.sum(chi_res)/((nl-pc)*beta))
                        weights0 = TukeyBiweight(c=k0).weights(tmp.resid / s2)
                        Bnew = tmp.params
                        ## scale or beta convergence?
                        if np.abs(s2/scale0 - 1) < 1e-16: ## we are definitely hitting the break
                            self.s_iters = i
                            break
                        scale0 = s2
#                         if np.abs(np.sum(Bnew)/np.sum(B0) - 1) < 1e-16: ## we are definitely hitting the break
#                             self.s_iters = i
#                             break
#                         B0 = Bnew
                    self.scale = s2
                    self.weights = weights0

                else: ## calculate weights without updating scale
                    self.weights = self.M.weights(wls_results.resid / self.scale)

                wls_results = reg_tools._MinimalWLS(self.endog, self.exog,
                                                    weights=self.weights,
                                                    check_weights=True).fit()
                if update_scale is True:
                    warnings.warn('MM Estimation requires scale to be held constant post S estimation.'
                                  'Updating may cause the solution to be unstable.')
                    self.scale = self._estimate_scale(wls_results.resid)

                history = self._update_history(wls_results, history, conv)
                iteration += 1
                converged = _check_convergence(criterion, iteration, tol, maxiter)
            results = RLMResults(self, wls_results.params,
                                 self.normalized_cov_params, self.scale)

            history['iteration'] = iteration
            results.fit_history = history
            results.fit_options = dict(cov=cov.upper(), scale_est=scale_est,
                                       norm=self.M.__class__.__name__, conv=conv)
            return RLMResultsWrapper(results)

## typical statistics call we do
def rmm_stats(fit, normm=None, center=None):
    '''Specific to the Robust MM Model'''
    if normm is None:
        normm = sma.robust.norms.TukeyBiweight()
    y = fit.model.endog
    co_mod = RLM_MM(endog = y, exog = np.ones_like(y), M=normm)
    co_fit = co_mod.fit(maxiter=1000, tol=1e-12)
    co_pred = co_fit.predict()
    rmse = np.sqrt(mean_squared_error(y, fit.fittedvalues.values))
    co_rmse = np.sqrt(mean_squared_error(y, co_pred))
    print("="*92)
    print("Model RMSE = {:.5f},   ConstOnly RMSE = {:.5f}".format(rmse, co_rmse))
    if rmse < co_rmse:
        print("The model is a lift over the constant only model.")
    else:
        print("The model is not a lift over the constant only model.")
    print("="*92)

    print("model scale = {:.5f}".format(fit.scale))
    center = co_fit.params[0] if center is None else np.median(fit.model.endog)
    m1 = normm.rho((fit.model.endog-center)/fit.scale).sum()
    m2 = normm.rho((fit.resid)/fit.scale).sum()
    pr2 = (m1-m2)/m1
    print("pseudo r^2 = {:.5f}".format(pr2))
    print("="*92)

    out1 = pd.DataFrame(np.array([[fit.scale], [pr2]]).reshape(1,2), index=['Stats'], columns=['Scale','Pseudo R Square'])
    out2 = pd.DataFrame(np.array([[rmse], [co_rmse], ['True' if rmse < co_rmse else 'False']]).reshape(1,3), index=['Lift over Null'], columns=['RMSE','Null RMSE','Null > Model'])
    return out1, out2, co_mod


def leverage_analysis(ols, plot_points=True, figsize=(15,12), fontsize=12, figsave=None):
    '''pass an ols model to this function for automated leverage point analysis'''
    # ols = sma.OLS(endog = lny.diff().dropna(), exog = sma.add_constant(mcf[newVars])[1::]).fit()
    # print(ols.summary(yname="d ln balance"))
    infl = ols.get_influence() ## get the influence
    olsidx = ols.model.data.row_labels ## get the indices
    labels =[str(i)[:10] for i in olsidx] ## labels
    dffits = pd.DataFrame(infl.dffits[0], index=labels) ## calculates df-fits
    dfbetas = pd.DataFrame(infl.dfbeta, index=labels) ## calculate df-betas

    residues = ols.resid #.as_matrix() #residuals
    leviers = infl.hat_matrix_diag #leverage
    sigma_err = np.sqrt(ols.scale) #regression standard error
    res_stds = residues/(sigma_err*np.sqrt(1.0-leviers)) ## studentized resids

    seuil_levier = 2*(ols.model.df_model + 1)/ols.model.df_resid
    atyp_levier = pd.DataFrame(leviers > seuil_levier, columns = ['atyp'], index=ols.model.data.row_labels)
    seuil_stud = sps.t.ppf(0.975, df=ols.model.df_resid-ols.model.df_model-2)
    atyp_stud = np.abs(res_stds) > seuil_stud
    atyp_stud_filt = atyp_stud[atyp_stud == True].dropna()

    lev_summary = infl.summary_frame().filter(["hat_diag","student_resid","dffits","cooks_d"])

    ## concanate outliers and leverage for one plot
    atyp_sdf = pd.DataFrame(np.where(atyp_stud == True, 'outlier', ''), columns=['outliers'])
    atyp_ldf = pd.DataFrame(np.where(atyp_levier == True, 'leverage', ''), columns=['leverage'])
    atyp_comb = pd.concat([atyp_sdf, atyp_ldf], axis=1)
    atyp_comb.index = olsidx
    atyp_comb['comb'] = atyp_comb.sum(axis=1).replace('','observation').replace('outlierleverage','outlier & leverage')
    ## plot summary
    plotsumm = pd.concat([pd.DataFrame(leviers, index=olsidx,
                                       columns=['leverage']),
                          pd.DataFrame(infl.resid_studentized, index=olsidx,
                                       columns=['resid_std']),
                          atyp_comb['comb']], axis=1)

    if plot_points == True:
        fig, ax=plt.subplots(2,1,figsize=figsize)
        # sma.graphics.influence_plot(ols, ax=ax[0]);
        sns.scatterplot(x=plotsumm.leverage, y=plotsumm.resid_std,
                        hue=plotsumm['comb'].tolist(), ax=ax[0]);
                        ## the to_list() command handles an sns error
        ax[0].axvline(seuil_levier.mean(), c='k', alpha=0.5)
        ax[0].axhline(seuil_stud.mean(), c='k', alpha=0.5)
        ax[0].set_title("Influence Plot");
        ax[0].set_ylabel("Studentized Resid")
        for i in plotsumm[plotsumm.comb != 'observation'].index:
            xitem = plotsumm['leverage'].loc[i]
            yitem = plotsumm['resid_std'].loc[i]
            ax[0].annotate(str(i)[:11], # this is the text
                         (xitem,yitem), # this is the point to label
                         textcoords="offset points", # how to position the text
                         xytext=(0,10), # distance from text to points (x,y)
                         ha='center', fontsize=fontsize)
        ax[1].axhline(0,c='k', ls='-', alpha=0.5)
        dffits.plot(ax=ax[1]);
        ax[1].set_xlabel("Observations");
        ax[1].set_ylabel("DFFITS");
        ax[1].legend(['dffits']);
        ax[1].set_title("Influence Diagnostics for Residual");
        ax[1].tick_params(axis='x', rotation=45);
        plt.tight_layout();
        if figsave is not None:
            plt.savefig(figsave)

    return plotsumm, lev_summary, infl



'''
UNIT TESTS ====================================================================
'''
def fnb_poisson_test():
    '''unit test for fnb_estimators'''
    from scipy.stats import poisson
    from numpy.random import rand
    import pandas as pd
    Xr = pd.DataFrame(rand(200,6), columns=[f'x{i+1}' for i in range(6)])
    mu = 0.6
    r = pd.Series(poisson.rvs(mu, size=200))
    r.name = 'poisson_target'
    ## artifical associations
    Xr['x3'] = Xr['x3'] * np.where(r>=2,3.14,1)
    Xr['x5'] = Xr['x5'] * np.where(r<2,(r**2)/3.14,1)
    # mod = fnb_estimators.POISSON_FNB(endog=r, exog=Xr, offset=None, addconst=True)
    mod = POISSON_FNB(endog=r, exog=Xr, offset=None, addconst=True)
    fit = mod.fit_POISSON_FNB(method='bfgs',maxiter=1000)
    print(fit.results.summary())
    fit.poisson_stats();
    return True



'''
END
'''
