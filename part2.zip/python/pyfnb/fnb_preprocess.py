import pandas as pd
from pandas import Series, DataFrame
import numpy as np
from matplotlib import colors, cm
import matplotlib.pyplot as plt
import seaborn as sns

from pyfnb import *
from tqdm import tqdm

def quantile_outlier_clean(X, qupper=0.98, qlower=0.02, replacement='quantile'):
    ''' outlier clean up based on quantiles
        X : dataframe to clean
        qupper : upper quantile
        qlower : lower quantile
        replacement : default is 'rightskew' which is uses avg if med < avg
            'mean' uses mean
            'median' uses median
            'quantile' uses the set upper and lower bound arguments
        returns the cleaned dataframe and the descriptive results of the clean
    '''
    assert isinstance(X, pd.DataFrame), "X must be a DataFrame"
    Xno = X.copy()
    sigma = 2
    uq = qupper
    lq = qlower
    len_df = len(Xno)
    res = []
    for c in tqdm(X.columns):
        avg = Xno[c].mean()
        med = Xno[c].median()
        dmin = Xno[c].min()
        dmax = Xno[c].max()
        upr = X[c].quantile(q=uq)
        lwr = X[c].quantile(q=lq)

        if replacement == 'rightskew':
            repl = avg if med < avg else med
        elif replacement == 'mean':
            repl = avg
        elif replacement == 'median':
            repl = med
        elif replacement == 'quantile':
            repl = (lwr,upr)
        else:
            raise ValueError("Unknown replacement option.")

        lwr_cnt = Xno[Xno[c] < lwr][c].count()
        upr_cnt = Xno[Xno[c] > upr][c].count()

        if replacement == 'quantile':
            Xno[c] = np.where(Xno[c] < lwr, lwr, Xno[c])
            Xno[c] = np.where(Xno[c] > upr, upr, Xno[c])
        else:
            Xno[c] = np.where((Xno[c] < lwr) | (Xno[c] > upr), repl, Xno[c])

        res.append([c, dmin, lwr, avg, med, upr, dmax, lwr_cnt/len_df*100, upr_cnt/len_df*100])
    res_df = pd.DataFrame(res, columns=['feature','min','lwr','avg','med','upr','max','lwr %','upr %'])
    return Xno, res_df


    
