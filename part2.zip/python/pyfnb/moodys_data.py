import requests
from requests.auth import HTTPDigestAuth
import json
import time
import datetime
import hashlib
import hmac
import base64
import requests
import numpy  as np
import pandas as pd
from pandas import DataFrame, Series
import pickle as cPickle
import io
from pyfnb import *
from pyfnb.fnb_data import MetaFrame
# from pyfnb.fnb_data import MetaFrame ## post outside install testing
import re

class MoodysData:
    """used to pull data from Moodys Analytics.  A thread sleep was inserted to guarantee completion.
    Moodys limits 1 sec between each request and 1 GB per month."""
    def __init__(self):
        self.available_baskets = {
        'Forecast Q Fed Severe':'EDD1AEA7-E02B-435F-A13F-E920CB0F26A9',
        'Forecast Q Fed Base':'77AA818E-A08A-4FD2-9067-610D11AD5D35',
        'Forecast Q Fed Adverse':'83BC1791-70F7-483A-ADDF-D21CF4C3A67D',
        'Forecast Q-S7':'879A9967-F9D9-42CF-AA14-41DC3EE64FD8',
        'Forecast Q-S6':'035E5014-B1DD-4638-8A07-9DBE61A8D75F',
        'Forecast Q-S5':'AA879C57-70A3-4938-87FD-4C151AE0D096',
        'Forecast Q-S4':'7E3577F2-207D-46FC-850F-AD7ED7ADF10C',
        'Forecast Q-S3':'85DE799E-A7F7-4775-A7B8-A8A764DD87BB',
        'Forecast Q-S2':'B9C9D426-45AF-43BB-8591-CA617A7DBC78',
        'Forecast Q-S1':'84207662-EDCD-496A-8199-700BBF263042',
        'Forecast Q-CF':'0990207D-902C-4157-954D-42E2AD427F91',
        'Basket 2017-12-8 8:31':'82413B25-F751-49D5-A427-30D8F6117973',
        'Forecast Fed Severe':'8C59820D-E5E6-4BAA-AA4A-5D93C8297655',
        'Forecast Fed Adverse':'9CD9CFF0-C024-4055-8CB9-18211F358633',
        'Forecast Fed Baseline':'829466D8-E087-4A5D-A891-BD1FEA47C796',
        'Historical Data':'A81B6204-EE9E-4940-BDD0-09A716F67A6F',
        'Forecast M-CF':'CE0B673C-7314-41F3-97F2-89F4D6F5B1A2',
        'Forecast M-S7':'269BBBA6-3F26-4458-8ECA-252BF96753A4',
        'Forecast M-S6':'BF5E39E4-7CD6-496D-BA1B-83A9293962D8',
        'Forecast M-S5':'1A161110-B821-4B9A-BB73-CEEBE845AFE0',
        'Forecast M-S4':'6EC35842-9356-4956-923C-A42C68725497',
        'Forecast M-S3':'6791CE74-64CC-4B07-82B2-24982B2ADBC3',
        'Forecast M-S2':'31370CB3-CB77-4A60-928F-ACF0D45DFD7C',
        'Forecast M-S1':'2E29DF77-2F39-444B-BE62-B3E5C4818D88'}

    def update_baskets(self, ak=None, ek=None):
        call_type = "GET"
        if ak is None:
            # ak = "C96BF4F9-5EFE-4FD5-AF54-A0C48FA13795"
            ak = "DE965C73-A832-4C6A-A1BD-A142FE922805"
        else:
            ak = ak
        if ek is None:
            # ek = "64F07D9E-A229-49F4-99FC-EF5551A7B7A6"
            ek = "D69EAC8F-3497-44DD-9040-07872BE56704"
        else:
            ek = ek
        ts = time.time()
        st = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
        message = (ak + st).encode()
        secret = ek.encode()
        signature = hmac.new(secret, message, digestmod=hashlib.sha256).hexdigest()
        url = 'https://api.economy.com/data/v1/baskets?'  # historical
        time.sleep(1)
        basketContentsResponse = requests.get(url, headers={"AccessKeyId": ak, "Signature":signature, "TimeStamp": st})
        basketContentsResponse.ok
        baskets = basketContentsResponse.json()
        self.available_baskets = dict([(basket["name"], basket["basketId"]) for basket in baskets])

    def retrieve_data(self, guid, freq = 128, ak=None, ek=None, sleeptime=1):
        """retrieve data from moody's analytics via api.  The guid is in self.available_baskets.
           This will return a MetaFrame (dataframe with attached metadata).  user 172 for quarterly.
           Sleeptime will increase the wait time if there are errors.
        """
        if ak is None:
            # ak = "C96BF4F9-5EFE-4FD5-AF54-A0C48FA13795"
            ak = "DE965C73-A832-4C6A-A1BD-A142FE922805"
        else:
            ak = ak
        if ek is None:
            # ek = "64F07D9E-A229-49F4-99FC-EF5551A7B7A6"
            ek = "D69EAC8F-3497-44DD-9040-07872BE56704"
        else:
            ek = ek
        ts = time.time()
        st = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
        st = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
        message = (ak + st).encode()
        secret = ek.encode()
        signature = hmac.new(secret, message, digestmod=hashlib.sha256).hexdigest()
        url = 'https://api.economy.com/data/v1/baskets/%s/contents' % guid  # historical
        time.sleep(sleeptime)
        basketContentsResponse = requests.get(url, headers={"AccessKeyId": ak, "Signature":signature, "TimeStamp": st})
        basketContentsResponse.ok
        mnemonics = [ field["concept"] + "." + field["geo"] for field in basketContentsResponse.json()]
        ## get ready for  data pull
        series = []
        metaData = dict()
        for mnen in mnemonics:
            clean_mnen = re.sub('_[A-Z0-9]+.','.',mnen)
            time.sleep(sleeptime)
            ts = time.time()
            st = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S')
            #print(st)
            message = (ak + st).encode()
            secret = ek.encode()
            signature = hmac.new(secret, message, digestmod=hashlib.sha256).hexdigest()
            url = 'https://api.economy.com/data/v1/series?m={}&freq={}'.format(mnen,freq)
            response = requests.get(url, headers={"AccessKeyId": ak, "Signature":signature, "TimeStamp": st})
            if response.ok:
                mdata = response.json()
                #metaData[mnen] = dict()
                metaData[clean_mnen] = dict()
                for key in mdata.keys():
                    if key == "data":
                        pass
                    else:
                        metaData[clean_mnen][key] = mdata[key]
                if mdata["data"] != None: ## stops the NoneType Error on the pull
                    data = mdata["data"]["data"]
                    start_date = mdata["startDate"]
                    end_date = mdata["endDate"]

                idx = pd.date_range(start = start_date, end=end_date, freq = ('M' if freq == 128 else 'Q'), normalize = True)
                ##elem = Series(data, index = idx, name = mdata["mnemonic"])
                elem = Series(data, index = idx, name = clean_mnen)
                series.append(elem)
            else:
                print("-----")
                print(mnen)
                print(response.ok)
                print(response.reason)
                print(response.json())
            response.close()
        macro_data = DataFrame(series).T

        return(MetaFrame(macro_data, metaData))
