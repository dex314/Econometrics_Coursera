import pandas as pd
import sidetable
import numpy as np
import numpy.matlib as npm
import dask
from dask.distributed import Client, LocalCluster
from multiprocessing.pool import ThreadPool
import operator
import scipy as sp
from scipy.stats import norm
import matplotlib.pyplot as plt

from pyfnb.models.GLMNetUtils import offset_check, array_safety

class CrossValidator(object):
    '''Crossvalidation Class for the GLM Elastic Net'''
    def __init__(self, model, cv_scheme=None, num_workers=None):
        ''' model : model to cross validate
            cv_scheme : cv scheme to use (default = None)
            num_workers : number of processes to use (default = None which is Max)
        '''
        self.model = model
        self.cv_scheme = cv_scheme
        self.folds = cv_scheme.n_splits
        self.num_workers = num_workers

        ## the best option after testing is to comment this out and use
        ## the FOR loop not the list comprehension in the fit call (2022-01-25)
        #cluster = LocalCluster(n_workers = num_workers,)
        #client = Client(cluster)

    def fit(self, X, y, offset=1, weights=None):
        ''' The fit call operates like the fit call from the GLM Net
            X : independent variable(s)
            y : dependet variable(s)
            offset : offset vector (default = 1)
            weights : regression weights vector (default = None)
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.model.param_names = X.columns
        else:
            self.model.param_names = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        if weights is None:
            weights = 1
        # X, y, offset, weights = self.model.array_safety(X, np.array(y), offset, weights)
        X, y, offset, weights = array_safety(X, np.array(y), offset, weights)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.weights = weights
        self.X = X
        self.y = y

        ## managed to one line the dask code
        ##delayd = [(cv+1, dask.delayed(self.in_par)(self.model, ti, vi, X, y, offset)) \
        ##           for cv, (ti,vi) in enumerate(self.cv_scheme.split(X))]
        ##results = dask.compute(delayd)
        ##self.results_dict = sorted(dict(results[0]).items(), key=operator.itemgetter(0))
        output = []
        for cv, (ti, vi) in enumerate(self.cv_scheme.split(X)): ## ti=trainidx, vi=validx
            res = dask.delayed(self.in_par)(self.model, ti, vi, X, y, offset)
            output.append((cv+1,res))
        with dask.config.set(pool=ThreadPool(self.num_workers)):
            results = dask.compute(*output)
        self.results_dict = sorted(dict(results).items(), key=operator.itemgetter(0))

    def in_par(self, model, trn_idx, val_idx, X, y, offset):
        ''' Parition function for each cross validation.
            Built into "delayd" variable and run with dask.compute()
        '''
        xtrn, ytrn, otrn = X[trn_idx, :], y[trn_idx], offset[trn_idx] ## train  data
        xval, yval, oval = X[val_idx, :], y[val_idx], offset[val_idx] ## valid' data
        model.fit(xtrn, ytrn)
        # val_error = model.family.deviance(xval, yval, model.B0, model.B, oval, model.K, model.link, model.pwr)
        val_error = model.calc_deviance(xval, yval, model.B0, model.B, oval, model.K, model.link, model.pwr)
        min_val_error = np.where(val_error == np.nanmin(val_error))[0]
        return model.B, model.B0, model.K, min_val_error, val_error

    def cv_data_agg(self, results=None):
        ''' Aggregates the CV data into specific variables rather than the
            results dictionary. Can work on other results as well.
        '''
        if results is None:
            results = self.results_dict
        p = self.folds
        mx, nx = np.shape(self.X)
        depth = self.model.depth

        Bs = np.empty((p, nx, depth))
        B0s = np.empty((p, depth))
        Ks = np.empty((p, depth))
        model_errs = np.empty((p, depth))
        min_indxs = []

        for j in range(len(results)):
            Bs_res, B0s_res, Ks_res, min_idx_res, mod_err_res = results[j][1]
            Bs[j,:,:] = Bs_res
            B0s[j,:] = B0s_res
            Ks[j,:] = Ks_res
            max_mindx = np.max(min_idx_res) ## this avoids 0 beta issue
            #min_indxs.append(max_mindx)
            model_errs[j,:] = mod_err_res[max_mindx].flatten()

        min_lam_err = model_errs.mean(axis=0) ##min lambda error
        min_cv_err = model_errs.mean(axis=1)  ##min CV error
        min_indxs = [np.argmin(min_lam_err), np.argmin(min_cv_err)]

        self.Bs = Bs
        self.B0s = B0s
        self.Ks = Ks
        self.model_errs = model_errs
        self.min_lam_err = min_lam_err
        self.min_cv_err = min_cv_err
        self.min_indxs = min_indxs

        return Bs, B0s, Ks, model_errs, min_indxs

    def coefficient_frequency(self, beta=None, min_indxs=None, param_names=None, figsize=None):
        ''' Pulls together the frequency of variables from GLM Net.
            beta : Beta variables (default = None)
            min_indxs : list of 2 indices for min error of model [lambda, crossval] (default = None)
            param_names : parameter names (X columns default = None)
        '''
        if param_names is None:
            param_names = self.model.param_names
        if beta is None:
            beta = self.Bs
        if min_indxs is None:
            min_cv_idx = self.min_indxs[1]
            min_lam_idx = self.min_indxs[0]
        else:
            assert len(min_idxs) == 2, "min_idxs should be a list of two values [argmin lam err, argmin cv err]"

        beta_list = []
        for i in range(beta.shape[0]):
            btemp = beta[i,:,:].reshape(beta.shape[1], beta.shape[2])
            bdf = pd.DataFrame(btemp[:,min_lam_idx], index=param_names)
            bdf = bdf[np.abs(bdf.values) > 1e-4].reset_index()
            beta_list.append(bdf)

        beta_concat = pd.concat(beta_list).dropna()
        beta_concat.columns = ['variable','coefficient']
        beta_concat['value_sign'] = ['pos' if i >= 0 else 'neg' for i in beta_concat.coefficient ]
        mean_coefficients = beta_concat.groupby('variable')['coefficient'].mean()

        # bc_freq = beta_concat.stb.freq(['variable','value_sign'])
        valcnts = dict(beta_concat.variable.value_counts())

        mean_coefficients = mean_coefficients.to_frame()
        mean_coefficients['valcnts'] = mean_coefficients.index.map(valcnts)

        if figsize is not None:
            maskp = mean_coefficients.coefficient < 0
            maskn = mean_coefficients.coefficient >= 0
            fig, ax=plt.subplots(1,1,figsize=figsize)
            ax.barh(mean_coefficients[maskp].index, np.abs(mean_coefficients[maskp].coefficient), color = 'cornflowerblue')
            ax.barh(mean_coefficients[maskn].index, mean_coefficients[maskn].coefficient, color = 'salmon')
            ax.set_title("Variable Summary - End Values are CrossVal Frequency", fontsize=12)
            ax.set_xlabel("Mean Coefficient Value (Red = Positive, Blue = Negative)", fontsize=12)
            rects = ax.patches
            labels = [i for i in mean_coefficients.valcnts]

            # For each bar: Place a label
            for i, rect in enumerate(rects):
                # Get X and Y placement of label from rect.
                x_value = rect.get_width()
                y_value = rect.get_y() + rect.get_height() / 2
                # Number of points between bar and label. Change to your liking.
                space = -1
                # Vertical alignment for positive values
                ha = 'right'
                # Use X value as label and format number with one decimal place
                label = "{:.0f}".format(labels[i])
                # Create annotation
                plt.annotate(
                    label,                      # Use `label` as label
                    (x_value, y_value),         # Place label at end of the bar
                    xytext=(space, 0),          # Horizontally shift label by `space`
                    textcoords="offset points", # Interpret `xytext` as offset in points
                    va='center',                # Vertically center label
                    ha=ha)                      # Horizontally align label differently for
                                                # positive and negative values.

        return mean_coefficients

    def cv_predict(self, X=None, offset=None):
        ''' Predict call for CV that uses errors. Can only be called Post fit.
            X : independent variable matrix (default = None)
        '''
        idx = np.argmax(self.min_indxs) ## the max of the min indices
        b0 = self.B0s[1,self.min_indxs[idx]]
        b = self.Bs[1,:,self.min_indxs[idx]].reshape(-1,1)
        if X is None:
            X = self.X
        if offset is None:
            offset = self.offset
        return self.model.glink(b0 + X.dot(b),offset,self.model.link)


## TIME SERIES CROSS VALIDATION ===============================================
from sklearn.model_selection import BaseCrossValidator
from sklearn.model_selection._split import _BaseKFold
from sklearn.utils.validation import _num_samples
from sklearn.utils import indexable

class FNBTimeSeriesSplit(_BaseKFold):
    def __init__(self, n_splits=5, test_size=4, max_train_size=None, window=1, gap=0):
        '''
           inherits from sklearn time series split but made for FNB style
           where the test size can be specified but the rolling window only
           ever slides by 1 point
           window gap not yet implemented
        '''
        super().__init__(n_splits, shuffle=False, random_state=None)
        self.max_train_size = max_train_size ## unused but maintained for implementation
        self.test_size = test_size ## this is our n_ahead argument
        self.gap = gap ## unused but maintained for implementation
        self.shift = 1 #window

    def split(self, X, y=None, groups=None):
        '''inherits'''
        X, y, groups = indexable(X, y, groups)
        n_samples = _num_samples(X)
        n_splits = self.n_splits ## old cvits (p)
        n_folds = n_splits + 1
        gap = self.gap
        shift = self.shift
        ## test_size is old "n_ahead"
        test_size = self.test_size if self.test_size is not None \
            else n_samples // n_folds

        # Make sure we have enough samples for the given split parameters
        if n_folds > n_samples:
            raise ValueError(
                (f"Cannot have number of folds={n_folds} greater"
                 f" than the number of samples={n_samples}."))
        ## this error check only counts if we do not include any of the previous X test points
        # if n_samples - gap - (test_size * n_splits) <= 0:
        #     raise ValueError(
        #         (f"Too many splits={n_splits} for number of samples"
        #          f"={n_samples} with test_size={test_size} and gap={gap}."))

        indices = np.arange(n_samples)
        train_starts = np.arange(0, n_splits, shift)
        test_starts = np.arange(n_samples - n_splits*shift - test_size, n_samples, shift)

        for i, t in enumerate(train_starts):
            train = indices[train_starts[i]:test_starts[i]]
            test = indices[test_starts[i]:test_starts[i]+test_size+shift]
            yield (train, test)
            ## yield is slightly different than "return"
