
import pandas as pd
import sidetable
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sma
import statsmodels.robust.norms as M
import os
from scipy.special import gammaln, logit, psi
from collections import namedtuple
import numpy.matlib as npm
import numpy.random as npr
import scipy as sp
from scipy.stats import norm

from pyfnb.models.GLMNetUtils import offset_check, array_safety
from sklearn.base import RegressorMixin, BaseEstimator

## ========================================================================================

def lam_seq_generator(X, y, rob_mod, offset=1, alpha=1, nlen=100):
    ''' Generates lambda sequence - updated with sklearn style approximation.
        X, y : independent and dependent variables
        rob_mod : robust model call for the weight functions
        offset : offset vector
        alpha : penalty multiplier
        nlen : length of sequence
    '''
    m,n=np.shape(X)
    if m>n: lratio = 1e-4
    else:   lratio = 1e-2
    if alpha <= 0: alpha = 1e-2
    wX = rob_mod.weight_function(y-np.mean(y))*X
    # lmax = np.max(np.abs(np.dot(wX.T,y)))/(m*alpha)
    # llog = np.linspace(np.log(lmax), np.log(lratio*lmax), nlen)
    # return np.exp(np.insert(llog,0,-10))
    ## both version work out the same here - its weird
    Xy = np.dot(wX.T,y)
    lmax = np.sqrt(np.sum(Xy ** 2, axis=1)).max() / (m * alpha) ##sklearn
    return np.logspace(np.log10(lmax * lratio), np.log10(lmax), num=nlen)[::-1]

## ========================================================================================

class RobustNet(BaseEstimator, RegressorMixin):
    ''' Elastic Net Base Parent Class '''
    def __init__(self):
        self.in_check = 'In Parent Class'

    def score(self, X, y, offset=1, sample_weight=None, score_method='r2'):
        '''Score Method - Added for easy sklearn inheritance.
           score_method = r2, mean_deviance, or loglikelihood.
        '''
        y_pred = self.predict(X)
        if score_method == 'r2':
            from sklearn.metrics import r2_score
            return r2_score(y, y_pred, sample_weight=sample_weight)
        elif score_method == 'mean_dev':
            from sklearn.metrics import mean_tweedie_deviance
            return mean_tweedie_deviance(y, y_pred, sample_weight=sample_weight)
        else:
            print("Not yet implemented...")
            return 0

    ## moving this didnt help
    def glink(self, p, offset=1, link='identity'):
        '''link function'''
        if link == 'identity':
            return p
        elif link == 'log':
            return np.exp(p + np.log(offset))
        elif link == 'logit':
            return self.sigmoid(p)
        else:
            raise Exception('** This link not implmented! **')
            return 0

    def sigmoid(self,z):
        ''' sigmoid function 1/(1+exp(-z)) for logit '''
        return 1.0/(1.0+np.exp(-z))

    def corddesc(self, X, y, b0_init, b_init, lam, offset=1, weights=1, k=1, alpha=1, nullDev=1, tol=1e-6):
            ''' Cost Function Convergence Coordinate Descent for Robust Elastic Net
                X, y, offset: arrays for descent
                b0_init, b_init: intial betas
                lam: lambda parameter
                weights: intial weightings
                k: dispersion measure
                alpha: penalty multiplier
                nullDev: null deviance
                tol: tolerance for beta Convergence
            '''
            m,n = np.shape(X)
            npass, tol_chk = 0, 1
            b = np.zeros((n,1))
            w = self.weight_function(y - (X.dot(b_init) + b0_init)) #-np.mean(y))
            z = y.copy()
            # p = self.glink(b0_init + X.dot(b_init), offset, self.link)
            # w, z = self.cd_weights(X, y, p, k, b0_init, b_init, self.pwr, weights)
            wsum = np.sum(w)
            cost = self.cost_function(X, y, b0_init, b_init, w, lam, alpha)
            while tol_chk >= tol and npass<1000:
                npass+=1
                b0 = np.dot( w.T, np.subtract(z, np.dot(X,b))) / wsum
                for ii in range(0,n):
                    xi = X[:,[ii]]
                    wxi = w*X[:,[ii]]
                    b[ii] = np.dot(wxi.T, (np.subtract(z, np.dot(X,b)) - b0 + xi*b[ii]))/m
                    f = np.abs(b[ii]) - alpha*lam
                    st = np.sign(b[ii]) * (np.abs(f) + f)/2.0 ## SoftThreshHolding
                    b[ii] = np.divide(st , np.add( np.dot(xi.T, (wxi))/m , (1.0-alpha)*lam ))
                cost_update = self.cost_function(X, y, b0, b, w, lam, alpha)
                ## beta convergence
                # tol_chk = np.linalg.norm(np.subtract(b0+b, b0_init+b_init))
                ## cost function convergence (same result as beta)
                tol_chk = np.abs(np.subtract(cost, cost_update))
                cost = cost_update.copy()
                b_init[:] = b[:]
                b0_init[:] = b0[:]

            return b0, b, npass

    def fit(self, X=None, y=None, offset=1, weights=None):
        ''' Fit call for consistency with sklearn. Offset is not used for Gaussian or Logistic.
            X, y: independent and dependent Variables
            weights: initial weights
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        if weights is None:
            weights = 1
        X, y, offset, weights = array_safety(X, np.array(y), offset, weights)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.weights = weights
        self.disp_method = 'x2'
        self.X = X
        self.y = y

        b_init = np.zeros((nx,1))
        b0_init = self.calc_b0_init(y, offset, self.link)
        k_init, dummy = self.disp_est(X, y, b0_init, b_init, self.pwr, offset,
                                        1, self.link, self.disp_method, self.weights)

        dev = np.mean(self.calc_deviance(X, y, b0_init, b_init, offset, k_init, self.link, self.pwr))
        # ylam = self.weight_function(y - self.glink(b0_init, offset, self.link))
        ylam = self.weight_function(y - np.mean(self.glink(b0_init, offset, self.link)))
        # lambdas = self.lam_seq_generator(X, ylam, offset, self.alpha, self.lslen, self.manual_lamseq)

        if self.reg_lambda is None:
            lambdas = lam_seq_generator(X, ylam, offset, self.alpha, self.lslen)
            minL = min(self.depth, self.lslen)
        else:
            lambdas = list(self.reg_lambda) if type(self.reg_lambda ) != list else self.reg_lambda
            if len(lambdas) <= 1:
                lams_temp = lam_seq_generator(X, ylam, offset, self.alpha, 2)
                lams_temp[1] = lambdas[0]
                lambdas = lams_temp
            minL = len(lambdas) - 1
        self.lambdas = lambdas

        outlier_check = self.weight_function(y)
        self.outliers = (outlier_check != 1).astype(int)

        if np.isnan(b0_init).any() == True:
            raise Exception("The value of b0 is NAN. Confirm y is NOT standardized.")

        ##Storage Methods for Variables----------------------------------------
        betas = np.empty((nx, minL))
        beta0s = np.empty((1, minL))
        ks = np.empty((1, minL))
        yhats = np.empty((minL, my))
        disp_iters = np.empty((minL,1))
        mod_err = np.empty((minL,1))
        npasses = np.empty((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = self.disp_est(X, y, b0_init, b_init, self.pwr, offset,
                                         k_init, self.link, self.disp_method, self.weights)

            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.corddesc(x_nzb, y, b0_init, b_nzb, lambda1, offset,
                                         weights, k, self.alpha, dev/mx, self.tol)

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b.reshape(-1,1)[:]
            model_dev = self.calc_deviance(X,y,b0_init,b_init,offset,k_init,self.link,self.pwr)
            if (dev-model_dev)/dev > 0.9:  break ##sclars no need to np it
            yhat = b0_init + X.dot(b_init)

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev
            npasses[j] = npass

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        ## no longer need lowest beta check
        self.B = betas
        self.B0 = beta0s
        self.offset = offset
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err
        self.npasses = npasses

    def predict(self, X=None, offset=None):
        ''' Predict call for consistency with SKLEARN '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
        if offset is None:
            offset = self.offset
        return self.glink(b0 + X.dot(b),offset,self.link)

    def scale_function(self, z, method=None):
        ''' scale function
            Median Abs Deviation or InterQuartile Range
        '''
        if method == 'mad':
            center = self.center
            scale = norm.ppf(3/4.0)
            return np.median(np.abs(z-center)/scale)
        if method == 'iqr':
            scale = norm.ppf(3 / 4) - norm.ppf(1 / 4)
            quantiles = np.quantile(z, [0.25, 0.75], axis=0)
            return np.squeeze(np.diff(quantiles, axis=0) / scale)
        else:
            raise ValueError("method %s unknown" % method)

## ===========================================================================================
class HuberNet(RobustNet):
    def __init__(self, alpha=1.0, reg_lambda=None, depth=20, lamseq_len=100, link='identity',
                 scale=None, center=None, tuningc=1.345, tol=1e-6, pwr=None):
        '''
        HuberNet is a robust elastic net based on the Huber estimator.
        alpha = 1.0
        reg_lambda = None: lamda regularization param, value or list of values
        depth = 20
        scale = None (default is MAD, options are MAD and IQR)
        center = None (Default is 0)
        tuningc = 1.345 (Default to HuberT)
        tol = 1e-6
        pwr = no effect, left for consistency with GLMNet
        '''
        self.alpha = alpha
        self.depth = depth
        self.reg_lambda = reg_lambda
        self.lslen = lamseq_len
        assert depth < lamseq_len, "** Depth must be less than length of Lambda sequence. **"
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.link = link
        self.family_name = 'Huber'
        self.pwr = pwr

        if scale is None:
            self.scale = 'mad'
            # self.scale = norm.ppf(3/4) ##inverse cdf of gaussian at 0.75
        else:
            self.scale = scale
        if center is None:
            self.center = 0
        else:
            self.center = center
        self.tuningc = tuningc
        RobustNet.__init__(self)

    def calc_b0_init(self, y, offset, link):
        b0_init = np.mean(y, axis=0)
        return b0_init

    def calc_deviance(self, X, y, b0, b, offset, k, link, pwr):
        '''Modeled after Gaussian'''
        m,n = np.shape(X)
        mu = self.glink(b0 + X.dot(b), offset, link)
        LL = np.subtract(y, mu)
        L = 0.5/len(y) * LL.T.dot(LL)
        return L

    def cd_weights(self, X, y, p, k, b0, b, pwr, weights):
        '''for consistency with GLMNet'''
        # w = np.ones((len(y),1))
        w = self.weight_function(p)
        z = y.copy()
        return w, z

    def weight_function(self, r):
        '''Huber Weight Function'''
        # mad = np.median(np.abs(r-self.center)/self.scale)
        # resid = np.where(np.abs(r/mad) < self.tuningc, 1, self.tuningc/np.abs(r/mad))
        scale = self.scale_function(r, self.scale)
        resid = M.HuberT(t=self.tuningc).weights(r/scale)
        return resid

    def cost_function(self, X, y, b0, b, weight, lam, alpha):
        '''Weight Oriented Cost Function'''
        yhat = b0 + X.dot(b)
        err = y - yhat
        werr = weight.reshape(-1,1) * err
        l1 = alpha*np.linalg.norm(b.flatten(),1)
        l2 = (1-alpha)*np.linalg.norm(b.flatten(),2)
        cf = werr.T.dot(err)/(2.0*len(err)) + lam*(l1+l2)
        return cf

    def disp_est(self, X, y, b0, b, pwr, offset=1, k=1, link='identity', disp_method=None, weights=None):
        '''left for consistency with GLM Net'''
        k, iters = 1e-5, 0
        return k, iters

## =============================================================================
class TukeyBWNet(RobustNet):
    def __init__(self, alpha=1.0, reg_lambda=None, depth=20, lamseq_len=100, link='identity',
                 scale=None, center=None, tuningc=4.685, tol=1e-6, pwr=None):
        '''
        TukeyBW is a robust elastic net based on the Tukey Biweught estimator.
        alpha = 1.0
        depth = 20
        reg_lambda = None: lamda regularization param, value or list of values
        scale = None (default is MAD, options are MAD and IQR)
        center = None (Default is 0)
        tuningc = 4.685 (Default to Tukey Biweight)
        tol = 1e-6
        pwr = no effect, left for consistency with GLMNet
        manual_lamseq = None (for passing a manual lambda sequence for faster convergence)
        '''
        self.alpha = alpha
        self.depth = depth
        self.reg_lambda = reg_lambda,
        self.lslen = lamseq_len
        assert depth < lamseq_len, "** Depth must be less than length of Lambda sequence. **"
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.link = link
        self.family_name = 'TukeyBiWeight'
        self.pwr = pwr

        if scale is None:
            self.scale = 'mad'
        else:
            self.scale = scale
        if center is None:
            self.center = 0
        else:
            self.center = center
        self.tuningc = tuningc
        RobustNet.__init__(self)

    def calc_b0_init(self, y, offset, link):
        b0_init = np.mean(y, axis=0)
        return b0_init

    def calc_deviance(self, X, y, b0, b, offset, k, link, pwr):
        '''Modeled after Gaussian'''
        m,n = np.shape(X)
        mu = self.glink(b0 + X.dot(b), offset, link)
        LL = np.subtract(y, mu)
        L = 0.5/len(y) * LL.T.dot(LL)
        return L

    def cd_weights(self, X, y, p, k, b0, b, pwr, weights):
        '''for consistency with GLMNet'''
        # w = np.ones((len(y),1))
        w = self.weight_function(p)
        z = y.copy()
        return w, z

    def weight_function(self, r):
        '''TukeyBiweighte Weight Function'''
        scale = self.scale_function(r, self.scale)
        resid = M.TukeyBiweight(c=self.tuningc).weights(r/scale)
        return resid

    def cost_function(self, X, y, b0, b, weight, lam, alpha):
        '''Weight Oriented Cost Function'''
        yhat = b0 + X.dot(b)
        err = y - yhat
        werr = weight.reshape(-1,1) * err
        l1 = alpha*np.linalg.norm(b.flatten(),1)
        l2 = (1-alpha)*np.linalg.norm(b.flatten(),2)
        cf = werr.T.dot(err)/(2.0*len(err)) + lam*(l1+l2)
        return cf

    def disp_est(self, X, y, b0, b, pwr, offset=1, k=1, link='identity', disp_method=None, weights=None):
        '''left for consistency with GLM Net'''
        k, iters = 1e-5, 0
        return k, iters
