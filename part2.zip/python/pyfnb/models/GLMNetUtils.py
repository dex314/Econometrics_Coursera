import numpy as np
import numpy.random as npr
import numpy.matlib as npm
from scipy.special import psi
from scipy.special import gammaln
from collections import namedtuple, Counter
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sma
import pandas as pd
import dask
import operator

## STANDARD UTILITIES =========================================================
def offset_check(offset, y):
    '''Confirms offset size matches y size.'''
    if np.size(offset) == 1:
        if offset == 0:
            return np.ones(y.shape)
        else:
            return offset * np.ones(y.shape)
    else:
        return np.ones(y.shape)


def array_safety(X, y, offset, weights):
    '''Confirms that X, y are multi-dimensional and not flat.'''
    if y.ndim <= 1:
        y = y.reshape(-1,1)
    mx,nx=np.shape(X)
    my,ny=np.shape(y)
    offset = offset_check(offset, y)
    offset = np.reshape(offset, (my*ny,1), order='F')
    weights = offset_check(weights, y)
    weights = np.reshape(weights, (my*ny,1), order='F')
    if ny > 1: self.multivariate_model = True
    X = npm.repmat(X, ny, 1)
    y = np.reshape(y, (my*ny,1), order='F')
    assert len(offset) == len(y), "Length of Offset != Length of y"
    assert len(weights) == len(y), "Length of Weights != Length of y"
    return X, y, offset, weights



#%% PLOTTING FUNCTIONS=========================================================
#%% Plot Variable Paths and Error Over Cross Val===============================
def path_plot(Bs, B0s, figsize=(12,8)):
    ''' function for plotting the Beta and Beta_0 paths
        _ = path_plot(model.B, model.B0, figsize)
    '''
    if len(Bs.shape) > 2:
        r_n = np.floor(len(Bs)/4)
        if r_n == 0 or r_n == 'inf':    r_n = 1;
        c_n = np.ceil(len(Bs)/r_n)
        if c_n == 0 or c_n == 'inf':    c_n = 1;

        if r_n>1 or c_n>1:
            fp, ax_p = plt.subplots(int(r_n), int(c_n), sharex=True, sharey=True, figsize=figsize)
            ax_p = ax_p.ravel()
            for i in range(len(Bs)):
                ax_p[i].plot(Bs[i][:,:].T)
                plt.suptitle('Lasso Parameters')

            fp0, ax_b0 = plt.subplots(int(r_n), int(c_n), sharex=True, sharey=True, figsize=figsize)
            ax_b0 = ax_b0.ravel()
            for i in range(len(B0s)):
                ax_b0[i].plot(B0s[i].T, 'go')
                plt.suptitle('Intercept Convergence')
    else:
        f1, ax_c = plt.subplots(1,2,figsize=figsize)
        ax_c = ax_c.ravel()
        ax_c[0].plot(Bs.T)
        ax_c[0].set_title('Betas')
        ax_c[1].plot(B0s.T, 'go')
        ax_c[1].set_title('Intercept')


#%% Nahead AND LAMS PLOT=======================================================
def err_plot(dev, figsize=(12,8)):
    ''' function for plotting the deviance or error
        _ = err_plot(model.model_errors.T, figsize)
    '''
    f, axe = plt.subplots(1,2, sharex=False, sharey=False, figsize=figsize)
    axe = axe.ravel()
    ##Transposing Need??????
    for j in range(2):
        if j == 0:
            de = dev.T; xlabs='Lambda Depth'
        else:
            de = dev; xlabs='CV Depth'

        lc_mn = []; lc_std = [];
        for i in range(np.shape(de)[0]):
            lc_mn.append(np.mean(de[i,:], axis=0))
            lc_std.append(np.std(de[i,:], axis=0))

        yercv = [np.array(lc_std)[:], 2.0*np.array(lc_std)[:]]
        axe[j].errorbar(range(len(lc_mn)), np.array(lc_mn)[:], yerr=yercv, c='r',
                                                    marker='o', ms=4, mew=1.5, mec='k')
        axe[j].set_xlabel(str(xlabs))
    plt.suptitle('Cross Validation Deviance (Error)')


## Highlight Coefficient Values and Descriptions =============================
def highlight_gt(s):
    '''    highlight POSITIVES in red    '''
    is_gt = s > 0
    return ['background-color: lightcoral' if v else '' for v in is_gt]

def highlight_lt(s):
    '''    highlight NEGATIVES in blue    '''
    is_lt = s < 0
    return ['background-color: cornflowerblue' if v else '' for v in is_lt]


def describe_vars(betas, param_nm, metadata, X=None, y=None, get_pvals=True, pval_thresh=0.15):
    ''' Function to describe variables and compare p-values pre-emptively.
        betas = coefficients from model
        param_nm = list of coefficient names
        metadata = appropriate meta data
        X = exogenous variables relative to betas and param_nm
        y = endog data (set this to the the training indices)
        get_pvals = if True gets simple OLS p values
        pval_thresh = threshold for display on p values, anything less than this value will be ommitted
    '''
    varc = pd.DataFrame(betas.T, columns=param_nm).iloc[-1,:].groupby(param_nm).mean().to_frame()
    varc.columns = ['coeff']

    if get_pvals:
        assert X is not None, "Please define the exog matrix as X = {exog}"
        assert y is not None, "Please define the endog matrix as y = {endog}"
        spval = []
        for item in varc.index:
            y_tmp = y.copy()
            x_tmp = X[item].loc[y_tmp.index]
            ols_tmp = sma.OLS(endog = y_tmp, exog = sma.add_constant(x_tmp), hasconst=True).fit()
            spval.append(ols_tmp.pvalues.loc[item])
        varc['single_pval'] = spval

    ## meta data descritions with replacement
    varc['desc'] = [metadata.meta_data[c.replace('_DOL_','$')]['description'].split(':')[2:] for c in varc.index]
    varc2 = varc[varc.single_pval <= pval_thresh]
    #varc2.style.apply(highlight_gt, subset=['coeff']).apply(highlight_lt, subset=['coeff'])
    return varc2


## CrossValidation Description Graph =========================================
def cv_graph(x, n_splits, test_size, window=0, figsize=(12,6), plot=True):
    ''' Function to plot the Cross Validation Scheme '''
    m = len(x)
    xidx = x.index
    df = pd.DataFrame(index = xidx)
    for i in range(n_splits):
        mpi = m - n_splits + i
        trn0 = int(i)
        trnF = int(mpi-test_size)
        val0 = int(mpi-test_size+1)
        valF = int(mpi)
        df['CV_{}'.format(i+1)] = 0
        df['CV_{}'.format(i+1)] = 1*((df.index>=xidx[trn0])&(df.index<=xidx[trnF])) + \
                -1*((df.index>=xidx[val0])&(df.index<=xidx[valF]))
    try:
        df.index = df.index.date
    except:
        df.index = df.index
    if plot == True:
        fig, ax=plt.subplots(1,1,figsize=figsize)
        sns.heatmap(df.T, cmap='coolwarm', linewidth=1, cbar=False, ax=ax, vmin=-1, vmax=1);
        ax.set_title("Cross Validation Graph", fontsize=16);
        ax.set_xlabel("Red = Train | Blue = Val | Gray = Unused", fontsize=16);
        plt.xticks(rotation=35);
    return df


## R POWER ESTIMATE FUNCTION ==================================================
def r_tweedie_power_est(y, X, figsize=None):
    ''' DEPRECATED - DO NOT USE - 2022-06-24
        R Based Tweedie Power Estimate
        y = pandas series or data frame
        X = pandas data frame

        The R function runs tweedie model profile with log link (0) over
        vector range np.arange(1.1, 1.95, 0.05).

        returns: power_estimate, loglikelihoods, power_range
    '''
    import re
    from rpy2.robjects import r
    from rpy2.robjects import pandas2ri
    from rpy2.robjects.packages import importr
    from rpy2 import robjects
    import rpy2
    pandas2ri.activate()

    rmass = importr('MASS')
    rstats = importr('stats')
    rbase = importr('base')
    rtweed = importr('tweedie')
    rdf = pd.concat([y, X], axis=1) ## R data frame
    y_name = y.name if type(y) == pd.core.series.Series else y.columns[0] ## y needs to be a series
    profile = rtweed.tweedie_profile('{} ~ .'.format(y_name), data=rdf,
                                     link_power=0,
                                     xi_vec=np.arange(1.1, 1.95, 0.05))
    loglik = profile.rx2['y']
    power_rng = profile.rx2['x']
    xi_max = profile.rx2['xi.max']
    if figsize is not None:
        fig, ax=plt.subplots(1,1,figsize=figsize)
        plt.scatter(power_rng, loglik)
        ax.axvline(xi_max)
        ax.set_ylabel("Log Likelihood")
        ax.set_xlabel("Power Range")
        ax.legend(['Power Est = {}'.format(np.round(xi_max[0],4))])
        ax.set_title("R Power Estimation");
    return xi_max[0], loglik, power_rng
