# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 15:51:32 2017

@author: SchillW

Yule-Walker Class
http://www.stat.ufl.edu/~winner/sta6208/gls1.pdf

TO DO:
    - finish doc explanations
    - confirm correct outputs on other models
    - add HC3 covariance mat fit call
"""

import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import statsmodels.api as sma
from matplotlib.pyplot import *
import statsmodels.stats as sms
import statsmodels.tools as smt
import statsmodels.graphics as smg
from statsmodels.tsa.stattools import acf
import copy
import scipy
import statsmodels.base.model as base
import statsmodels.base.wrapper as wrap
from statsmodels.iolib.table import SimpleTable

#%%
class Autoregression(sma.regression.linear_model.RegressionModel):
    __doc__ = """

    Generalized least squares model with a general covariance structure.

    %(params)s
    sigma : scalar or array
        `sigma` is the weighting matrix of the covariance.
        The default is None for no scaling.  If `sigma` is a scalar, it is
        assumed that `sigma` is an n x n diagonal matrix with the given
        scalar, `sigma` as the value of each diagonal element.  If `sigma`
        is an n-length vector, then `sigma` is assumed to be a diagonal
        matrix with the given `sigma` on the diagonal.  This should be the
        same as WLS.
    %(extra_params)s

    **Attributes**

    pinv_wexog : array
        `pinv_wexog` is the p x n Moore-Penrose pseudoinverse of `wexog`.
    cholsimgainv : array
        The transpose of the Cholesky decomposition of the pseudoinverse.
    df_model : float
        p - 1, where p is the number of regressors including the intercept.
        of freedom.
    df_resid : float
        Number of observations n less the number of parameters p.
    llf : float
        The value of the likelihood function of the fitted model.
    nobs : float
        The number of observations n.
    normalized_cov_params : array
        p x p array :math:`(X^{T}\Sigma^{-1}X)^{-1}`
    results : RegressionResults instance
        A property that returns the RegressionResults class if fit.
    sigma : array
        `sigma` is the n x n covariance structure of the error terms.
    wexog : array
        Design matrix whitened by `cholsigmainv`
    wendog : array
        Response variable whitened by `cholsigmainv`

    Notes
    -----
    If sigma is a function of the data making one of the regressors
    a constant, then the current postestimation statistics will not be correct.


    Examples
    --------
    >>> import numpy as np
    >>> import statsmodels.api as sm
    >>> data = sm.datasets.longley.load()
    >>> data.exog = sm.add_constant(data.exog)
    >>> ols_resid = sm.OLS(data.endog, data.exog).fit().resid
    >>> res_fit = sm.OLS(ols_resid[1:], ols_resid[:-1]).fit()
    >>> rho = res_fit.params

    `rho` is a consistent estimator of the correlation of the residuals from
    an OLS fit of the longley data.  It is assumed that this is the true rho
    of the AR process data.

    >>> from scipy.linalg import toeplitz
    >>> order = toeplitz(np.arange(16))
    >>> sigma = rho**order

    `sigma` is an n x n matrix of the autocorrelation structure of the
    data.

    >>> gls_model = sm.GLS(data.endog, data.exog, sigma=sigma)
    >>> gls_results = gls_model.fit()
    >>> print(gls_results.summary())

    """ % {'params' : base._model_params_doc,
           'extra_params' : base._missing_param_doc + base._extra_param_doc}

    def __init__(self, endog, exog, ar=1, d=0, sigma=None, missing='none', hasconst=None,**kwargs):
        '''
        reference for method implemented can be found at http://www.stat.ufl.edu/~winner/sta6208/gls1.pdf
        Given dataset with exogenous matrix x and endogenous variable y and an implied AR(p) error structure
        we get same results as

        ====================================================================================================
        SAS REPLICATION OF SIGMA CALCULATION
        proc autoreg data=dataset;
          model y = x / nlag = ar ginv coef method = yw;
        run;
        ====================================================================================================
        hasconst is necessary for base, not necessarily for intermediate calcs
        '''
        if (exog.shape[0] != endog.shape[0]):
            raise Exception("endog and exog dimensions do not align")
        self.orig_endog = endog.copy()
        self.orig_exog = exog.copy()


        ## difference endog - note: the first d obs get drops
        try:
            endog = pd.Series(np.diff(endog,d), name = "d^{} ".format(d)*(1 if d > 0 else 0) + endog.name, index = endog.index[d::])
        except:
            endog = np.diff(endog,d)
        ## align exog with endog
        exog = exog[d::]

        nobs = exog.shape[0]
        df_resid = exog.shape[0] - exog.shape[1] - ar
        ols = sma.regression.linear_model.OLS(endog = endog, exog=exog).fit()
        self.ols = ols
        RHO = sma.regression.yule_walker(ols.resid, order=ar, inv=True, method="mle")
        GINV = RHO[2]
        self.GINV = GINV  # inverse of Toeplitz matrix of AR coefficients
        sig = RHO[1]**2   # preliminary mse
        self.sig = sig
        P = np.linalg.cholesky(GINV).T
        yw_coef = RHO[0]  # yule-walker coefficients
        yw_std = np.sqrt( np.diag( sig*GINV) / ( df_resid ))  # standard error of yule-walker coefficients
        T11 = np.sqrt(sig)*P   # constructing V
        T12 = np.zeros([ar, nobs - ar])  # constructing V
        rho2 = np.append( -yw_coef[::-1], 1) # constructing V
        T2 = np.zeros([nobs - ar, nobs])# constructing V
        for i in range(nobs - ar): # constructing V
            T2[i, 0 + i:ar + i + 1] = rho2 # constructing V
        T = np.concatenate( (np.concatenate((T11, T12), axis=1), T2), axis=0) # constructing V
        V = np.dot(T.T, T)
        sV = np.linalg.pinv(V)

        sigma, cholsigmainv = sma.regression.linear_model._get_sigma(sV, len(endog))

        self.yw_coef = yw_coef
        self.yw_std = yw_std
        self.V = V
        coef = (scipy.linalg.cholesky( V, lower=False)[-ar:,-ar:])  ## coefficient matrix used to whiten first ar records
        self.whiten_first_ar_terms = np.flip(np.flip(coef,axis=0),axis=1)

        super(Autoregression, self).__init__(endog, exog, missing=missing,
                                  hasconst=hasconst, sigma=sigma,
                                  cholsigmainv=cholsigmainv, **kwargs)

        self.ar = ar
        self.nobs = nobs
        self.df_resid = df_resid
        self.df_model = self.nobs - self.df_resid
        self.d = d
        i1 = np.linalg.inv( np.dot(np.dot( exog.T, V), exog))
        i2 = np.dot(np.dot( exog.T, V), endog)

        self.byw = np.dot(i1, i2)  ## preliminary autoregression parameters
        ## update made to py 3.9
        try: ## py >= 3.9
            self.estimated_acorr = acf(ols.resid, adjusted=False, nlags=ar+1, qstat=False, fft=False, alpha=None, missing='none')
        except: ## py < 3.9
            self.estimated_acorr = acf(ols.resid, unbiased=False, nlags=ar+1, qstat=False, fft=False, alpha=None, missing='none')
        self.estimated_acov = self.estimated_acorr * np.linalg.pinv(GINV)[0][0]

        #store attribute names for data arrays
        self._data_attr.extend(['sigma', 'cholsigmainv', 'ar', 'whiten_first_ar_temrs', 'yw_coef'])
    # def olsSummary(self):
    #     """
    #     OLS Summary pull.
    #     """
    #     return self.initOLS.summary()

    def acovPrint(self):
        """
        Printing the AR coefficient terms to match sas output
        """
        # autoCovDf = pd.DataFrame(np.round(self.estimated_acov,8),
        #              columns=['Covariance'], index=range(1,len(self.estimated_acov)+1))
        # autoCorrDf = pd.DataFrame(np.round(self.estimated_acorr,8),
        #                      columns=['Correlation'], index=range(1,len(self.estimated_acorr)+1))
        # out = pd.concat([autoCovDf, autoCorrDf], axis=1, join='outer'); out.index.name = 'Lag'

        pic = []
        for i in self.estimated_acorr:
            if(i == 1):
                pic.append(" "*20 + "|"+ "*" * 20 )
            elif(i < 0):
                temp = int(np.abs(np.round(i*20,0)))
                pic.append(' '*(20 - temp) + '*' * temp +"|"+ " "*20)
                #print( ' '*(20 - temp) + '*' * temp)
            else:
                temp = int(np.abs(np.round(i*20,0)))
                pic.append(' '*20 +"|"+ '*'*temp + " "*(20 - temp))

        data = list(zip( np.arange(0, self.ar+1), self.estimated_acov, self.estimated_acorr, pic))
        tbl = SimpleTable(data, ["Lag", "Autocovariance", "Autocorrelation", "-1"+" "*18 + "0" + " "*19 + "1"], title="Estimates of Autocorrelations")
        return tbl

    def arPrint(self):
        """
        Printing the AR coefficient terms.
        """
        # ywcDF = pd.DataFrame(np.round(self.yw_coef,4),
        #              columns=['Coefficient'], index=range(1,len(self.yw_coef)+1))
        # ywsDF = pd.DataFrame(np.round(self.yw_std,4),
        #                      columns=['Std Err'], index=range(1,len(self.yw_coef)+1))
        # ywtvDF = pd.DataFrame(np.round(ywcDF.values/ywsDF.values,4)
        #                       , columns=['t Value'], index=range(1,len(self.yw_coef)+1))
        # ywAll = pd.concat([ywcDF, ywsDF, ywtvDF], axis=1, join='outer'); ywAll.index.name = 'Lag'
        data = list( zip( np.arange(1, self.ar+1), self.yw_coef, self.yw_std, self.yw_coef / self.yw_std))
        tbl = SimpleTable(data, ["Lag", "Coefficient", "Standard Error", "t Value"], title = "Estimates of Autoregressive Parameters")
        return tbl

    def whiten(self, X):
        """
        Whitening method from SAS proc autoreg.
        Parameters
        -----------
        X : array-like
            Data to be whitened.
        See Also
        --------
        http://support.sas.com/documentation/cdl/en/etsug/63939/HTML/default/viewer.htm#etsug_autoreg_sect028.htm
        """
        # whiten first ar terms based on incomplete information.
        x_first_q_obs = np.dot(self.whiten_first_ar_terms, X[0:self.yw_coef.shape[0]]) ## replace coef
        X = np.asarray(X, np.float64)
        _X = X.copy()
        #the following loops over the first axis,  works for 1d and nd
        # whitens remaining n - ar observations
        for i in range(self.yw_coef.shape[0]):
            _X[(i+1):] = _X[(i+1):] - self.yw_coef[i] * X[0:-(i+1)]
        #return _X[rho.shape[0]:]
        return np.concatenate( (x_first_q_obs, _X[self.yw_coef.shape[0]:]), axis=0)

    def loglike(self, params):
        """
        Returns the value of the Gaussian log-likelihood function at params.

        Given the whitened design matrix, the log-likelihood is evaluated
        at the parameter vector `params` for the dependent variable `endog`.

        Parameters
        ----------
        params : array-like
            The parameter estimates

        Returns
        -------
        loglike : float
            The value of the log-likelihood function for a GLS Model.


        Notes
        -----
        The log-likelihood function for the normal distribution is

        .. math:: -\\frac{n}{2}\\log\\left(\\left(Y-\\hat{Y}\\right)^{\\prime}\\left(Y-\\hat{Y}\\right)\\right)-\\frac{n}{2}\\left(1+\\log\\left(\\frac{2\\pi}{n}\\right)\\right)-\\frac{1}{2}\\log\\left(\\left|\\Sigma\\right|\\right)

        Y and Y-hat are whitened.

        """
        #TODO: combine this with OLS/WLS loglike and add _det_sigma argument
        nobs2 = self.nobs / 2.0
        SSR = np.sum((self.wendog - np.dot(self.wexog, params))**2, axis=0)
        llf = -np.log(SSR) * nobs2      # concentrated likelihood
        llf -= (1+np.log(np.pi/nobs2))*nobs2  # with likelihood constant
        if np.any(self.sigma):
        #FIXME: robust-enough check?  unneeded if _det_sigma gets defined
            if self.sigma.ndim==2:
                det = np.linalg.slogdet(self.sigma)
                llf -= .5*det[1]
            else:
                llf -= 0.5*np.sum(np.log(self.sigma))
            # with error covariance matrix
        return llf

#%%

def sasStatPrint(fit):
    """
    All methods here developed using non whitened statmodel residuals and
    based on the SAS Proc AutoReg method from:
    https://support.sas.com/documentation/cdl/en/etsug/63939/HTML/default/viewer.htm#autoreg_toc.htm
    MAE does not match.  We are unable to tranlate what sas is doing for the first p observations when
    calc'ing predicted values
    """
    e = fit.resid
    y = fit.model.endog
    x = fit.model.exog

    wresid = fit.wresid
    wendog = fit.model.wendog
    wexog = fit.model.wendog

    mae = np.abs(wresid).mean()
    mape = (np.abs( wresid[y != 0] / y[y!=0])).mean() * 100

    ## not 100% sure about the following calc
    regress_r_square = 1 - ( (wresid )**2).sum()/ \
            ((wendog - fit.model.whiten(np.ones(fit.model.endog.shape)*fit.model.endog.mean()))**2).sum()
    total_r_square = 1 - ((wresid - wresid.mean())**2).sum() / ((y - y.mean())**2).sum()

    tp = np.sum(y>0)
    # if tp != len(y):
    #     print('t transpose and endog > 0 length mismatch - see sas documenation on handling')
    #mape = np.sum(np.abs( e/self.endog ))/tp * 100

    llf = fit.llf
    ny = fit.model.nobs
    k = fit.model.df_model

    aic = -2*llf + 2*k;   aicc = aic + 2*k*(k+1)/(ny-k-1)
    sbc = -2*llf + np.log(ny)*k  # aka BIC
    hqc = -2*llf + 2*np.log(np.log(ny))*k
    idx = list(['sse', 'mse', 'mae','mape','llf','aic','aicc','bic/sbc','hqc', 'regress r-square', 'total r-square'])
    idx = [element.upper() for element in idx]
    vals = np.round([fit.ssr, fit.ssr / fit.df_resid, mae,mape,llf, aic, aicc, sbc, hqc,regress_r_square, total_r_square],8)
    sasstat = pd.DataFrame(vals, index=idx, columns=['SAS Proc Autoreg stats'])
    data = [ ("sse",fit.ssr , "log-likelihood", llf ),
        ("mse", fit.ssr / fit.df_resid, "root mse", np.sqrt(fit.ssr / fit.df_resid)),
        ("sbc", sbc,"aic", aic),
        ("mae",mae, "aicc", aicc),
        ("mape", mape, "hqc", hqc),
        ("regress r-square",regress_r_square, "total r-square", total_r_square)
        ]
    tbl = SimpleTable(data, ["Statistic", "Value", "Statistic", "Value"], title="SAS Proc Autoreg Fit Statistics")
    sasstat = pd.DataFrame(vals, index=idx, columns=['SAS Proc Autoreg stats'])
    return tbl


def stattests(fit, lags=10, figsize=(8,4), white_hetero_source = None, bp_hetero_source = None):
    """
    SP recommends avoiding ljung-box.
    Statistical Tests for the FNB GLSAR method.
    Heteroskedasticity: White's Test, Breusch Pagan, Goldfeld Quandt
    Auto-Correlation: Breusch Godfrey
    Normality: Jarque(Yogi)-Berra
    """
    resid = fit.wresid
    x = fit.model.wexog
    y = fit.model.wendog

    fitC = copy.deepcopy(fit)
    fitC.resid = resid.copy()

    ##========== Jarque Bera Test ===============================
    jb = sms.stattools.jarque_bera(resid)
    jb = SimpleTable([jb], ['Statistics', 'Chi^2 two-tail prob.', 'Skew', 'Kurtosis'], title="Jarque-Bera Test")

    ##==========Breusch Godfrey Test=============================
    bg = []
    for i in range(1,lags+1):
        bgt = sma.stats.diagnostic.acorr_breusch_godfrey(fitC, i)
        bg.append([i,bgt[0],bgt[1]])
    bg = SimpleTable(bg, ['Lag','Stat','PVal'], title="Breusch-Godfrey Test")

    ##===========White Test =====================================
    ## use non-whitened data for white test.
    if white_hetero_source == None:
        hetW = sms.diagnostic.het_white(resid, exog=sma.add_constant(fit.model.wexog))
    else:
        hetW = sms.diagnostic.het_white(resid, exog= sma.add_constant(fit.model.whiten(fit.model.data.orig_exog[white_hetero_source])))
    hetW = SimpleTable([hetW],['LM','LM pval','Ftest','F pval'], title = "White Test")

    ##===========Breusch Pagan Test =============================
    ## bp is using no whitened data.
    if bp_hetero_source == None:
        hetBP = sms.diagnostic.het_breuschpagan(resid, exog_het=sma.add_constant(fit.model.wexog))
    else:
        hetBP = sms.diagnostic.het_breuschpagan(resid, exog_het=sma.add_constant(fit.model.whiten(fit.model.data.orig_exog[bp_hetero_source])))
    hetBP = SimpleTable([hetBP],['LM','LM pval','Ftest','F pval'], title = ' Breusch-Pagan Test')

    ##============Goldfeld Quandt Test ==========================
    # gfq = sms.diagnostic.HetGoldfeldQuandt().run(y=np.array(y), x=np.array(x), idx=None,
    #                                        alternative='two-sided')

    ## py 3.9 statsmodels 0.14 update
    gfq = sms.diagnostic.het_goldfeldquandt(y=np.array(y), x=np.array(x), idx=None,
                                            alternative='two-sided')

    gfqa = np.array([np.round(gfq[0],5),np.round(gfq[1],5),gfq[2]],ndmin=2)
    gfq = SimpleTable(gfqa, ['fval','pval','ordering'], title='Goldfeld-Quandt Test')
    # tbls = [jb,bg,gfq,hetW,hetBP]
    tbls = [jb,bg,hetW,hetBP]

    print(jb,"\n")
    print(bg,"\n")
    print(hetW)
    print("Heteroskedasticity source:", ",".join(fit.model.data.xnames) if (white_hetero_source==None) else ",".join(bp_hetero_source), "\n")

    print(hetBP)
    print("Heteroskedasticity source:", ",".join(fit.model.data.xnames) if (bp_hetero_source==None) else",".join(bp_hetero_source))

    if lags < 20:
        acpl = 20
    else:
        acpl = lags
    figS, axS = subplots(1,2,figsize=figsize)
    smg.tsaplots.plot_acf(fit.wresid, lags=acpl, ax=axS[0])
    smg.tsaplots.plot_pacf(fit.wresid, lags=acpl, ax=axS[1])
    return tbls


#%%
### END
