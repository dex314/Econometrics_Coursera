import pandas as pd
from pandas import DataFrame, Series
import numpy as np

import seaborn as sns
import matplotlib.pyplot as plt

import scipy
from scipy.stats import nct, norm
import statsmodels.api as sma
from sklearn.metrics import mean_squared_error

import os
import re

'''
===============================================================================
'''
def mvt(mu,Sigma,N,M):
    '''
    Output:
    Produce M samples of d-dimensional multivariate t distribution
    Input:
    mu = mean (d dimensional numpy array or scalar)
    Sigma = scale matrix (dxd numpy array)
    N = degrees of freedom
    M = # of samples to produce
    '''
    d = len(Sigma)
    g = np.tile(np.random.gamma(N/2.,2./N,M),(d,1)).T
    Z = np.random.multivariate_normal(np.zeros(d),Sigma,M)
    return mu + Z/np.sqrt(g)

class ModelSensitivity:
    """
    Method used to perform sensitivity analysis on a
    set of parameters and an assumed covariance matriex.
    """

    def __init__(self, b, cov, df=3, n_simuls=5000, labels=None):
        self.labels = labels
        self.b = b
        self.cov = cov
        self.df = df
        self.n_simuls = n_simuls

    def analyze(self, plot = False):
        nct_dist = nct(self.df, nc=0,loc=self.b, scale = np.sqrt( np.diag(self.cov)))
        norm_dist = norm(loc=self.b, scale=np.sqrt( np.diag(self.cov)))
        t_samp = mvt( mu = self.b, Sigma = self.cov, N=self.df, M=self.n_simuls)
        unif = DataFrame(nct_dist.cdf(t_samp))
        norm_samp = DataFrame(norm_dist.ppf(unif))
        norm_samp.columns = self.labels
        if plot:
#             sns.set(style="white")
            norm_samp.columns = self.labels
            g = sns.PairGrid(norm_samp, diag_sharey=False)
            g.map_lower(sns.kdeplot, cmap="Blues_d")
            g.map_upper(plt.scatter)
            g.map_diag(sns.kdeplot, lw=3)
        return DataFrame(norm_samp)


'''
==============================================================================
Leverage Point Analysis
'''
def leverage_analysis(ols, plot_points=True, figsize=(15,12), fontsize=12, figsave=None):
    '''pass an ols model to this function for automated leverage point analysis'''
    # ols = sma.OLS(endog = lny.diff().dropna(), exog = sma.add_constant(mcf[newVars])[1::]).fit()
    # print(ols.summary(yname="d ln balance"))
    infl = ols.get_influence() ## get the influence
    olsidx = ols.model.data.row_labels ## get the indices
    labels =[str(i)[:10] for i in olsidx] ## labels
    dffits = pd.DataFrame(infl.dffits[0], index=labels) ## calculates df-fits
    dfbetas = pd.DataFrame(infl.dfbeta, index=labels) ## calculate df-betas

    residues = ols.resid #.as_matrix() #residuals
    leviers = infl.hat_matrix_diag #leverage
    sigma_err = np.sqrt(ols.scale) #regression standard error
    res_stds = residues/(sigma_err*np.sqrt(1.0-leviers)) ## studentized resids

    seuil_levier = 2*(ols.model.df_model + 1)/ols.model.df_resid
    atyp_levier = pd.DataFrame(leviers > seuil_levier, columns = ['atyp'], index=ols.model.data.row_labels)
    seuil_stud = scipy.stats.t.ppf(0.975, df=ols.model.df_resid-ols.model.df_model-2)
    atyp_stud = np.abs(res_stds) > seuil_stud
    atyp_stud_filt = atyp_stud[atyp_stud == True].dropna()

    lev_summary = infl.summary_frame().filter(["hat_diag","student_resid","dffits","cooks_d"])

    ## concanate outliers and leverage for one plot
    atyp_sdf = pd.DataFrame(np.where(atyp_stud == True, 'outlier', ''), columns=['outliers'])
    atyp_ldf = pd.DataFrame(np.where(atyp_levier == True, 'leverage', ''), columns=['leverage'])
    atyp_comb = pd.concat([atyp_sdf, atyp_ldf], axis=1)
    atyp_comb.index = olsidx
    atyp_comb['comb'] = atyp_comb.sum(axis=1).replace('','observation')\
                        .replace('outlierleverage','outlier & leverage')
    ## plot summary
    plotsumm = pd.concat([pd.DataFrame(leviers, index=olsidx,
                                       columns=['leverage']),
                          pd.DataFrame(infl.resid_studentized, index=olsidx,
                                       columns=['resid_std']),
                          atyp_comb['comb']], axis=1)

    if plot_points == True:
        fig, ax=plt.subplots(2,1,figsize=figsize)
        # sma.graphics.influence_plot(ols, ax=ax[0]);
        sns.scatterplot(x=plotsumm.leverage, y=plotsumm.resid_std,
                        hue=plotsumm['comb'].tolist(), ax=ax[0]);
                        ## the to_list() command handles an sns error
        ax[0].axvline(seuil_levier.mean(), c='k', alpha=0.5)
        ax[0].axhline(seuil_stud.mean(), c='k', alpha=0.5)
        ax[0].set_title("Influence Plot");
        ax[0].set_ylabel("Studentized Resid")
        for i in plotsumm[plotsumm.comb != 'observation'].index:
            xitem = plotsumm['leverage'].loc[i]
            yitem = plotsumm['resid_std'].loc[i]
            ax[0].annotate(str(i)[:11], # this is the text
                         (xitem,yitem), # this is the point to label
                         textcoords="offset points", # how to position the text
                         xytext=(0,10), # distance from text to points (x,y)
                         ha='center', fontsize=fontsize)
        ax[1].axhline(0,c='k', ls='-', alpha=0.5)
        dffits.plot(ax=ax[1]);
        ax[1].set_xlabel("Observations");
        ax[1].set_ylabel("DFFITS");
        ax[1].legend(['dffits']);
        ax[1].set_title("Influence Diagnostics for Residual");
        ax[1].tick_params(axis='x', rotation=45);
        plt.tight_layout();
        if figsave is not None:
            plt.savefig(figsave)

    return plotsumm, lev_summary, infl
