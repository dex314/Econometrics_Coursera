
import pandas as pd
from pandas import Series, DataFrame
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from pyfnb import *
from tqdm import tqdm

def decile_and_lift(preds, actuals, baseline=None, duplicates='drop'):
    ''' Deciling and Lift Function
        preds = prediction probabilites, must be a 1D Array of values matching length with actuals
        actuals = actual instances (0,1), must be pandas DF with matching index to preds
        baseline = baseline score, usually y.mean()
        Returns Decile DataFrame, Pred DataFrame
        May not return exactly 10 buckets!
    '''
    if baseline is None:
        baseline = actuals.mean()
    deciles = pd.qcut(preds, q=10, labels=False, duplicates='drop') ## deciling takes 1D array
    preds_df = pd.DataFrame(preds.reshape(-1,1),
                            index=actuals.index,
                            columns=['preds']) ## actuals index should match
    preds_df['actuals'] = actuals.values
    preds_df['decile'] = deciles
    dec_df = preds_df.groupby('decile').agg(['min', 'max', 'mean', 'count']) ##aggregation
    try:
        dec_df.index = range(10, 0, -1) ## resets index
    except:
        print("Did not reach 10 buckets, max reached = {}".format(len(dec_df)))
        dec_df.index = range(len(dec_df), 0, -1) ## resets index
    dec_df.columns = ['_'.join(col).strip() for col in dec_df.columns.values]
    dec_df2 = dec_df[['preds_min', 'preds_max', 'actuals_mean', 'preds_count']]
    dec_df2.columns = ['decile_min', 'decile_max', 'decile_avg', 'count']
    dec_df2['baseline'] = baseline
    dec_df2['lift'] = dec_df2['decile_avg'] / baseline
    return dec_df2.sort_index(), preds_df
