import pandas as pd
from pandas import DataFrame, Series
import numpy as np

import scipy as sp
import scipy.stats.stats as stats
import scipy.stats as sps
from scipy.stats import norm, chisquare, trim_mean
from sklearn.utils import resample
from sklearn.metrics import mean_squared_error
import statsmodels.api as sma

from pyfnb import *
from pyfnb import tweedie_dist

from matplotlib import colors, cm
import matplotlib.pyplot as plt
import seaborn as sns

import itertools
import pickle as cPickle
import os
import sys

## METAFRAME CLASS ===========================================================
class MetaFrame(DataFrame):
    """ wrapper for Pandas.DataFrame.  a method for meta data.
        see help(DataFrame) for all constructor parameters except meta_data.
        meta_data will be used to store info concerning the DataFrame.  the
        intended us was a dictionary with key = field, and value = info on the field.

        example
        -------
        >>>>> mdf = MetaFrame([1,2,3,4], columns=["field 1"], meta_data = dict([("field 1", "array of intergers")]))
        >>>>> mdf.meta_data
    """
    def __init__(self, data=None, meta_data = None, index=None, columns=None, dtype=None,copy=False):
        super().__init__(data, index, columns, dtype,copy)
        self.meta_data = meta_data
    def to_pickle(self, f= "pkl"):
        """pickles MetaFrame.
           parameters
           ----------
           f = the directory in which the pickles will be places
           This directory should NOT exists.  If it does, you will be advised
           to delete the directory.  No overwrite by default was chosen as a
           safety precaution.
           The method pickles both DataFrame and meta data in seperate pkl files in
           the specified directory.
           """
        if os.path.exists(f):
            print(f + " exists.  delete the directory and try again")
        else:
            os.mkdir(f)
            with open(f + "/data.pkl", 'wb') as df:
                super().to_pickle(df)
            with open(f + "/meta.pkl", "wb") as dfm:
                cPickle.dump(self.meta_data, dfm)


'''
LOOSE FUNCTIONS ===============================================================
'''
def pimped_pickle_write(model,string):
    """write models to pkl file"""
    with open(string, 'wb') as f:
        obj = cPickle.dump(model, f)
    return(obj)


def pimped_pickle_read(string):
    '''read models from pkl file'''
    with open(string, 'rb') as f:
        obj = cPickle.load(f)
    return(obj)


def pimped_wape_write(insample_wape, backtest_wape, fileo):
    '''write WAPE for backtesting in documentation'''
    f = open(fileo,'w')
    f.write(str(insample_wape)+'\n'+str(backtest_wape))
    f.close()


def pimped_wape_read(infile):
    '''read WAPE for backtesting in documentation'''
    f = open(infile, "r")
    w = list(map( lambda x: float( x.strip("\n")), f.readlines()))
    return w


def zip_historicals_and_forecast_2018(hist, forecast, last_hist_date='2018-07-01'):
    ''' Zip Historicals and FOrecasts for data consistency.
        THe last_hist_date is best when its AT LEAST one month previous to current FNB data date.
    '''
    forecast_temp = forecast.copy()
    for hist_name, forecast_name in zip(hist.columns, forecast.columns):
        null_index = hist[hist_name].isnull()
        null_index = null_index[null_index == False].loc[np.min(forecast.index):np.max(forecast.index)].index
        forecast[forecast_name].loc[null_index] = hist[hist_name].loc[null_index]
        forecast.meta_data[forecast_name]["note"] = "data from historical basket through {}, scenario basket data thereafter".format(
            hist.meta_data[hist_name]["endDate"]
        )
    miss_level_list = ['FGDP$.IUSA', 'FGDP.IUSA', 'FYPDPI$Q.IUSA', 'FYPDPIQ.IUSA', 'FCD$.IUSA',
                       'FC$.IUSA', 'FCD.IUSA', 'FC.IUSA', 'FYPSVQ.IUSA', 'FYPEPPNFQ.IUSA', 'FCS$.IUSA',
                       'FCS.IUSA']
    start_date = pd.to_datetime(last_hist_date) - pd.DateOffset(months=1)
    ## level it out
    forecast.loc[:last_hist_date][miss_level_list] = forecast.loc[:last_hist_date][miss_level_list]/1000
    ## replace with cf
    forecast.loc[start_date:][miss_level_list] = forecast_temp.loc[start_date:][miss_level_list]
    return forecast


def zip_historicals_and_forecast_2022(hist, forecast, last_hist_date='2018-07-01'):
    ''' Zip Historicals and FOrecasts for data consistency.
        THe last_hist_date is best when its AT LEAST one month previous to current FNB data date.
    '''
    forecast_temp = forecast.copy()
    for hist_name, forecast_name in zip(hist.columns, forecast.columns):
        null_index = hist[hist_name].isnull()
        null_index = null_index[null_index == False].loc[np.min(forecast.index):np.max(forecast.index)].index
        forecast[forecast_name].loc[null_index] = hist[hist_name].loc[null_index]
        forecast.meta_data[forecast_name]["note"] = "data from historical basket through {}, scenario basket data thereafter".format(
            hist.meta_data[hist_name]["endDate"]
        )
    miss_level_list = ['FGDP$.IUSA', 'FGDP.IUSA', 'FYPDPI$Q.IUSA', 'FYPDPIQ.IUSA', 'FCD$.IUSA',
                       'FC$.IUSA', 'FCD.IUSA', 'FC.IUSA', 'FYPSVQ.IUSA', 'FYPEPPNFQ.IUSA', 'FCS$.IUSA',
                       'FCS.IUSA',
                      ## new 10/24/2022 ?
                       'FGFB.IUSA','FHN1.IUSA','FHN1MED.IUSA',
                       'FRTFS.IUSA','FRVEHL.IUSA', # special cases
                      ]
    zipdict = dict(zip(forecast.columns, hist.columns))
    for m in miss_level_list:
        if m == 'FRTFS.IUSA' or m == 'FRVEHL.IUSA':
            new_hist = hist[zipdict[m]].dropna()/100
        else:
            new_hist = hist[zipdict[m]].dropna()/1000

        last_idx = new_hist.index[-1]
        start_date = pd.to_datetime(last_idx) + pd.DateOffset(months=1)
        new_forecast = pd.concat([new_hist,
                                  forecast[m].loc[start_date:]], axis=0)
        forecast[m] = new_forecast
    return forecast


def zip_hist_and_forc(hist, forecast, last_hist_date='2018-07-01'):
    ''' Zip Historicals and FOrecasts for data consistency.
        THe last_hist_date is best when its AT LEAST one month previous to current FNB data date.
        For the NEW Moodys naming conventions!
    '''
    forecast_temp = forecast.copy()
    for hist_name, forecast_name in zip(hist.columns, forecast.columns):
        null_index = hist[hist_name].isnull()
        null_index = null_index[null_index == False].loc[np.min(forecast.index):np.max(forecast.index)].index
        forecast[forecast_name].loc[null_index] = hist[hist_name].loc[null_index]
        forecast.meta_data[forecast_name]["note"] = "data from historical basket through {}, scenario basket data thereafter".format(
            hist.meta_data[hist_name]["endDate"]
        )
    miss_level_list = ['GDP_DMM_Real_2012','GDP_DMM','DPI_DMM_Real_2012','DPI_DMM','PCE_DG_DMM_Real_2012',
                        'PCE_DMM_Real_2012','PCE_DG_DMM','PCE_DMM','Pers_Saving_DMM','Pers_Inc_Nonfarm_DMM',
                        'PCE_Serv_DMM_Real_2012','PCE_Serv_DMM']
    start_date = pd.to_datetime(last_hist_date) - pd.DateOffset(months=1)
    ## level it out
    forecast.loc[:last_hist_date][miss_level_list] = forecast.loc[:last_hist_date][miss_level_list]/1000
    ## replace with cf
    forecast.loc[start_date:][miss_level_list] = forecast_temp.loc[start_date:][miss_level_list]
    return forecast


def zip_historicals_and_forecast(hist, forecast):
    '''zips historical and forecast moodys data'''
    for hist_name, forecast_name in zip(hist.columns, forecast.columns):
        null_index = hist[hist_name].isnull()
        null_index = null_index[null_index == False].loc[np.min(forecast.index):np.max(forecast.index)].index
        forecast[forecast_name].loc[null_index] = hist[hist_name].loc[null_index]
        forecast.meta_data[forecast_name]["note"] = "data from historical basket through {}, scenario basket data thereafter".format(
            hist.meta_data[hist_name]["endDate"]
        )
    return forecast


def getData(path = "../../data/moodys-cf", verbose=False, comm=True, lags=12,
            hist_path=None, last_hist_date='2012-12-01'):
    '''
    Pulls in the appropriate macro data based on whether the portoflio is commercial or
    consumer. Also can attach historicals which is set to True for default.
    '''
    macro_df = read_MetaFrame_pickle(path)
    meta = macro_df.meta_data
    scenario = path.split('/')[-1]#This is added to know the COVID scenarios from the folder path
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    if hist_path is not None:
        # ## this works as long as historicals is in the same place as meta
        # pth = hist_path.split('data')[0]+'data/historical/'
        hist = read_MetaFrame_pickle(hist_path)
        print("history successfully imported")
        # macro_df = zip_historicals_and_forecast_2018(hist, macro_df, last_hist_date=last_hist_date)
        macro_df = zip_historicals_and_forecast_2022(hist, macro_df, last_hist_date=last_hist_date)
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    macro_df["date"] = pd.to_datetime(macro_df.index + pd.offsets.MonthBegin(-1))
    macro_df.set_index("date", inplace = True, drop=True)

    if comm == True:
        '''
        Moodys data error update(For the variable "FCRNCPPITUQ.IUSA" - description was missing) - 8/4/2020 - All the commented code below are the original code.
        "FCRNCPPITUQ.IUSA" variable was removed since it was not used in any of the models.
        '''
        x = MetaFrame(
        macro_df[["FGDP$.IUSA", "FRTB3MEBY.IUSA", "FC$.IUSA", "FCBC.IUSA", "FCPIU.IUSA", "FLBR.IUSA","FSP500Q.IUSA", "FDJMIIUSDDWCFTDQ.IUSA", "FSPVOL.IUSA",
                    ## additional items below added by WES 12.10.2020
                  "FUNI.IUSA", "FCD$.IUSA", "FYPEPPNFQ.IUSA", "FBKB.IUSA", "FBKBY.IUSA", "FBKP.IUSA", "FBKPY.IUSA",# "FCPPIQ.IUSA",
                  'FHVACRQ.IUSA', 'FRTFS.IUSA', 'FYPDPI$Q.IUSA',
                  'FZFL075035503Q.IUSA','FHCF$.IUSA','FEIAMGTTQ.IUSA',
                    ## moodys var change updates
                  'FCREPIQ.IUSA', 'FCREPAPTIQ.IUSA', 'FCREPCOMIQ.IUSA', 'FCREPOFFIQ.IUSA',
                  'FCREPRETIQ.IUSA', 'FCREPINDIQ.IUSA', 'FCREPHWRIQ.IUSA', 'FCREPHOTIQ.IUSA'
                  ]],meta)
            ## commerical variable transformations
        ln_vars = ["FGDP$.IUSA","FCPIU.IUSA",'FSP500Q.IUSA', 'FDJMIIUSDDWCFTDQ.IUSA', "FUNI.IUSA", "FCD$.IUSA", "FYPEPPNFQ.IUSA",
                   "FCBC.IUSA",
                    "FBKB.IUSA", "FBKBY.IUSA", "FBKP.IUSA", "FBKPY.IUSA",# "FCPPIQ.IUSA",
                    'FRTFS.IUSA', 'FYPDPI$Q.IUSA','FZFL075035503Q.IUSA','FHCF$.IUSA',
                   'FEIAMGTTQ.IUSA',
                   'FCREPIQ.IUSA', 'FCREPAPTIQ.IUSA', 'FCREPCOMIQ.IUSA', 'FCREPOFFIQ.IUSA',
                   'FCREPRETIQ.IUSA', 'FCREPINDIQ.IUSA', 'FCREPHWRIQ.IUSA', 'FCREPHOTIQ.IUSA'
                  ]
        diff_log_level = [ "D_LN_{}".format(i) for i in ln_vars]
        diff_level = [ "D_{}".format(i) for i in ["FRTB3MEBY.IUSA","FC$.IUSA",# "FCBC.IUSA",
                                                    "FLBR.IUSA", 'FHVACRQ.IUSA', 'FZFL075035503Q.IUSA' ]]
        level = ["FSPVOL.IUSA"]
        x = logMf(x, names=ln_vars)
        x = diff(x)
        meta = x.meta_data
        if verbose == True:
            for v in x.columns:
                print(v," => ", x.meta_data[v]["description"], "\n")

        variables = diff_log_level
        variables.extend(diff_level)
        variables.extend(level)
        x = x[variables]

    else:
        x = MetaFrame(macro_df[["FGDP$.IUSA", "FRTB3MEBY.IUSA", "FC$.IUSA", "FCBC.IUSA", "FCPIU.IUSA", "FLBR.IUSA", "FHOFHOPIPOQ.IUSA",
                      ## additional items below added by WES 12.10.2020
                      "FBKP.IUSA", "FBKPY.IUSA", "FUNI.IUSA", 'FRTFS.IUSA', 'FYPDPI$Q.IUSA',
                      'FAHETTPQ.IUSA', 'FYPSVQ.IUSA', 'FYPEPPNFQ.IUSA','FRFHLMCFM.IUSA','FHXAFF.IUSA','FEIAMGTTQ.IUSA']], meta)
        ## consumer variable transformations
        ln_vars = ["FGDP$.IUSA", "FCPIU.IUSA", "FHOFHOPIPOQ.IUSA", "FBKP.IUSA", "FBKPY.IUSA", "FUNI.IUSA", 'FRTFS.IUSA', "FCBC.IUSA",
                    'FYPDPI$Q.IUSA', 'FAHETTPQ.IUSA', 'FYPSVQ.IUSA', 'FYPEPPNFQ.IUSA','FHXAFF.IUSA','FEIAMGTTQ.IUSA']
        diff_log_level = [ "D_LN_{}".format(i) for i in ln_vars]
        diff_level = [ "D_{}".format(i) for i in ["FRTB3MEBY.IUSA","FC$.IUSA",# "FCBC.IUSA",
                                                    "FLBR.IUSA",'FRFHLMCFM.IUSA']]
        x = logMf(x, names=ln_vars)
        x = diff(x)
        meta = x.meta_data
        if verbose == True:
            for v in x.columns:
                print(v," => ", x.meta_data[v]["description"], "\n")

        variables = diff_log_level
        variables.extend(diff_level)
        x = x[variables]

    x = MetaFrame(x, meta)
    xl = lagMf(x, lags=lags)
    return(xl)


def getData_specific(path = "../../data/moodys-cf", verbose=False, lags=12,
                     d_vars = None, ln_vars = None, ## these will be differenced
                     level_vars = None, hist_path=None, last_hist_date='2012-12-01'):
    '''
    Pulls in SPECIFIC macro data based on the users decision.
    Also can attach historicals which is set to True for default.
    '''
    macro_df = read_MetaFrame_pickle(path)
    meta = macro_df.meta_data
    scenario = path.split('/')[-1] #This is added to know the COVID scenarios from the folder path
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    if hist_path is not None:
        # ## this works as long as historicals is in the same place as meta
        hist = read_MetaFrame_pickle(hist_path)
        print("history successfully imported")
        # macro_df = zip_historicals_and_forecast_2018(hist, macro_df, last_hist_date=last_hist_date)
        macro_df = zip_historicals_and_forecast_2022(hist, macro_df, last_hist_date=last_hist_date)
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    macro_df["date"] = pd.to_datetime(macro_df.index + pd.offsets.MonthBegin(-1))
    macro_df.set_index("date", inplace = True, drop=True)

    x = MetaFrame(macro_df, meta)
    if ln_vars is not None:
        diff_log_level = [ "D_LN_{}".format(i) for i in ln_vars]
    if d_vars is not None:
        diff_level = [ "D_{}".format(i) for i in d_vars]
    if level_vars is not None:
        level = [i for i in level_vars]

    x = logMf(x, names=ln_vars)
    x = diff(x)
    meta = x.meta_data
    if verbose == True:
        for v in x.columns:
            print(v," => ", x.meta_data[v]["description"], "\n")

    if ln_vars is not None:
        variables = diff_log_level
    else: ## instantiate an empty list if no ln_vars
        variables = []
    if d_vars is not None:
        variables.extend(diff_level)
    if level_vars is not None:
        variables.extend(level)
    x = x[variables]

    x = MetaFrame(x, meta)
    xl = lagMf(x, lags=lags)
    return(xl)


def getData_all(path="../../data/moodys-cf", verbose=False, lags=12, hist_path=None,
                last_hist_date='2012-12-01',
                dev=False):
    '''
    Pulls in ALL macro data based on how Moodys data sets are built.
    Also can attach historicals which is set to True for default.
    '''
    macro_df = read_MetaFrame_pickle(path)
    meta = macro_df.meta_data
    scenario = path.split('/')[-1]#This is added to know the COVID scenarios from the folder path
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    if hist_path is not None:
        # ## this works as long as historicals is in the same place as meta
        # pth = hist_path.split('data')[0]+'data/historical/'
        hist = read_MetaFrame_pickle(hist_path)
        print("history successfully imported")
        # macro_df = zip_historicals_and_forecast_2018(hist, macro_df, last_hist_date=last_hist_date)
        macro_df = zip_historicals_and_forecast_2022(hist, macro_df, last_hist_date=last_hist_date)
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    macro_df["date"] = pd.to_datetime(macro_df.index + pd.offsets.MonthBegin(-1))
    macro_df.set_index("date", inplace = True, drop=True)

    dln_vars = ['FAHETTPQ.IUSA', 'FBKB.IUSA', 'FBKBY.IUSA', 'FBKP.IUSA', 'FBKPY.IUSA', 'FC$.IUSA', 'FCBC.IUSA', 'FCD$.IUSA', 'FCPIU.IUSA', #'FCPPIQ.IUSA',
               'FDJMIIUSDDWCFTDQ.IUSA', 'FGDP.IUSA', 'FGDP$.IUSA', 'FHCF$.IUSA', 'FHOFHOPIPOQ.IUSA', 'FHVACRQ.IUSA', 'FHXAFF.IUSA', 'FLBR.IUSA', 'FRFHLMCFM.IUSA',
               'FRTB3MEBY.IUSA', 'FRTFS.IUSA', 'FSP500Q.IUSA', 'FSPVOL.IUSA', 'FUNI.IUSA', 'FYPDPIQ.IUSA', 'FYPDPI$Q.IUSA', 'FYPEPPNFQ.IUSA',
               'FYPSVQ.IUSA', 'FZFL075035503Q.IUSA', #'FCPPCOMIQ.IUSA',
               'FHCLHP1TI20Q.IUSA', 'FHOFHOPIQ.IUSA', 'FCD.IUSA',
               'FIRBAACI7Q.IUSA', 'FRGT5Y.IUSA', 'FRGT10Y.IUSA',
               'FCREPIQ.IUSA', 'FCREPAPTIQ.IUSA', 'FCREPCOMIQ.IUSA', 'FCREPOFFIQ.IUSA',
               'FCREPRETIQ.IUSA', 'FCREPINDIQ.IUSA', 'FCREPHWRIQ.IUSA', 'FCREPHOTIQ.IUSA',
               'FEIAMGTTQ.IUSA','FCPGASQ.IUSA','FRVEHL.IUSA'
               ]

    ln_vars = ['FAHETTPQ.IUSA', 'FBKB.IUSA', 'FBKBY.IUSA', 'FBKP.IUSA', 'FBKPY.IUSA', 'FCD$.IUSA', 'FCPIU.IUSA', #'FCPPIQ.IUSA',
               'FDJMIIUSDDWCFTDQ.IUSA', 'FCBC.IUSA',
               'FGDP.IUSA', 'FGDP$.IUSA', 'FHCF$.IUSA', 'FHOFHOPIPOQ.IUSA', 'FHXAFF.IUSA', 'FRTFS.IUSA', 'FSP500Q.IUSA', 'FUNI.IUSA', 'FYPDPIQ.IUSA',
               'FYPDPI$Q.IUSA', 'FYPEPPNFQ.IUSA', #'FCPPCOMIQ.IUSA',
               'FHCLHP1TI20Q.IUSA', 'FHOFHOPIQ.IUSA', 'FCD.IUSA',
               'FYPSVQ.IUSA', 'FZFL075035503Q.IUSA',
               'FCREPIQ.IUSA', 'FCREPAPTIQ.IUSA', 'FCREPCOMIQ.IUSA', 'FCREPOFFIQ.IUSA',
               'FCREPRETIQ.IUSA', 'FCREPINDIQ.IUSA', 'FCREPHWRIQ.IUSA', 'FCREPHOTIQ.IUSA',
               'FEIAMGTTQ.IUSA','FCPGASQ.IUSA','FRVEHL.IUSA'
              ]

    d_vars = ["FRTB3MEBY.IUSA", "FC$.IUSA", #"FCBC.IUSA",
              "FLBR.IUSA", 'FHVACRQ.IUSA', 'FZFL075035503Q.IUSA','FRFHLMCFM.IUSA','FIRBAACI7Q.IUSA',
              'FRGT5Y.IUSA', 'FRGT10Y.IUSA',
             ]
    ## instantiate
    x = MetaFrame(macro_df[dln_vars],meta)
    diff_log_level = [ "D_LN_{}".format(i) for i in ln_vars]
    diff_level = [ "D_{}".format(i) for i in d_vars]
    level = ["FSPVOL.IUSA",'FRGT5Y.IUSA', 'FRGT10Y.IUSA','FRFHLMCFM.IUSA'] #,'FCBC.IUSA',]
    x = logMf(x, names=ln_vars)
    x = diff(x)
    meta = x.meta_data
    if verbose == True:
        for v in x.columns:
            print(v," => ", x.meta_data[v]["description"], "\n")

    variables = diff_log_level
    variables.extend(diff_level)
    variables.extend(level)
    x = x[variables]

    ## old correction
    x['D_LN_FRTFS.IUSA'].loc['2018-09-01'] = (x['D_LN_FRTFS.IUSA'].loc['2018-08-01']+x['D_LN_FRTFS.IUSA'].loc['2018-10-01'])/2.0

    ## engineered variables
    x['GDP_Inflation'] = (1.0 + x['D_LN_FGDP$.IUSA'])/(1.0 + x['D_LN_FGDP.IUSA']) - 1.0
    x['DowJonesRiskPremium'] = x['D_LN_FDJMIIUSDDWCFTDQ.IUSA']/100 - x['FRGT10Y.IUSA']
    x['RealDowJonesGrowthRate'] = x['D_LN_FDJMIIUSDDWCFTDQ.IUSA']/100 - x['D_LN_FCPIU.IUSA']
    x['MortgageRiskPremium'] = x['FRFHLMCFM.IUSA'] - x['FRGT10Y.IUSA']
    x['RealCREGrowth'] = x['D_LN_FZFL075035503Q.IUSA'] - x['D_LN_FCPIU.IUSA']

    if dev == False:
        ## acqusition and policy dummies - not for development
        ## useful for re-estimation though
        x['omega'] = np.where(x.index == '2008-05-01', 1, 0)
        x['metro'] = np.where(x.index == '2016-02-01', 1, 0)
        x['yadkin'] = np.where(x.index == '2017-03-01', 1, 0)
        x['policy_change'] = np.where(x.index >= '2017-04-01', 1, 0)
        ## one offs per segment
        x['meanshift_dec19'] = np.where((x.index >= '2019-12-01') & (x.index <= '2020-10-01'), 1, 0)
        x['mean_shift_Feb16_to_Jul18'] = np.where((x.index>='2016-02-01') & (x.index<='2018-07-01'), 1, 0)
        x['mean_shift_062018_to_062020'] = np.where((x.index>='2018-06-01') & (x.index<='2020-06-01'), 1, 0)
        x['shift_dummy_Apr2017_to_Mar2021'] = np.where((x.index>='2017-04-01') & (x.index<='2021-03-01'), 1, 0)


    ## meta data additions
    meta['DowJonesRiskPremium'] = {"derivation": 'D_LN_FDJMIIUSDDWCFTDQ.IUSA - FRGT10Y.IUSA', "description":"Dow Jones Risk Premium"}
    meta['RealDowJonesGrowthRate'] = {"derivation":'D_LN_FDJMIIUSDDWCFTDQ.IUSA - D_LN_FCPIU.IUSA', "description":"Real Dow Jones Growth Rate"}
    meta['MortgageRiskPremium'] = {"derivation":'FRFHLMCFM.IUSA - FRGT10Y.IUSA', "description":"Mortgage risk premium"}
    meta['RealCREGrowth'] = {"derivation":'D_LN_FZFL075035503Q.IUSA - D_LN_FCPIU.IUSA', "description": "Real Commercial Real Estate Growth"}
    meta["GDP_Inflation"] = {"derivation":"(1.0 + D_LN_FGDP$.IUSA)/(1.0 + D_LN_FGDP.IUSA) - 1.0", "description": "Gdp Inflation"}

    if dev == False:
        meta['yadkin'] = {'description':'Yadkin acquisition dummy for March 2017.'}
        meta["omega"] = {"description":"Acquisition of Omega Bank"}
        meta["metro"] = {"description":"Acquisition of Metro Bank"}
        meta["policy_change"] = {"description":"Dummy shift for the policy change post Yadkin for diverting growth and to allow the balance to level off (TF)."}
        meta['meanshift_dec19'] = {'description':'MeanShift starting in Dec2019 to incorporate the hard changes and Sep2020 selloff in Indirect.'}
        meta['mean_shift_Feb16_to_Jul18'] = {"description":"This shift handles unsually high activity from Feb 2016 through July 2018 where a significant number of RBB loans were acquired (TF)."}
        meta['mean_shift_062018_to_062020'] = {"description":"Provides a lift in sudden expected value of defaults due to increase in loans up until selloff in 2020 (TF)."}
        meta['shift_dummy_Apr2017_to_Mar2021'] = {'description':'Shift dummy from April 17 to Mar 21 to catch growth, Yadkin through Pandemic.'}

    xnew = x.copy() ## defragment?
    xnew = MetaFrame(xnew, meta)
    xl = lagMf(xnew, lags=lags)
    return(xl)


def getData_all_new_map(path="../../data/moodys-cf", verbose=False, lags=12, hist_path=None,
                        last_hist_date='2012-12-01',
                        dev=False):
    '''
    Pulls in ALL macro data based on how Moodys data sets are built.
    Also can attach historicals which is set to True for default.
    Uses the new variable mapping names.
    '''
    macro_df = read_MetaFrame_pickle(path)
    meta = macro_df.meta_data
    scenario = path.split('/')[-1]#This is added to know the COVID scenarios from the folder path
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    if hist_path is not None:
        # ## this works as long as historicals is in the same place as meta
        # pth = hist_path.split('data')[0]+'data/historical/'
        hist = read_MetaFrame_pickle(hist_path)
        print("history successfully imported")
        macro_df = zip_hist_and_forc(hist, macro_df, last_hist_date=last_hist_date)
    ##<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    macro_df["date"] = pd.to_datetime(macro_df.index + pd.offsets.MonthBegin(-1))
    macro_df.set_index("date", inplace = True, drop=True)

    dln_vars = ['Avg_Hourly_Earn_DperHr', 'Bankruptcy_Bus_N3mRoll', 'Bankruptcy_Bus_N12mTrail', 'Bankruptcy_Pers_N3mRoll', 'Bankruptcy_Pers_N12mTrail',
                'PCE_DMM_Real_2012', 'CCI_index_1985', 'PCE_DG_DMM_Real_2012', 'CPI_Index_1982', 'Dow_Index_Close', 'GDP_DMM',
                'GDP_DMM_Real_2012', 'HH_CashFlow_DBil_Real_2012', 'HPI_Purch_Index_1991', 'Rental_Vacancy_Pct', 'UnEmp_Pct',
                '30Y_FRM_Pct', '3MT_Pct', 'Retail_Sales_DMM', 'S&P_Index_1941', 'VIX_Index', 'Init_Unemp_Claims_N', 'DPI_DMM', 'DPI_DMM_Real_2012',
                'Pers_Inc_Nonfarm_DMM', 'Pers_Saving_DMM', 'CRE_Index', 'Case_Shiller_Index_2000', 'HPI_SF_Index_1980', 'PCE_DG_DMM',
                'Corp_7Y__Baa_Pct', '5YT_Pct', '10YT_Pct', 'CRE_Index_Total_2002', 'CRE_Index_MF_2002', 'CRE_Index_CML_2002', 'CRE_Index_Office_2002',
                'CRE_Index_Retail_2002', 'CRE_Index_Industry_2002', 'CRE_Index_Warehouse_2002', 'CRE_Index_Hotel_2002',
                'Gas_D_Per_Gal','Nat_Gas_Fut_DperMMBTU','New_Vehicle_Sales_NM'
               ]

    ln_vars = ['Avg_Hourly_Earn_DperHr', 'Bankruptcy_Bus_N3mRoll', 'Bankruptcy_Bus_N12mTrail', 'Bankruptcy_Pers_N3mRoll', 'Bankruptcy_Pers_N12mTrail',
                'CCI_index_1985',
               'PCE_DG_DMM_Real_2012', 'CPI_Index_1982', 'Dow_Index_Close', 'GDP_DMM', 'GDP_DMM_Real_2012', 'HH_CashFlow_DBil_Real_2012',
               'HPI_Purch_Index_1991', 'Retail_Sales_DMM', 'S&P_Index_1941', 'Init_Unemp_Claims_N', 'DPI_DMM', 'DPI_DMM_Real_2012',
               'Pers_Inc_Nonfarm_DMM', 'Case_Shiller_Index_2000', 'HPI_SF_Index_1980', 'PCE_DG_DMM', 'CCI_index_1985', 'Pers_Saving_DMM',
               'CRE_Index', 'CRE_Index_Total_2002', 'CRE_Index_MF_2002', 'CRE_Index_CML_2002', 'CRE_Index_Office_2002', 'CRE_Index_Retail_2002',
               'CRE_Index_Industry_2002', 'CRE_Index_Warehouse_2002', 'CRE_Index_Hotel_2002',
               'Gas_D_Per_Gal','Nat_Gas_Fut_DperMMBTU','New_Vehicle_Sales_NM'
               ]

    d_vars = ['3MT_Pct', 'PCE_DMM_Real_2012',
              #'CCI_index_1985',
              'UnEmp_Pct', 'Rental_Vacancy_Pct', 'CRE_Index', '30Y_FRM_Pct', 'Corp_7Y__Baa_Pct',
              '5YT_Pct', '10YT_Pct'
             ]

    ## instantiate
    x = MetaFrame(macro_df[dln_vars],meta)
    diff_log_level = [ "D_LN_{}".format(i) for i in ln_vars]
    diff_level = [ "D_{}".format(i) for i in d_vars]
    level = ['VIX_Index', '5YT_Pct', '10YT_Pct', '30Y_FRM_Pct'] #, 'CCI_index_1985']
    x = logMf(x, names=ln_vars)
    x = diff(x)
    meta = x.meta_data
    if verbose == True:
        for v in x.columns:
            print(v," => ", x.meta_data[v]["description"], "\n")

    variables = diff_log_level
    variables.extend(diff_level)
    variables.extend(level)
    x = x[variables]

    ## old correction
    x['D_LN_Retail_Sales_DMM'].loc['2018-09-01'] = (x['D_LN_Retail_Sales_DMM'].loc['2018-08-01']+x['D_LN_Retail_Sales_DMM'].loc['2018-10-01'])/2.0

    ## engineered variables
    x['GDP_Inflation'] = (1.0 + x['D_LN_GDP_DMM_Real_2012'])/(1.0 + x['D_LN_GDP_DMM_Real_2012']) - 1.0
    x['DowJonesRiskPremium'] = x['D_LN_Dow_Index_Close']/100 - x['10YT_Pct']
    x['RealDowJonesGrowthRate'] = x['D_LN_Dow_Index_Close']/100 - x['D_LN_CPI_Index_1982']
    x['MortgageRiskPremium'] = x['30Y_FRM_Pct'] - x['10YT_Pct']
    x['RealCREGrowth'] = x['D_LN_CRE_Index'] - x['D_LN_CPI_Index_1982']

    if dev == False:
        ## acqusition and policy dummies - not for development
        ## useful for re-estimation though
        x['omega'] = np.where(x.index == '2008-05-01', 1, 0)
        x['metro'] = np.where(x.index == '2016-02-01', 1, 0)
        x['yadkin'] = np.where(x.index == '2017-03-01', 1, 0)
        x['policy_change'] = np.where(x.index >= '2017-04-01', 1, 0)
        ## one offs per segment
        x['meanshift_dec19'] = np.where((x.index >= '2019-12-01') & (x.index <= '2020-10-01'), 1, 0)
        x['mean_shift_Feb16_to_Jul18'] = np.where((x.index>='2016-02-01') & (x.index<='2018-07-01'), 1, 0)
        x['mean_shift_062018_to_062020'] = np.where((x.index>='2018-06-01') & (x.index<='2020-06-01'), 1, 0)
        x['shift_dummy_Apr2017_to_Mar2021'] = np.where((x.index>='2017-04-01') & (x.index<='2021-03-01'), 1, 0)

    ## meta data additions
    meta['DowJonesRiskPremium'] = {"derivation": 'D_LN_Dow_Index_Close - 10YT_Pct', "description":"Dow Jones Risk Premium"}
    meta['RealDowJonesGrowthRate'] = {"derivation":'D_LN_Dow_Index_Close - D_LN_CPI_Index_1982', "description":"Real Dow Jones Growth Rate"}
    meta['MortgageRiskPremium'] = {"derivation":'30Y_FRM_Pct - 10YT_Pct', "description":"Mortgage risk premium"}
    meta['RealCREGrowth'] = {"derivation":'D_LN_CRE_Index - D_LN_CPI_Index_1982',  "description": "Real Commercial Real Estate Growth"}
    meta["GDP_Inflation"] = {"derivation":"(1.0 + D_LN_GDP_DMM_Real_2012)/(1.0 + D_LN_GDP_DMM_Real_2012) - 1.0", "description": "Gdp Inflation"}

    if dev == False:
        meta['yadkin'] = {'description':'Yadkin acquisition dummy for March 2017.'}
        meta["omega"] = {"description":"Acquisition of Omega Bank"}
        meta["metro"] = {"description":"Acquisition of Metro Bank"}
        meta["policy_change"] = {"description":"Dummy shift for the policy change post Yadkin for diverting growth and to allow the balance to level off (TF)."}
        meta['meanshift_dec19'] = {'description':'MeanShift starting in Dec2019 to incorporate the hard changes and Sep2020 selloff in Indirect.'}
        meta['mean_shift_Feb16_to_Jul18'] = {"description":"This shift handles unsually high activity from Feb 2016 through July 2018 where a significant number of RBB loans were acquired (TF)."}
        meta['mean_shift_062018_to_062020'] = {"description":"Provides a lift in sudden expected value of defaults due to increase in loans up until selloff in 2020 (TF)."}
        meta['shift_dummy_Apr2017_to_Mar2021'] = {'description':'Shift dummy from April 17 to Mar 21 to catch growth, Yadkin through Pandemic.'}

    xnew = x.copy() ## defragment?
    xnew = MetaFrame(xnew, meta)
    xl = lagMf(xnew, lags=lags)
    return(xl)


## METAFRAME FUNCTIONS ========================================================
def read_MetaFrame_pickle(f):
    """ reads in pickled MetaFrame
        adding in a few more lines of comments """
    with open(f + "/data.pkl", 'rb') as df:
        s = pd.read_pickle(df)
    with open(f + "/meta.pkl", "rb") as dfm:
        meta = cPickle.load(dfm)
    return( MetaFrame(s, meta) )


def lagDf(df, lags=1, names = None):
    """ add lags to DataFrame, no inplace unless
    reassigned, e.g. x = lagDf(x)
    df: Pandas.DataFrame -> dataframe of variables to lagDf
    lags: int -> integer representing numbers of lags to add (up to and including)
          list -> specific lags only
          tuple -> must be of length > 1 or else it will be considered an int
    """
    if not (type(df) is pd.core.frame.DataFrame or type(df) is MetaFrame):
        raise Exception("x should be a DataFrame")
    if names == None:
        names = df.columns
    transDf = df.copy()

    ## allows for range or specific lags
    if type(lags) == int:
        lag_range = range(1, lags+1)
    elif type(lags) == list or type(lags) == tuple:
        lag_range = list(lags)
    else:
        raise Exception("lags should be int, list, or tuple")

    for i in lag_range: #range(1, lags+1):
        for name in names:
            t = str(name) + "_L%i" % i
            transDf[t] = transDf[name].shift(i)
    return transDf


def lagMf(mf, lags=1, names = None):
    """ add lags to MetaFrame, no inplace unless
    reassigned, e.g. x = lagDf(x)
    mf: fnbbase.fnb_data.MetaFrame -> MetaFrame of variables to lagDf
    lags: int -> integer representing numbers of lags to add (up to and including)
          list -> specific lags only
          tuple -> must be of length > 1 or else it will be considered an int
    in the meta_data dictionary, lags of order n is denoted L^n
    """
    if not (type(mf) is MetaFrame):
        raise Exception("x should be a MetaFrame")
    mf2 = lagDf(mf, lags=lags, names=names)
    if names == None:
        keys = mf.keys()
    else:
        keys = names
    meta_data = mf.meta_data.copy()

    ## allows for range or specific lags
    if type(lags) == int:
        lag_range = range(1, lags+1)
    elif type(lags) == list or type(lags) == tuple:
        lag_range = list(lags)
    else:
        raise Exception("lags should be int, list, or tuple")

    for i in lag_range: #range(1,lags+1):
        keys2 = list( map( lambda x: x + "_L%d" % i, keys))
        for new_key,old_key in list(zip(keys2,keys)):
            meta_data[new_key] = dict()
            meta_data[new_key]["base_name"] = old_key
            ## handles missing meta data
            if meta_data[old_key]["description"] is not None:
                meta_data[new_key]["description"] = meta_data[old_key]["description"] + " Lag %d" % i
            else:
                meta_data[new_key]["description"] = 'MissingDescription' + " Lag %d" % i
            if "transformation" in meta_data[old_key]:
                meta_data[new_key]["transformation"] = list(itertools.chain(meta_data[old_key]["transformation"], ['lag^%d' % i]))
            else:
                meta_data[new_key]["transformation"] = ['lag^%d' % i]
    return(MetaFrame(mf2, meta_data))


def logMf(mf, names=None):
    """names is an iterable, typically mf.columns"""
    if not (type(mf) is MetaFrame):
        raise Exception("x should be a MetaFrame")
    if names == None:
        names = mf.columns
    new_names = list( map( lambda n: "LN_" + n, names))
    mf2 = mf.copy()
    meta_data = mf.meta_data.copy()
    for n1, n2 in list(zip(new_names, names)):
        mf2[n1] = np.log(mf2[n2])
        meta_data[n1] = dict()
        meta_data[n1]["base_name"] = n2 if meta_data.get(n2).get("base_name")==None else meta_data.get(n2).get("base_name")
        if "transformation" in meta_data[n2]:
            meta_data[n1]["transformation"] = list(itertools.chain(meta_data[n2]["transformation"] , ["log"]))
        else:
            meta_data[n1]["transformation"] = ["log"]
        if meta_data[n2]["description"] is None:
            meta_data[n1]["description"] = "Log " + 'No Description Available - Variable may be discontinued.'
        else:
            meta_data[n1]["description"] = "Log " + meta_data[n2]["description"]
    return(MetaFrame(mf2,meta_data))


def diff(mf, names=None, order=1):
    """
    names is an iterable, typically mf.columns
    order is the total number of differencing applied to the series.
    in the meta_data dictionary, the transformations are denoted diff^order
    """
    if not (type(mf) is MetaFrame):
        raise Exception("x should be a MetaFrame")
    if names == None:
        names = mf.columns
    new_names = list( map( lambda n: "D_" + n, names))
    mf2 = mf.copy()
    meta_data = mf.meta_data.copy()
    for n1, n2 in list(zip(new_names, names)):
        mf2[n1] = mf2[n2].diff(order)
        meta_data[n1] = dict()
        meta_data[n1]["base_name"] = n2 if meta_data.get(n2).get("base_name")==None else meta_data.get(n2).get("base_name")
        if "transformation" in meta_data[n2]:
            meta_data[n1]["transformation"] = list(itertools.chain(meta_data[n2]["transformation"] , ["diff^%d" % order]))
        else:
            meta_data[n1]["transformation"] = ["diff^%d" % order]
        if meta_data[n2]["description"] is None:
            meta_data[n1]["description"] = "%d Difference " % order + 'No Description Available - Variable may be discontinued.'
        else:
            meta_data[n1]["description"] = "%d Difference " % order + meta_data[n2]["description"]
    return(MetaFrame(mf2,meta_data))


def tz_to_naive(datetime_index):
    """ Converts a tz-aware DatetimeIndex into a tz-naive DatetimeIndex,
        effectively baking the timezone into the internal representation.
        Source:
        https://stackoverflow.com/questions/16628819/convert-pandas-timezone-aware-datetimeindex-to-naive-timestamp-but-in-certain-t
        Parameters :  datetime_index : pandas.DatetimeIndex, tz-aware
        Returns :  pandas.DatetimeIndex, tz-naive
    """
    # Calculate timezone offset relative to UTC
    timestamp = datetime_index[0]
    tz_offset = (timestamp.replace(tzinfo=None) -
                 timestamp.tz_convert('UTC').replace(tzinfo=None))
    tz_offset_td64 = np.timedelta64(tz_offset)
    # Now convert to naive DatetimeIndex
    return pd.DatetimeIndex(datetime_index.values + tz_offset_td64)



'''
END
'''
