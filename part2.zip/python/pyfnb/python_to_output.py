import pandas as pd
from pandas import Series, DataFrame
import numpy as np

import scipy as sp
import scipy.stats.stats as stats
import scipy.stats as sps
from scipy.stats import norm, chisquare, trim_mean
from sklearn.utils import resample
from sklearn.metrics import mean_squared_error
import statsmodels.api as sma

from pyfnb import *
from pyfnb import tweedie_dist

from matplotlib import colors, cm
import matplotlib.pyplot as plt
import seaborn as sns

'''
FNB module for moving any models / data to R or SAS for testing purposes.
2022.04.27
'''

def tweedie_rout(y, X, power, path, segment):
    '''Writes an R script for ease of checking to the specified path portion.
       The path already pulls in the current working directory of the notebook.
       Returns the r_data and the script.
    '''
    import os

    cwd = os.getcwd()
    data = pd.concat([y,X],axis=1).dropna()
    data.to_csv(cwd+path+'/r_data.csv', index=True)

    y_name = data.columns[0]

    script = '''
        Packages <- c("tweedie", "statmod", "lmtest", "sandwich")
        lapply(Packages, library, character.only = TRUE)

        print("Read in the data ===================")
        df <- read.csv(file='r_data.csv')
        print("Run the Model ======================")
        m <- glm('{}~.', data=df, family=tweedie(var.power={}, link.power=0))
        print("Summary ============================")
        summary(m)
        print("Newey-West Robust Errors ===========")
        coeftest(m, vcov=NeweyWest(m, lag=12, prewhite=F))
        '''.format(y_name, power)

    with open(cwd+path+'/r_code_{}.r'.format(segment), 'w') as f:
        f.write(script)

    return data, script

def rlm_mm_sas_code(mcf, meta_data, all_exog, endog, fileName = "rlm_mm_code.sas"):
    '''Function for writing RLM MM to SAS MM.'''
    params = ["b{}".format(i+1) for i in range(len(all_exog))]
    all_exog = list(map( lambda x: "'{}'n".format(x), all_exog))
    all_exog_lc = ' + '.join(map( lambda x: x[0] + '*' + x[1], zip(params, all_exog)))
    all_exog = " ".join(all_exog)
    with open(fileName, 'w') as f:
        f.write("/*\n")
        f.write("variable descriptions\n")
        for column in mcf.columns:
            f.write(column +" => " + meta_data[column]["description"] + "\n")
        f.write("*/")
        sas_string = """
/* if this is for balances, please take first difference of y variable
   before executing code, if not already completed:
   data data_import;
   set balance_model_dataset;
    'd_{}'n = dif('{}'n);
    run;
*/
proc robustreg data=sasout method=mm(K0=1.548 EFF=0.95);
    model '{}'n = {};
run;""".format(endog, endog, endog, all_exog)
        f.write(sas_string)


def rlm_sas_code(mcf, meta_data, all_exog, endog, fileName = "rlm_code.sas"):
    '''Function for writing RLM to SAS.'''
    params = ["b{}".format(i+1) for i in range(len(all_exog))]
    all_exog = list(map( lambda x: "'{}'n".format(x), all_exog))
    all_exog_lc = ' + '.join(map( lambda x: x[0] + '*' + x[1], zip(params, all_exog)))
    all_exog = " ".join(all_exog)
    with open(fileName, 'w') as f:
        f.write("/*\n")
        f.write("variable descriptions\n")
        for column in mcf.columns:
            f.write(column +" => " + meta_data[column]["description"] + "\n")
        f.write("*/")
        sas_string = """
/* if this is for balances, please take first difference of y variable
   before executing code, i.e.,
data data_import;
    set balance_model_dataset;
    'd_{}'n = dif('{}'n);
run;
*/
proc robustreg data=data_import method=m(wf=huber);
    model '{}'n = {};
run;""".format(endog, endog, endog, all_exog)
        f.write(sas_string)


def autoreg_sas_code(mcf, all_exog, macro_exog, fileName = "balance_code.sas", ar=0, special_notes=""):
    params = ["b{}".format(i+1) for i in range(len(all_exog))]
    all_exog = list(map( lambda x: "'{}'n".format(x), all_exog))
    macro_exog = list(map( lambda x: "'{}'n".format(x), macro_exog))
    all_exog_lc = ' + '.join(map( lambda x: x[0] + '*' + x[1], zip(params, all_exog)))
    all_exog = " ".join(all_exog)
    macro_exog = " ".join(macro_exog)
    ar_struct = "" if ar == 0 else "nlag = {}".format(ar)
    with open(fileName, 'w') as f:
        f.write("/* variable descriptions\n")
        f.write("   =====================\n")
        for column in mcf.columns:
            f.write(column +" => " + mcf.meta_data[column]["description"] + "\n")
        f.write("   =====================\n")
        f.write("*/")
        sas_string = """
%macro showODStable(table=);
	ods select &table;
	ods trace on;
	ods show;
	ods trace off;
%mend;
/* {} */
data balance_model_dataset;
    set balance_model_dataset;
    d_ln_balance = dif('ln Balance'n);
run;
proc autoreg data=balance_model_dataset;
    model d_ln_balance = {} / method = yw godfrey = 10 normal {};
    output out=predicted constant = constant transform=d_ln_balance {} ;
    /* tranform whitens data */
run;
/* ============ sas breusch pagan vs python breusch pagan =============
   sas bp WILL NOT match python bp when testing to see if serial
   correlation is still present in the "corrected" model.  Haven't
   tracked down the reason exaclty, but in Python, we run breusch
   pagan on the auxilary regression (e.g., whitened endog and exog)
   ====================================================================
*/
/* ============ sas white test vs python white test =============
   sas white test WILL NOT match python white test
   python sources the heteroskedasticity to macro
   indicators only.  This doesn't seem possible in SAS
   ==============================================================
*/
proc model data = predicted;
    d_ln_balance = a*constant + {};
    fit d_ln_balance / white breusch=(1 {}) normal hccme=3;
	%showODStable(table=HeteroTest );
run;""".format(special_notes,all_exog, ar_struct, all_exog, all_exog_lc, macro_exog)
        f.write(sas_string)


def genmod_sas_code(mcf, endog, all_exog, macro_exog, offset = None, fileName = "balance_code.sas", dist="negbin"):
    params = ["b{}".format(i+1) for i in range(len(all_exog))]
    all_exog = list(map( lambda x: "'{}'n".format(x), all_exog))
    macro_exog = list(map( lambda x: "'{}'n".format(x), macro_exog))
    all_exog_lc = ' + '.join(map( lambda x: x[0] + '*' + x[1], zip(params, all_exog)))
    all_exog = " ".join(all_exog)
    macro_exog = " ".join(macro_exog)
    with open(fileName, 'w') as f:
        f.write("/* variable descriptions\n")
        f.write("   =====================\n")
        for column in mcf.columns:
            f.write(column +" => " + mcf.meta_data[column]["description"] + "\n")
        f.write("   =====================\n")
        f.write("*/")
        offset = 1 if offset is None else offset
        sas_string_offset = """
data data_import;
    set data_import;
    ln_offset = log('{}'n);
run;
proc genmod data=data_import;
    model {} = {} / dist={} offset = ln_offset type1;
run;""".format(offset, endog, all_exog, dist)
        sas_string = """
proc genmod data=data_import;
    model {} = {} / dist={} type1;
run;""".format(endog, all_exog, dist)
        f.write(sas_string if offset == 1 else sas_string_offset)


'''
UNIT TEST ====================================================================
'''
def sas_out_test():
    '''sas out test'''
    from fnb_data import MetaFrame
    from sklearn.datasets import make_regression
    X, y = make_regression(n_samples=100, n_features=3, n_informative=1, n_targets=1, bias=0.25)
    X = pd.DataFrame(X, columns=[f'x{i+1}' for i in range(X.shape[1]) ])
    meta = []
    for item in X.columns:
        meta.append((f"{item}", {"description":f"variable info for {item}"}))
    meta = dict(meta)
    X = MetaFrame(X, meta_data = meta)
    y = pd.Series(y)
    y.name = "target"
    python_to_output.rlm_sas_code(X, X, y.name, 'sas_out_test.sas')
    return True
