from setuptools import find_packages, setup

setup(
    name='pyfnb',
    packages=find_packages(),
    version='0.2.0',
    description='fnb python base code',
    author='fnb data science',
    license=''
)
