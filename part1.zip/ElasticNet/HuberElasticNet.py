
## working through a python implementation of the huber elastic net by TW

import numpy as np
import numpy.random as npr
import numpy.matlib as npm
import pandas as pd
import matplotlib.pyplot as plt
import os

import scipy as sp
from scipy.stats import norm
# from ElasticNet_v2 import ElasticNetBase
from fnbbase.models.ElasticNet_v2 import ElasticNetBase

class HuberRegressor(ElasticNetBase):

    def __init__(self, alpha=1.0, depth=20, scale=None, center=None,
                 tol=1e-4, manual_lamseq=None, scaled_lambda=False):
        self.alpha = alpha
        self.depth = depth
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.lscaled = scaled_lambda
        super().__init__()

        if scale is None:
            self.scale = norm.ppf(3/4) ##inverse cdf of gaussian at 0.75
        else:
            self.scale = scale
        if center is None:
            self.center = 0
        else:
            self.center = center

    def array_safety(self, X, y, offset):
        '''confirms that y has 2 dimensions'''
        if y.ndim <= 1:
            y = y.reshape(-1,1)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        offset = self.offset_check(offset, y)
        offset = np.reshape(offset, (my*ny,1), order='F')

        if ny > 1: self.multivariate_model = True
        X = npm.repmat(X, ny, 1)
        y = np.reshape(y, (my*ny,1), order='F')
        assert len(offset) == len(y), "Length of Offset != Length of y"
        return X, y, offset

    def huber_weight_function(self, r):
        mad = np.median(np.abs(r-self.center)/self.scale)
        resid = np.where(np.abs(r/mad) < 1.345, 1, 1.345/np.abs(r/mad))
        return resid

    def score(self, X, y, offset=1, sample_weight=None):
        '''Added for inheritance from sklearn.'''
        from sklearn.metrics import r2_score
        y_pred = self.predict(X)
        return r2_score(y, y_pred, sample_weight=sample_weight)

    def calc_mu(self, X, b0, b, link='identity'):
        mu = b0 + X.dot(b)
        if link == 'log':
            mu = np.exp(mu)
            return mu
        else:
            return mu

    def huber_cost(self, X, y, b0, b, weight, lam, alpha):
        '''Huber Cost Function'''
        yhat = b0 + X.dot(b)
        err = y - yhat
        werr = weight.reshape(-1,1) * err
        l1 = alpha*np.linalg.norm(b.flatten(),1)
        l2 = (1-alpha)*np.linalg.norm(b.flatten(),2)
        cf = werr.T.dot(err)/(2.0*len(err)) + lam*(l1+l2)
        return cf

    def lam_seq_generator_huber(self, X, y, offset=1, alpha=1, nlen=100, scaled=False,
                                manual_lamseq=None):
        if manual_lamseq is None:
            m,n=np.shape(X)
            if scaled:
                 y = y/np.std(y)
            if m>n: lratio = 1e-4
            else:   lratio = 1e-2
            wX = self.huber_weight_function(y-np.mean(y))*X
            lmax = np.max(np.abs(np.dot(wX.T,y)))/m
            if alpha != 0: lmax = lmax/alpha
            else:          lmax = lmax/1e-2
            lmin = lratio*lmax
            llog = np.linspace(np.log(lmax), np.log(lmin), nlen)
            return np.exp(np.insert(llog,0,-10))
        else:
            manual_lamseq = np.array(manual_lamseq)
            if type(manual_lamseq) != np.ndarray and type(manual_lamseq) != list:
                raise Exception('** Manual lambdas must be a list or an numpy array and must be of length >= 2! **')
            assert len(manual_lamseq) >= 2, "** Length of Manual Lam Seq Must Be >= 2. **"
            return manual_lamseq.astype(float)

    def huber_cd(self, X, y, b0_init, b_init, lam, offset=1, k=1, alpha=1, nullDev=1, tol=1e-4):
        m,n = np.shape(X)
        npass, tol_chk = 0, 1
        b = np.zeros((n,1))
        w = self.huber_weight_function(y-np.mean(y))
        z = y.copy()
        wsum = np.sum(w)
        xsize= X.size
        cost = self.huber_cost(X, y, b0_init, b_init, w, lam, alpha)
        while tol_chk >= tol and npass<1000:
            npass+=1
            b0 = np.dot( w.T, np.subtract(z, np.dot(X,b))) / wsum
            if xsize != 0:
                for ii in range(0,n):
                    xi = X[:,[ii]]
                    wxi = w*X[:,[ii]]
                    b[ii] = np.dot(wxi.T, (np.subtract(z, np.dot(X,b)) - b0 + xi*b[ii]))/m
                    f = np.abs(b[ii]) - alpha*lam
                    st = np.sign(b[ii]) * (np.abs(f) + f)/2.0 ## SoftThreshHolding
                    b[ii] = np.divide(st , np.add( np.dot(xi.T, (wxi))/m , (1.0-alpha)*lam ))
            cost_update = self.huber_cost(X, y, b0, b, w, lam, alpha)
            ## beta convergence
            # tol_chk = np.linalg.norm(np.subtract(b0+b, b0_init+b_init))
            ## cost function convergence (same result as beta)
            tol_chk = np.abs(np.subtract(cost, cost_update))
            cost = cost_update.copy()
            b_init[:] = b[:]
            b0_init[:] = b0[:]

        return b0, b, npass

    def deviance(self, X, y, b0, b, offset=1, k=1):
        '''Gaussian Deviance Calculation'''
        m,n = np.shape(X)
        LL = np.subtract(y, X.dot(b) + b0)
        L = 0.5/len(y) * LL.T.dot(LL)
        return L

    def fit(self, X=None, y=None, offset=1):
        ''' fit call for the regression '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        b_init = np.zeros((nx,1))
        b0_init = np.mean(y,axis=0)
        k_init, it_dummy = 1e-5, 0
        dev = np.mean(self.deviance(X, y, b0_init, b_init, offset, k_init))

        nlen=100
        ylam = self.huber_weight_function(y-np.mean(y))
        lambdas = self.lam_seq_generator_huber(X,y,offset,self.alpha,nlen,self.lscaled,
                                               self.manual_lamseq)
        self.lambdas = lambdas
        if self.manual_lamseq is not None:
            self.depth = len(self.manual_lamseq) - 1 ## to reflect appropiate sequence

        outlier_check = self.huber_weight_function(y)
        self.outliers = (outlier_check != 1).astype(int)

        if np.isnan(b0_init).any() == True:
            raise Exception("The value of b0 is NAN. Confirm y is NOT standardized.")

        ##Storage Methods for Variables----------------------------------------
        minL = min(self.depth, 100)
        betas = np.zeros((nx, minL))
        beta0s = np.zeros((1, minL))
        ks = np.zeros((1, minL))
        yhats = np.zeros((minL, my))
        disp_iters = np.zeros((minL,1))
        mod_err = np.zeros((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = 1e-5, 0

            ## tried the r = y-yhat from Tims but that made it funky
            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.huber_cd(x_nzb, y, b0_init, b_nzb, lambda1, offset,
                                         k, self.alpha, dev/mx, self.tol)

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b[:]
            model_dev = self.deviance(X,y,b0_init,b_init,offset,k_init)
            r = (dev-model_dev)/dev ## these are scalars no need to numpy it
            if r > 0.9:  break
            yhat = b0_init + X.dot(b_init)

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)
        while beta_cnt_chk < 2 and min_errlm_idx < self.depth-1:
            self.min_errlm_idx_note = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            min_errlm_idx += 1
            beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)

        self.B = betas
        self.B0 = beta0s
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None):
        ''' Predict call for consistency with SKLEARN '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
        return b0 + X.dot(b)
