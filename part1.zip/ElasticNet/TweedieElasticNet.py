'''
WES.2020.09.11
'''

import numpy as np
import numpy.random as npr
import numpy.matlib as npm
from scipy.special import psi
from scipy.special import gammaln
from collections import namedtuple
import matplotlib.pyplot as plt
import pandas as pd
import warnings
import os
import dask
import operator
import scipy as sp
from scipy.stats import norm
from sklearn.base import RegressorMixin, BaseEstimator

'''
https://www.casact.org/education/annual/2009/handouts/c25-meyers.pdf
https://www.bing.com/search?q=tweedie+loss+function&cvid=d26ccb6904b5445c87fb867624e7e53f&FORM=ANNTA9&PC=U531
https://www.casact.org/community/affiliates/bace/0419/Loss_Cost_Modeling.pdf
https://towardsdatascience.com/tweedie-loss-function-for-right-skewed-data-2c5ca470678f
https://math.uoregon.edu/wp-content/uploads/2018/07/TempleStempleTweedieThesis.pdf
https://scikit-learn.org/stable/auto_examples/linear_model/plot_tweedie_regression_insurance_claims.html#sphx-glr-auto-examples-linear-model-plot-tweedie-regression-insurance-claims-py

'''

class ElasticNetBase(BaseEstimator, RegressorMixin):
    def __init__(self):
        ''' Initialization for ElasticNet Base '''
        self.in_enet = True

    def lam_seq_generator(self, X, y, w, offset=1, alpha=1, nlen=100, scaled=False,
                                manual_lamseq=None):
        ''' lambda sequence generator
            alpha : regularization parameter (default 1)
            nlen : total length of lambda vector (default 100)
            scaled : default False - True allows for re-scaling of X and y if
                the sequence is too large for regularization
            manual_lamseq : default None
        '''
        if manual_lamseq is None:
            m,n=np.shape(X)
            if scaled:
                 y = y/np.std(y)
            if m>n: lratio = 1e-4
            else:   lratio = 1e-2
            wX = w*X
            lmax = np.max(np.abs(np.dot(wX.T,y)))/m
            if alpha != 0: lmax = lmax/alpha
            else:          lmax = lmax/1e-2
            lmin = lratio*lmax
            llog = np.linspace(np.log(lmax), np.log(lmin), nlen)
            return np.exp(np.insert(llog,0,-10))
        else:
            manual_lamseq = np.array(manual_lamseq)
            if type(manual_lamseq) != np.ndarray and type(manual_lamseq) != list:
                raise Exception('** Manual lambdas must be a list or an numpy array and must be of length >= 2! **')
            assert len(manual_lamseq) >= 2, "** Length of Manual Lam Seq Must Be >= 2. **"
            return manual_lamseq.astype(float)

    def score(self, X, y, offset=1, sample_weight=None):
        '''Added for inheritance from sklearn.'''
        print("CALCULATES MEAN TWEEDIE DEVIANCE - SEE TWEEDIE SKLEARN")
        from sklearn.metrics import r2_score, mean_tweedie_deviance
        y_pred = self.predict(X)
        # return r2_score(y, y_pred, sample_weight=sample_weight)
        return mean_tweedie_deviance(y, y_pred, sample_weight=sample_weight)

    def array_safety(self, X, y, offset, weights):
        '''confirms that y has 2 dimensions'''
        if y.ndim <= 1:
            y = y.reshape(-1,1)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        offset = self.offset_check(offset, y)
        offset = np.reshape(offset, (my*ny,1), order='F')
        weights = self.offset_check(weights, y)
        weights = np.reshape(weights, (my*ny,1), order='F')

        if ny > 1: self.multivariate_model = True
        X = npm.repmat(X, ny, 1)
        y = np.reshape(y, (my*ny,1), order='F')
        assert len(offset) == len(y), "Length of Offset != Length of y"
        assert len(weights) == len(y), "Length of Weights != Length of y"
        return X, y, offset, weights

    def offset_check(self, offset, y):
        '''confirms offset size matches y'''
        if np.size(offset) == 1:
            if offset == 0:
                return np.ones(y.shape)
            else:
                return offset * np.ones(y.shape)
        else:
            return np.ones(y.shape)

    def corddesc(self, X, y, b0_init, b_init, p, lam, weights, offset=1, k=1, alpha=1,
                 nullDev=1, tol=1e-4, link='log'):
        ''' Coordinate descent algorithm based on beta convergence.  '''
        m,n = np.shape(X)
        npass, tol_chk = 0, 1
        b = np.zeros((n,1))

        # mu = np.exp(b0_init + np.add(X.dot(b_init), np.log(offset)))
        # ## https://www.casact.org/community/affiliates/bace/0419/Loss_Cost_Modeling.pdf
        # ## https://towardsdatascience.com/tweedie-loss-function-for-right-skewed-data-2c5ca470678f
        ## https://www.math.mcgill.ca/yyang/resources/papers/JCGS_HDtweedie.pdf ??
        # if p == 0:
        #     w = np.ones((len(y),1))
        #     z = y.copy()
        # else:
        mu = b0_init + np.add(X.dot(b_init), np.log(offset))
        r1 = weights*y*np.exp(-(p-1)*mu)
        r2 = weights*np.exp((2-p)*mu)
        w = (p-1)*r1 + (2-p)*r2 ## vtt
        z = mu + (r1-r2)/w   ## yt

        '''
        TO DO:
            fix the above to match:
            https://github.com/statsmodels/statsmodels/blob/master/statsmodels/genmod/families/family.py
        '''

        wsum = np.sum(w)
        xsize = X.size
        cost = self.tweedie_cost(X, y, b0_init, b_init, p, w, offset, link, lam, alpha)
        while tol_chk >= tol and npass<1000:
            npass+=1
            b0 = np.dot( w.T, np.subtract(z, np.dot(X,b))) / wsum
            if xsize != 0:
                for ii in range(0,n):
                    xi = X[:,[ii]]
                    b[ii] = np.dot(xi.T, ( w*(np.subtract(z, np.dot(X,b)) - b0 + xi*b[ii]) ) )/m
                    f = np.abs(b[ii]) - alpha*lam
                    st = np.sign(b[ii]) * (np.abs(f) + f)/2.0 ## SoftThreshHolding
                    b[ii] = np.divide(st , np.add( np.dot(xi.T, (w*xi))/m , (1.0-alpha)*lam ))

            # cost_update = self.tweedie_cost(X, y, b0_init, b_init, p, w, offset, link, lam, alpha)
            # tol_chk = np.abs(np.subtract(cost, cost_update))
            # cost = cost_update.copy()
            tol_chk = np.linalg.norm(np.subtract(b0+b, b0_init+b_init))
            b_init[:] = b[:]
            b0_init[:] = b0[:]

        return b0, b, npass

## ============================================================================
class TweedieRegressor(ElasticNetBase):
    ''' Tweedie Regressor '''
    def __init__(self, power=1.0, alpha=1.0, depth=20, link='log', tol=1e-4, manual_lamseq=None, scaled_lambda=False):
        '''
            This Tweedie Regressor is based on the Compound Tweedie Poisson work done in:
            https://www.math.mcgill.ca/yyang/resources/papers/JCGS_HDtweedie.pdf
            There are stability issues with powers < 1 and >= 2 so it is recommended to
            stay within those boundaries. It is also suggested to keep the weighting at 1
            unless for specific reasons.

            power : power for tweedie (1.0 = Poisson)
            alpha : regularization parameter (1.0 = Lasso)
            depth : early stopping depth for regularization (default=20)
            link  : the link function (default = 'log')
            tol   : tolerance for convergence
            manual_lamseq : passable sequence for manually generated lambdas
            scaled_lambda : scaling argument if lamba sequence is too large
        '''
        self.p = power
        self.alpha = alpha
        self.depth = depth
        self.link = link
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.lscaled = scaled_lambda
        super().__init__()

    def deviance(self, X, y, b0, b, p, offset=1, k=1, link='log'):
        '''Tweedie Deviance Calculation'''
        m,n = np.shape(X)
        mu = self.calc_mu(X,b0,b,offset=offset,link=link)
        if p==0:    ## normal dist
            # dev = ((y-mu)**2)/2
            dev = np.power(y-mu,2)/2
        elif p==1:  ## poisson dist
            dev = np.where(y==0, mu, y * np.log(y/mu) + (mu-y))
        elif p==2:  ## gamma dist
            dev = np.log(mu/y) + y/mu - 1
        else:
            # dev = (y**(2-p) / ((1-p) * (2-p)) - y*mu**(1-p)/(1-p) + mu**(2-p)/(2-p))
            dev1 = np.power(y,2-p) / ((1-p)*(2-p))
            dev2 = y*np.power(mu,1-p)/(1-p) + np.power(mu,2-p)/(2-p)
            dev = dev1 - dev2
        return 2*dev.T.dot(dev)

    def deviance_deriv(self, y, yhat, weights):
        '''calculates the deviance derivative'''
        return -2 * weights * (y - yhat) / self.variance(yhat)

    def cost(self, X, y, b0, b, weight, lam, alpha):
        '''Cost Function'''
        yhat = b0 + X.dot(b)
        err = y - yhat
        werr = weight.reshape(-1,1) * err
        l1 = alpha*np.linalg.norm(b.flatten(),1)
        l2 = (1-alpha)*np.linalg.norm(b.flatten(),2)
        cf = werr.T.dot(err)/(2.0*len(err)) + lam*(l1+l2)
        return cf

    def tweedie_cost(self, X, y, b0, b, p, weights, offset, link, lam, alpha):
        '''LogLikelihood Based Cost - Not Used'''
        ## https://www.math.mcgill.ca/yyang/resources/papers/JCGS_HDtweedie.pdf (eqn 4)
        ## https://github.com/cran/HDtweedie/blob/master/src/tweediegrpnet.f90
        mu = b0 + np.add(X.dot(b), np.log(offset))
        r1 = weights*y*np.exp(-(p-1)*mu)
        r2 = weights*np.exp((2-p)*mu)
        vtt = (p-1)*r1 + (2-p)*r2
        yt = mu + (r1-r2)/vtt
        return yt

    def calc_mu(self, X, b0, b, offset=1, link='log'):
        '''for calculating a prediction'''
        yhat = b0 + X.dot(b)
        if link == 'identity':
            return yhat
        elif link == 'log':
            return np.exp(yhat + np.log(offset))
        else:
            raise Exception('** This link not implmented! **')
            return 0

    def variance(self, y):
        '''calculates the variance'''
        return np.power(y, self.power)

    def fit(self, X=None, y=None, weights=None, offset=1):
        ''' Fit call for consistency with sklearn.
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        if weights is None:
            weights = 1/len(y) ##vt
        X, y, offset, weights = self.array_safety(X, np.array(y), offset, weights)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.weights = weights
        self.X = X
        self.y = y

        p = self.p
        if (p > 0) & (p < 1):
            warnings.warn(" ** Warning : Instabilities for powers < 1.0 and >= 2.0 ! ** ")

        b_init = np.zeros((nx,1))
        b0_init = np.log(np.mean(y/offset, axis=0))
        k_init, dummy = 1e-5, 0
        dev = self.deviance(X, y, b0_init, b_init, p, offset, k_init, self.link)

        nlen=100
        ylam = y - np.exp(b0_init + np.log(offset))
        lambdas = self.lam_seq_generator(X,ylam,offset,self.weights,self.alpha,nlen,self.lscaled,
                                         self.manual_lamseq)
        self.lambdas = lambdas
        if self.manual_lamseq is not None:
            self.depth = len(self.manual_lamseq) - 1 ## to reflect appropiate sequence

        ##Storage Methods for Variables----------------------------------------
        minL = min(self.depth, 100)
        betas = np.zeros((nx, minL))
        beta0s = np.zeros((1, minL))
        ks = np.zeros((1, minL))
        yhats = np.zeros((minL, my))
        disp_iters = np.zeros((minL,1))
        mod_err = np.zeros((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = 1e-5, 0

            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.corddesc(x_nzb, y, b0_init, b_nzb, p, lambda1, weights, offset,
                                         k, self.alpha, dev/mx, self.tol, self.link)

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b[:]
            model_dev = self.deviance(X,y,b0_init,b_init,p,offset,k_init,self.link)
            r = (dev-model_dev)/dev ## these are scalars no need to numpy it
            if r > 0.9:  break
            yhat = b0_init + X.dot(b_init)

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)
        while beta_cnt_chk < 2 and min_errlm_idx < self.depth-1:
            self.min_errlm_idx_note = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            min_errlm_idx += 1
            beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)

        self.B = betas
        self.B0 = beta0s
        self.offset = offset
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None, offset=1, link='log'):
        ''' Predict call for consistency with SKLEARN '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
            offset = self.offset
            link = self.link
        # yhat = self.tweedie_cost(X, y, b0, b, p, weights, offset, link, lam, alpha)
        return self.calc_mu(X,b0,b,offset=offset,link=link)

## ============================================================================
## ============================================================================
class TweedieCrossValidator(object):
    def __init__(self, model, cv_scheme=None):
        self.model = model
        self.cv_scheme = cv_scheme
        self.folds = cv_scheme.n_splits

    def offset_check(self, offset, y):
        '''confirms offset size matches y'''
        if np.size(offset) == 1:
            if offset == 0:
                return np.ones(y.shape)
            else:
                return offset * np.ones(y.shape)
        else:
            return np.ones(y.shape)

    def fit(self, X, y, weights=None, offset=1):
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        if weights is None:
            weights = 1/len(y) ##vt
        X, y, offset, weights = self.model.array_safety(X, np.array(y), offset, weights)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.weights = weights
        self.X = X
        self.y = y
        self.link = self.model.link
        self.p = self.model.p

        output = []
        for cv, (ti, vi) in enumerate(self.cv_scheme.split(X)): ## ti=trainidx, vi=validx
            res = dask.delayed(self.in_par)(self.model, ti, vi, X, y, offset)
            output.append((cv+1,res))
        results = dask.compute(*output)
        res_dict = sorted(dict(results).items(), key=operator.itemgetter(0))
        self.results_dict = res_dict
        # return res_dict

    def in_par(self, model, trn_idx, val_idx, X, y, offset):
        xtrn = X[trn_idx, :]
        ytrn = y[trn_idx]
        otrn = offset[trn_idx]
        xval = X[val_idx, :]
        yval = y[val_idx]
        oval = offset[val_idx]
        model.fit(xtrn, ytrn, self.weights)
        val_error = model.deviance(xval, yval, model.B0, model.B, self.p, oval, model.K, self.link)
        min_cv_error = np.where(val_error == np.nanmin(val_error))[0]
        return model.B, model.B0, model.K, min_cv_error, val_error

    def cv_data_agg(self, results=None):
        if results is None:
            results = self.results_dict
        folds = self.folds
        mx, nx = np.shape(self.X)
        depth = self.model.depth

        Bs = np.zeros((folds, nx, depth))
        B0s = np.zeros((folds, depth))
        Ks = np.zeros((folds, depth))
        mod_err = np.zeros((folds, depth))
        mindices = []

        for j in range(len(results)):
            Bs_res, B0s_res, Ks_res, min_ind_res, mod_err_res = results[j][1]
            Bs[j,:,:] = Bs_res
            B0s[j,:] = B0s_res
            Ks[j,:] = Ks_res
            max_mindx = np.max(min_ind_res)
            mindices.append(max_mindx)
            mod_err[j,:] = mod_err_res[max_mindx].flatten()
            # mod_err[j,:] = mod_err_res #.flatten()

        self.Bs = Bs
        self.B0s = B0s
        self.Ks = Ks
        self.mod_err = mod_err
        self.mindices = mindices

        return Bs, B0s, Ks, mod_err, mindices

    def coefficient_frequency(self, beta=None, min_cv_idx=None, param_names=None):
        if param_names is None:
            param_names = self.model.param_nm
        if beta is None:
            beta = self.Bs
        if min_cv_idx is None:
            min_cv_idx = self.mindices

        beta_list = []
        for i in range(beta.shape[0]):
            btemp = beta[i,:,:].reshape(beta.shape[1], beta.shape[2])
            bdf = pd.DataFrame(btemp[:,min_cv_idx[i]], index=param_names)
            bdf = bdf[np.abs(bdf.values) > 1e-4].reset_index()
            beta_list.append(bdf)

        beta_concat = pd.concat(beta_list).dropna()
        beta_concat.columns = ['variable','coefficient']
        beta_concat['value_sign'] = ['pos' if i >= 0 else 'neg' for i in beta_concat.coefficient ]
        mean_coefficients = beta_concat.groupby('variable')['coefficient'].mean()

        bc_freq = beta_concat.stb.freq(['variable','value_sign'])
        return bc_freq, mean_coefficients

# OTHER CODE ==================================================================

    # def weight_function(self, r):
    #     '''w = 1 / (g'(\mu)^2  * Var(\mu))'''
    #     # resid = r/r.sum()
    #     mu = self.calc_mu(r)
    #     resid = 1. / (self.deriv(mu)**2 * self.variance(mu))
    #     return resid
    #
    # def power_deriv(self, y):
    #     '''calculates power derivative'''
    #     if self.power == 1:
    #         return np.ones_like(y)
    #     else:
    #         return self.power * np.power(y, self.power - 1)
    #
    # def deriv(self, y, yhat):
    #     '''calculates derivate of y'''
    #     return -2 * (y - yhat) / self.variance(yhat)
    #
    # def loglik(self, X, y, b0, b, p, var_weights, scale, offset=1, k=1):
    #     '''Tweedie Log Likelihood'''
    #     llf = np.log(2*np.pi*scale) + p*np.log(mu) - np.log(var_weights)
    #     llf /= -2
    #
    #     if p==1:
    #         u = y*np.log(y/mu) - (y-mu)
    #         u *= var_weights / scale
    #     elif p==2:
    #         yr = y/mu
    #         u = yr - np.log(yr) - 1
    #         u *= var_weights/scale
    #     else:
    #         u = (y**(2-p) - (2-p)*y*mu**(1-p) + (1-p)*mu**(2-p))
    #         u *= var_weights / (scale * (1-p) * (2-p))
    #     llf -= u
    #     return llf

    # def disp_est(self, X, y, b0, b, offset=1, k=1):
    #     '''Dispersion Estimate for NegBinRegressor'''
    #     iters, k0 = 0, 0
    #     while np.abs(k-k0) > 1e-3:
    #         k0 = np.copy(k)
    #         k = k - 0.01/np.sqrt(len(X)+iters) * self.local_grad(X,y,b0,b,offset,k)
    #         iters += 1 ## this is mainly for error checking
    #         if k<0:
    #             k = 1e-6
    #             break
    #     return k, iters
    #
    # def local_grad(self, X, y, b0, b, offset=1, k=1):
    #     '''NegBinRegressor Gradient Calculation'''
    #     mu = np.exp(b0 + X.dot(b) + np.log(offset))
    #     g1 = psi(y+1/k)*(-1/k**2) + psi(1/k)*(1/k**2) + (1/k**2)*np.log(k) - (1/k**2)
    #     g2 =  (1/k**2)*np.log(1/k + mu) + (1/k**3)/(1/k + mu) + (y/(1/k + mu))*(1/k**2)
    #     return -np.sum(g1 + g2)
