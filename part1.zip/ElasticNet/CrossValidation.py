

import numpy as np
import numpy.random as npr
import numpy.matlib as npm
import pandas as pd
import sidetable
import matplotlib.pyplot as plt
import os
import dask
# from dask.distributed import Client
from multiprocessing.pool import ThreadPool
import operator
import scipy as sp
from scipy.stats import norm
# from ElasticNet_v2 import ElasticNetBase
from fnbbase.models.ElasticNet_v2 import ElasticNetBase

class CrossValidator(object):
    def __init__(self, model, cv_scheme=None, num_workers=3):
        self.model = model
        self.cv_scheme = cv_scheme
        self.folds = cv_scheme.n_splits
        self.num_workers = num_workers

    def offset_check(self, offset, y):
        '''confirms offset size matches y'''
        if np.size(offset) == 1:
            if offset == 0:
                return np.ones(y.shape)
            else:
                return offset * np.ones(y.shape)
        else:
            return np.ones(y.shape)

    def fit(self, X, y, offset=1):
        # dask.config.set(pool=ThreadPool(self.num_workers))
        # client = Client(n_workers=self.num_workers)
        if type(X) == pd.core.frame.DataFrame:
            self.model.param_names = X.columns
        else:
            self.model.param_names = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.model.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        output = []
        for cv, (ti, vi) in enumerate(self.cv_scheme.split(X)): ## ti=trainidx, vi=validx
            res = dask.delayed(self.in_par)(self.model, ti, vi, X, y, offset)
            output.append((cv+1,res))
        with dask.config.set(pool=ThreadPool(self.num_workers)):
            results = dask.compute(*output)
        res_dict = sorted(dict(results).items(), key=operator.itemgetter(0))
        self.results_dict = res_dict
        # return res_dict

    def in_par(self, model, trn_idx, val_idx, X, y, offset):
        xtrn = X[trn_idx, :]
        ytrn = y[trn_idx]
        otrn = offset[trn_idx]
        xval = X[val_idx, :]
        yval = y[val_idx]
        oval = offset[val_idx]
        model.fit(xtrn, ytrn)
        val_error = model.deviance(xval, yval, model.B0, model.B, oval, model.K)
        min_cv_error = np.where(val_error == np.nanmin(val_error))[0]
        return model.B, model.B0, model.K, min_cv_error, val_error

    def cv_data_agg(self, results=None):
        if results is None:
            results = self.results_dict
        p = self.folds
        mx, nx = np.shape(self.X)
        depth = self.model.depth

        Bs = np.zeros((p, nx, depth))
        B0s = np.zeros((p, depth))
        Ks = np.zeros((p, depth))
        mod_err = np.zeros((p, depth))
        mindices = []

        for j in range(len(results)):
            Bs_res, B0s_res, Ks_res, min_ind_res, mod_err_res = results[j][1]
            Bs[j,:,:] = Bs_res
            B0s[j,:] = B0s_res
            Ks[j,:] = Ks_res
            max_mindx = np.max(min_ind_res)
            mindices.append(max_mindx)
            mod_err[j,:] = mod_err_res[max_mindx].flatten()
            # mod_err[j,:] = mod_err_res #.flatten()

        self.Bs = Bs
        self.B0s = B0s
        self.Ks = Ks
        self.mod_err = mod_err
        self.mindices = mindices

        return Bs, B0s, Ks, mod_err, mindices

    def coefficient_frequency(self, beta=None, min_cv_idx=None, param_names=None):
        if param_names is None:
            param_names = self.model.param_names
        if beta is None:
            beta = self.Bs
        if min_cv_idx is None:
            min_cv_idx = self.mindices

        beta_list = []
        for i in range(beta.shape[0]):
            btemp = beta[i,:,:].reshape(beta.shape[1], beta.shape[2])
            bdf = pd.DataFrame(btemp[:,min_cv_idx[i]], index=param_names)
            bdf = bdf[np.abs(bdf.values) > 1e-4].reset_index()
            beta_list.append(bdf)

        beta_concat = pd.concat(beta_list).dropna()
        beta_concat.columns = ['variable','coefficient']
        beta_concat['value_sign'] = ['pos' if i >= 0 else 'neg' for i in beta_concat.coefficient ]
        mean_coefficients = beta_concat.groupby('variable')['coefficient'].mean()

        bc_freq = beta_concat.stb.freq(['variable','value_sign'])
        return bc_freq, mean_coefficients


## TIME SERIES CROSS VALIDATION ===============================================
from sklearn.model_selection import BaseCrossValidator
from sklearn.model_selection._split import _BaseKFold
from sklearn.utils.validation import _num_samples
from sklearn.utils import indexable

class FNBTimeSeriesSplit(_BaseKFold):
    def __init__(self, n_splits=5, test_size=4, max_train_size=None, gap=0):
        '''inherits from sklearn time series split but made for FNB style'''
        super().__init__(n_splits, shuffle=False, random_state=None)
        self.max_train_size = max_train_size ## unused but maintained for implementation
        self.test_size = test_size ## this is our n_ahead argument
        self.gap = gap ## unused but maintained for implementation
        self.shift = 1 ## non editible

    def split(self, X, y=None, groups=None):
        '''inherits'''
        X, y, groups = indexable(X, y, groups)
        n_samples = _num_samples(X)
        n_splits = self.n_splits ## old cvits (p)
        n_folds = n_splits + 1
        gap = self.gap
        shift = self.shift
        ## test_size is old "n_ahead"
        test_size = self.test_size if self.test_size is not None \
            else n_samples // n_folds

        # Make sure we have enough samples for the given split parameters
        if n_folds > n_samples:
            raise ValueError(
                (f"Cannot have number of folds={n_folds} greater"
                 f" than the number of samples={n_samples}."))
        if n_samples - gap - (test_size * n_splits) <= 0:
            raise ValueError(
                (f"Too many splits={n_splits} for number of samples"
                 f"={n_samples} with test_size={test_size} and gap={gap}."))

        indices = np.arange(n_samples)
        train_starts = np.arange(0, n_splits, shift)
        test_starts = np.arange(n_samples - n_splits*shift - test_size, n_samples, shift)

        for i, t in enumerate(train_starts):
            train = indices[train_starts[i]:test_starts[i]]
            test = indices[test_starts[i]:test_starts[i]+test_size+shift]
            yield (train, test)
            ## yield is slightly different than "return"
