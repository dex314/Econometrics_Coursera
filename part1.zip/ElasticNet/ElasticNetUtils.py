import numpy as np
import numpy.random as npr
import numpy.matlib as npm
from scipy.special import psi
from scipy.special import gammaln
from collections import namedtuple, Counter
import matplotlib.pyplot as plt
import pandas as pd
import dask
import operator


#%% PLOTTING FUNCTIONS=========================================================
#%% Plot Variable Paths and Error Over Cross Val===============================
def path_plot(Bs, B0s, figsize=(12,8)):
    ''' a function for plotting the Beta and Beta_0 paths
        _ = path_plot(model.B, model.B0, figsize)
    '''
    if len(Bs.shape) > 2:
        r_n = np.floor(len(Bs)/4)
        if r_n == 0 or r_n == 'inf':    r_n = 1;
        c_n = np.ceil(len(Bs)/r_n)
        if c_n == 0 or c_n == 'inf':    c_n = 1;

        if r_n>1 or c_n>1:
            fp, ax_p = plt.subplots(int(r_n), int(c_n), sharex=True, sharey=True, figsize=figsize)
            ax_p = ax_p.ravel()
            for i in range(len(Bs)):
                ax_p[i].plot(Bs[i][:,:].T)
                plt.suptitle('Lasso Parameters')

            fp0, ax_b0 = plt.subplots(int(r_n), int(c_n), sharex=True, sharey=True, figsize=figsize)
            ax_b0 = ax_b0.ravel()
            for i in range(len(B0s)):
                ax_b0[i].plot(B0s[i].T, 'go')
                plt.suptitle('Intercept Convergence')
    else:
        f1, ax_c = plt.subplots(1,2,figsize=figsize)
        ax_c = ax_c.ravel()
        ax_c[0].plot(Bs.T)
        ax_c[0].set_title('Betas')
        ax_c[1].plot(B0s.T, 'go')
        ax_c[1].set_title('Intercept')

#%% Nahead AND LAMS PLOT=======================================================
def err_plot(dev, figsize=(12,8)):
    ''' a function for plotting the deviance or error
        _ = err_plot(model.model_errors.T, figsize)
    '''
    f, axe = plt.subplots(1,2, sharex=False, sharey=False, figsize=figsize)
    axe = axe.ravel()
    ##Transposing Need??????
    for j in range(2):
        if j == 0:
            de = dev.T; xlabs='Lambda Depth'
        else:
            de = dev; xlabs='CV Depth'

        lc_mn = []; lc_std = [];
        for i in range(np.shape(de)[0]):
            lc_mn.append(np.mean(de[i,:], axis=0))
            lc_std.append(np.std(de[i,:], axis=0))

        yercv = [np.array(lc_std)[:], 2.0*np.array(lc_std)[:]]
        axe[j].errorbar(range(len(lc_mn)), np.array(lc_mn)[:], yerr=yercv, c='r',
                                                    marker='o', ms=4, mew=1.5, mec='k')
        axe[j].set_xlabel(str(xlabs))
    plt.suptitle('Cross Validation Deviance (Error)')

#%% NEW FIELD VOTE PLOT ======================================================
def field_vote_plot(Bs, min_ce_idx, param_name, min_indices=None, figsize=(12,8)):
    ''' New field vote plot.
        coefficient_dataframe = field_vote_plot(model.Bs, model.min_cvlam_idx, model.param_nm, cv.min_indices, figsize)
    '''
    var_counts = []
    var_vals = []
    if min_indices is not None: ##for cross val method
        cv_n, var_n, lam_n = Bs.shape
        for i in range(cv_n):
            minl = min_indices[i][0]
            midx_B = pd.DataFrame(Bs[i, :, minl].T, index=param_name, columns=['coef_val'])
            for c in list(midx_B[np.abs(midx_B.values) >= 1e-4].index.values):
                var_counts.append(c)
                var_vals.append([c,midx_B.loc[c][0]])
    else: ##single fit
        var_n, lam_n = Bs.shape
        midx_B = pd.DataFrame(Bs[:, min_ce_idx].T, index=param_name, columns=['coef_val'])
        for c in list(midx_B[np.abs(midx_B.values) >= 1e-4].index.values):
            var_counts.append(c)
            var_vals.append([c,midx_B.loc[c][0]])
    ## count up the instances over the cvs
    coef_c = []
    for key, ix in Counter(var_counts).items():
        coef_c.append([key,ix])
    ## change ot data frames for easy concatenation
    coef_cdf = pd.DataFrame(coef_c, columns=['var_name','count']).set_index('var_name')
    coef_vdf = pd.DataFrame(var_vals, columns=['var_name','var_val_mean']).set_index('var_name').groupby('var_name').mean()
    full = pd.concat([coef_cdf, coef_vdf], axis=1, join='outer')
    full = full.loc[(full!=0).any(axis=1)]
    full.columns = ['votes', 'vals']
    fulls = full.sort_values(by='votes',ascending=False)

    color2 = iter(plt.cm.rainbow(np.linspace(0,1,len(fulls))))
    f, axs = plt.subplots(1,2,sharey=True,figsize=figsize)
    axs = axs.ravel()
    for j in range(len(fulls)):
        col2 = next(color2)
        axs[0].barh(j,fulls.iloc[j,0], color=col2, align='center')
        axs[0].set_title('Field Votes'), axs[0].set_xlabel('Cross Vals')
        axs[1].barh(j,fulls.iloc[j,1], color=col2, align='center')
        axs[1].set_title('Variable Importance'), axs[1].set_xlabel('Beta Value')
        axs[1].axvline(0,color='black',linewidth=0.5)
    plt.yticks(np.arange(len(fulls.index)), fulls.index, fontsize=9)
    return full

def cv_graph(x, n_splits, test_size, figsize=(12,6), plot=True):
    ''' Function to plot the Cross Validation Scheme '''
    m = len(x)
    xidx = x.index
    df = pd.DataFrame(index = xidx)
    for i in range(n_splits):
        mpi = m - n_splits + i
        trn0 = int(i)
        trnF = int(mpi-test_size)
        val0 = int(mpi-test_size+1)
        valF = int(mpi)
        df['CV_{}'.format(i+1)] = 0
        df['CV_{}'.format(i+1)] = 1*((df.index>=xidx[trn0])&(df.index<=xidx[trnF])) + \
                -1*((df.index>=xidx[val0])&(df.index<=xidx[valF]))

    try:
        df.index = df.index.date
    except:
        df.index = df.index
    if plot == True:
        fig, ax=plt.subplots(1,1,figsize=figsize)
        sns.heatmap(df.T, cmap='coolwarm', linewidth=1, cbar=False, ax=ax, vmin=-1, vmax=1);
        ax.set_title("Cross Validation Graph", fontsize=16);
        ax.set_xlabel("Red = Train | Blue = Val | Gray = Unused", fontsize=16);
        plt.xticks(rotation=35);
    return df

## old version
# def cv_graph(x, cv_its, n_ahead, figsize=(12,6)):
#     ''' Function to plot the Cross Validation Scheme '''
#     m = len(x)
#     xidx = x.index
#     df = pd.DataFrame(index = xidx)
#     for i in range(cv_its):
#         mpi = m - cv_its + i
#         trn0 = int(i)
#         trnF = int(mpi-n_ahead)
#         val0 = int(mpi-n_ahead+1)
#         valF = int(mpi)
#         df['CV_{}'.format(i+1)] = 0
#         df['CV_{}'.format(i+1)] = 1*((df.index>=xidx[trn0])&(df.index<=xidx[trnF])) + \
#                 -1*((df.index>=xidx[val0])&(df.index<=xidx[valF]))
#
#     df.index = df.index.date
#     fig, ax=plt.subplots(1,1,figsize=figsize)
#     sns.heatmap(df.T, cmap='coolwarm', linewidth=1, cbar=False, ax=ax);
#     ax.set_title("Cross Validation Graph", fontsize=16);
#     ax.set_xlabel("Red = Train | Blue = Val | Gray = Unused", fontsize=16);
#     plt.xticks(rotation=35);
#     return df
