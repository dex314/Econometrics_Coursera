'''
WES.2020.10.15
'''

import numpy as np
import numpy.random as npr
import numpy.matlib as npm
from scipy.special import psi, gammaln, logit, factorial
from scipy.stats import norm
from collections import namedtuple
import matplotlib.pyplot as plt
import pandas as pd
import sidetable
import os
import dask
import operator

from sklearn.base import RegressorMixin, BaseEstimator

class ElasticNetBase(BaseEstimator, RegressorMixin):
    def __init__(self):
        ''' Initialization for ElasticNet Base '''
        self.in_enet = True

    def lam_seq_generator(self, X, y, offset=1, alpha=1, nlen=100, scaled=False, manual_lamseq=None):
        ''' lambda sequence generator
            alpha : regularization parameter (default 1)
            nlen : total length of lambda vector (default 100)
            scaled : default False - True allows for re-scaling of X and y if
                the sequence is too large for regularization
        '''
        if manual_lamseq is None:
            m,n=np.shape(X)
            if scaled:
                y = y/np.std(y)
            if m>n: lratio = 1e-4
            else:   lratio = 1e-2
            lmax = np.max(np.abs(np.dot(X.T,y)))/m
            if alpha != 0: lmax = lmax/alpha
            else:          lmax = lmax/1e-2
            lmin = lratio*lmax
            llog = np.linspace(np.log(lmax), np.log(lmin), nlen)
            return np.exp(np.insert(llog,0,-10))
        else:
            lams = np.array(manual_lamseq)
            if type(lams) != np.ndarray and type(lams) != list:
                raise Exception('** Manual lambdas must be a list or an numpy array and must be of length >= 2! **')
            assert len(lams) >= 2, "** Length of Manual Lam Seq Must Be >= 2. **"
            return lams.astype(float)

    def lam_seq_finalizer(self, lam_seq, X, y, offset, alpha, nlen, lscaled):
        '''Built to keep depth static'''
        if lam_seq is None:
            lams = self.lam_seq_generator(X,y,offset,alpha,nlen,lscaled)
            depth = len(lams)
        elif type(lam_seq) == int:
            depth = lam_seq
            lams = self.lam_seq_generator(X,y,offset,alpha,nlen,lscaled)
        else:
            lams = np.array(lam_seq)
            if type(lams) != np.ndarray and type(lams) != list:
                raise Exception('** Manual lambdas must be a list or an numpy array and must be of length >= 2! **')
            assert len(lams) >= 2, "** Length of Manual Lam Seq Must Be >= 2. **"
            depth = len(lams) - 1
        return lams, depth

    def score(self, X, y, offset=1, sample_weight=None):
        '''Added for inheritance from sklearn.'''
        from sklearn.metrics import r2_score
        y_pred = self.predict(X)
        return r2_score(y, y_pred, sample_weight=sample_weight)

    def disp_est(self, X, y, b0, b, offset=1, k=1):
        '''Dispersion Estimate for NegBinRegressor'''
        iters, k0 = 0, 0
        while np.abs(k-k0) > 1e-3:
            k0 = np.copy(k)
            k = k - 0.01/np.sqrt(len(X)+iters) * self.local_grad(X,y,b0,b,offset,k)
            iters += 1 ## this is mainly for error checking
            if k<0:
                k = 1e-6
                break
        return k, iters

    def local_grad(self, X, y, b0, b, offset=1, k=1):
        '''NegBinRegressor Gradient Calculation'''
        mu = np.exp(b0 + X.dot(b) + np.log(offset))
        g1 = psi(y+1/k)*(-1/k**2) + psi(1/k)*(1/k**2) + (1/k**2)*np.log(k) - (1/k**2)
        g2 =  (1/k**2)*np.log(1/k + mu) + (1/k**3)/(1/k + mu) + (y/(1/k + mu))*(1/k**2)
        return -np.sum(g1 + g2)

    def offset_check(self, offset, y):
        '''confirms offset size matches y'''
        if np.size(offset) == 1:
            if offset == 0:
                return np.ones(y.shape)
            else:
                return offset * np.ones(y.shape)
        else:
            return np.ones(y.shape)

    def array_safety(self, X, y, offset):
        '''confirms that y has 2 dimensions'''
        if y.ndim <= 1:
            y = y.reshape(-1,1)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        offset = self.offset_check(offset, y)
        offset = np.reshape(offset, (my*ny,1), order='F')

        if ny > 1: self.multivariate_model = True
        X = npm.repmat(X, ny, 1)
        y = np.reshape(y, (my*ny,1), order='F')
        assert len(offset) == len(y), "Length of Offset != Length of y"
        return X, y, offset

    def corddesc(self, X, y, b0_init, b_init, lam, weight=1, offset=1, k=1, alpha=1,
             nullDev=1, tol=1e-4, fam='Poisson'):
        ''' Coordinate descent algorithm based on beta convergence.
            Accesible to all but must call the respective Family.
        '''
        m,n = np.shape(X)
        npass, tol_chk = 0, 1
        b = np.zeros((n,1))

        if fam == 'Logistic':
            p = self.sigmoid(b0_init + np.dot(X,b_init))
            s = np.multiply( p, (1.0-p) )
            q0 =  np.divide( (y-p) , s )
            w = np.ones((len(y),1))*s
            z =  b0_init + np.add(X.dot(b_init), q0)
        if fam == 'Poisson':
            p = np.exp(b0_init + np.add(X.dot(b_init), np.log(offset)))
            q0 =  np.divide( (y-p) , p )
            w = np.ones((len(y),1))*p
            z =  b0_init + np.add(X.dot(b_init), q0)

        w = w*weight
        wsum = np.sum(w)
        xsize = X.size
        while tol_chk >= tol and npass<2000:
            npass+=1
            b0 = np.dot( w.T, np.subtract(z, np.dot(X,b))) / wsum
            if xsize != 0:
                for ii in range(0,n):
                    xi = X[:,[ii]]
                    b[ii] = np.dot(xi.T, ( w*(np.subtract(z, np.dot(X,b)) - b0 + xi*b[ii]) ) )/m
                    f = np.abs(b[ii]) - alpha*lam
                    st = np.sign(b[ii]) * (np.abs(f) + f)/2.0 ## SoftThreshHolding
                    b[ii] = np.divide(st , np.add( np.dot(xi.T, (w*xi))/m , (1.0-alpha)*lam ))
            tol_chk = np.linalg.norm(np.subtract(b0+b, b0_init+b_init))
            b_init[:] = b[:]
            b0_init[:] = b0[:]

        return b0, b, npass

## ============================================================================
class ZeroInflatedPoissonRegressor(ElasticNetBase):
    ''' ZeroInflatedPoissonRegressor '''
    def __init__(self, alpha=1.0, infl_depth=20, poisson_depth=20,
                 manual_infl_lambda_sequence=None,
                 manual_poisson_lambda_sequence=None,
                 tol=1e-4, scaled_lambda=False):
        '''
            IT IS HIGHLY RECOMMENDED THAT YOU STANDARDIZE YOUR INDEPENDENT
            VARIABLES PRIOR TO RUNNING THIS MODEL AS ERRORS SUCH AS
            OVERFLOW WARNINGS MAY OCCUR FROM THE EXPOENTIAL PORTIONS OF
            THE MODEL RELATIVE TO THE LAMBDA THRESHOLDS!!!

            alpha : regularization parameter (1.0 = Lasso)
            infl_depth : lambda depth for inflation coefficients (Logistic)
            poisson_depth : lambda depth for poisson coefficients
            infl_lambda_sequence : inflation based coefficients
                pre determined lambda sequence OR
                int for depth OR
                None for full depth
            poisson_lambda_sequence : parameter coefficients
                pre determined lambda sequence OR
                int for depth OR
                None for full depth
            tol   : tolerance for convergence
            manual_lamseq : passable sequence for manually generated lambdas
            scaled_lambda : scaling argument if lamba sequence is too large
        '''
        self.alpha = alpha
        self.infl_depth = infl_depth
        self.poisson_depth = poisson_depth
        self.manual_infl_lambda_sequence = manual_infl_lambda_sequence
        self.manual_poisson_lambda_sequence = manual_poisson_lambda_sequence
        self.tol = tol
        self.lscaled = scaled_lambda
        super().__init__()

    def sigmoid(self,z):
        ''' sigmoid function 1/(1+exp(-z)) for logistic reg'''
        return 1.0/(1.0+np.exp(-z))

    def deviance_infl(self, X, y, b0, b, offset=1, k=1):
        '''Logistic Deviance Calculation'''
        m,n = np.shape(X)
        mu = self.sigmoid(b0 + X.dot(b))
        LL = np.add(np.where(y>0, y*np.log(mu), 0), np.where(y<1, (1.0-y)*np.log(1.0-mu), 0))
        L = -2.0*np.sum(LL, axis=0)
        return L

    def deviance_poisson(self, X, y, b0, b, offset=1, k=1):
        '''Poisson Deviance Calculation'''
        m,n = np.shape(X)
        mu = np.exp(b0 + X.dot(b) + np.log(offset))
        LL = y*mu - gammaln(y+1)
        L = -2.0*np.sum(LL, axis=0)
        return L

    def deviance_zip(self, X, y, b0, b, g0, g, offset=1, k=1):
        '''ZIP Deviance Calculation'''
        m,n = np.shape(X)
        gg = self.sigmoid(g0 + X.dot(g))
        bb = np.exp(b0 + X.dot(b) + np.log(offset))
        l1 = -np.log(1-gg) + np.exp(bb) - y*bb + np.log(factorial(y))
        l2 = -np.log(gg + np.exp(-np.where(y==0,l1,0)))
        L = -2.0*l2.sum()
        return L

    def fit(self, X=None, y=None, offset=1):
        ''' Fit call for consistency with sklearn
            offset = 1 is not used for Gaussian or Logistic.
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        '''
        in matlab, here is a y==0 example
        y = [2 1 0 1 2 0 1 0 1]
        y == 0 -> [0 0 1 0 0 1 0 1 0]
        mean(y==0) = sum(y==0)/len(y) = 3/9 = 1/3
        '''

        b_init = np.zeros((nx,1))
        b0_init = np.mean(y,axis=0)
        k_init, it_dummy = 1e-5, 0
        # dev = np.mean(self.deviance(X, y, b0_init, b_init, offset, k_init))

        nlen=100
        ## everything with z is referring to the logit portion (l is confusing)
        ## inflation lambdas ==================================================
        ylamz = np.where(y==0,1,0)
        infl_lams = self.lam_seq_generator(X, ylamz, offset, self.alpha, nlen, self.lscaled,
                                            self.manual_infl_lambda_sequence)
        self.infl_lams = infl_lams
        if self.manual_infl_lambda_sequence is not None:
            infl_depth = min(self.infl_depth, len(self.manual_infl_lambda_sequence) - 1)
        else:
            infl_depth = self.infl_depth
        ## coefficient lambdas ================================================
        ylamp = y - b0_init
        poisson_lams = self.lam_seq_generator(X, ylamp, offset, self.alpha, nlen, self.lscaled,
                                              self.manual_poisson_lambda_sequence)
        self.poisson_lams = poisson_lams
        if self.manual_poisson_lambda_sequence is not None:
            poisson_depth = min(self.poisson_depth, len(self.manual_poisson_lambda_sequence) - 1)
        else:
            poisson_depth = self.poisson_depth

        ## calculate intitial predictions
        lhat = np.mean(y) * np.ones((my,ny))
        phat = np.mean(y==0) * np.ones((my,ny))
        zhat = phat / (phat + (1-phat) * np.exp(-lhat))
        zhat = np.array([0 if y[i]>0 else zhat[i][0] for i in range(len(zhat))]).reshape(-1,1)
        ## calculate intitial deviance
        pdev = self.deviance_poisson(X, y, np.log(np.mean(y)), np.zeros((nx,1)))
        zdev = self.deviance_infl(X, zhat, self.sigmoid(np.mean(zhat)), np.zeros((nx,1)))

        ##Storage Methods for Variables----------------------------------------
        betas = np.zeros((nx, poisson_depth, infl_depth))
        gammas = np.zeros((nx, poisson_depth, infl_depth))
        beta0s = np.zeros((1, poisson_depth, infl_depth))
        gamma0s = np.zeros((1, poisson_depth, infl_depth))
        yhats = np.zeros((my, poisson_depth, infl_depth))
        model_errs = np.zeros((poisson_depth, infl_depth))
        ## itnitialize empty parameters
        b, b0 = np.zeros((nx,1)), np.zeros((1))
        g, g0 = np.zeros((nx,1)), np.zeros((1))
        zip_dev = self.deviance_zip(X,y,b0,b,g0,g)

        ## the beta loop ======================================================
        for jj in range(self.poisson_depth):
            p0 = poisson_lams[jj]
            p1 = poisson_lams[jj+1]

            g0 = np.zeros((1)) ## do we need to set it above still?
            phat = np.mean(y==0)
            zh = phat / (phat + (1-phat)*np.exp(-np.mean(y)))
            zhat = np.where(y>0,0,zh)

            b_old = b[:]
            g_old = g[:]
            b = np.zeros((nx,1))
            g = np.zeros((nx,1))
        ## the gamma loop =====================================================
            for kk in range(self.infl_depth):
                z0 = infl_lams[kk]
                z1 = infl_lams[kk+1]

                nzb, jdum = np.nonzero(np.abs(X.T.dot(y)/mx) > self.alpha*(2*p1-p0))
                nzg, kdum = np.nonzero(np.abs(X.T.dot(zhat)/mx) > self.alpha*(2*z1-z0))

                b0_old = np.random.randn(1,1)
                g0_old = np.random.randn(1,1)
                el_paso = 0
                tol_chk_beta = np.linalg.norm(np.subtract(b0_old+b_old, b0+b))
                tol_chk_gamma = np.linalg.norm(np.subtract(g0_old+g_old, g0+g))
                while (tol_chk_beta+tol_chk_gamma) > 1e-8 and el_paso < 2000:
                    b0_old, b_old = b0[:], b[:]
                    g0_old, g_old = g0[:], g[:]

                    b0, b[nzb], beta_pass = self.corddesc(X[:,nzb], y, b0, b[nzb], p0, weight=1-zhat,
                                                          alpha=self.alpha, offset=offset,
                                                          nullDev=pdev/mx, tol=self.tol, fam='Poisson')

                    lhat = np.exp(b0+X.dot(b))
                    zh = phat / (phat + (1-phat)*np.exp(-lhat))
                    zhat = np.where(y>0,0,zh)

                    g0, g[nzg], gamma_pass = self.corddesc(X[:,nzg], zhat, g0, g[nzg], z0, weight=1,
                                                           alpha=self.alpha, offset=offset,
                                                           nullDev=zdev/mx, tol=self.tol, fam='Logistic')

                    phat = self.sigmoid(g0 + X[:,nzg].dot(g[nzg]))
                    zh = phat / (phat+(1-phat)*np.exp(-lhat))
                    zhat = np.where(y>0,0,zh)

                    tol_chk_beta = np.linalg.norm(np.subtract(b0_old+b_old, b0+b))
                    tol_chk_gamma = np.linalg.norm(np.subtract(g0_old+g_old, g0+g))
                    el_paso+=1

                mod_err = self.deviance_zip(X,y,b0,b,g0,g,offset)
                r = (zip_dev - mod_err)/zip_dev
                if r>0.9: print("r > 0.9 --> ", r); break
                yhat = (1-self.sigmoid(g0 + X.dot(g)))*np.exp(b0 + X.dot(b) + np.log(offset))

                betas[:,jj,kk] = b.ravel()
                gammas[:,jj,kk] = g.ravel()
                beta0s[:,jj,kk] = b0
                gamma0s[:,jj,kk] = g0
                yhats[:,jj,kk] = yhat.ravel()
                model_errs[jj,kk] = mod_err

        rowmi, colmi = np.where(model_errs == np.nanmin(model_errs))
        rowm, colm = rowmi[0], colmi[0]
        beta_cnt_chk = np.sum(betas[:, rowm, :] != 0)
        gamma_cnt_chk = np.sum(gammas[:, :, colm] != 0)
        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        while (beta_cnt_chk < 2) and (rowm < self.poisson_depth-1):
            self.min_errlm_idx_note_beta = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            rowm += 1
            beta_cnt_chk = np.sum(betas[:,rowm,:]!=0)
        while (gamma_cnt_chk < 2) and (colm < self.infl_depth-1):
            self.min_errlm_idx_note_gamma = 'Min lambda error had no Gammas - moving forward until there are at least 2.'
            colm += 1
            gamma_cnt_chk = np.sum(gammas[:,:,colm]!=0)

        self.B = betas
        self.B0 = beta0s
        self.Inflation = gammas
        self.Inflation0 = gamma0s
        self.offset = offset
        self.min_lam_idx = (rowm, colm)
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None, offset=1):
        ''' Predict call for consistency with SKLEARN '''
        b0 = self.B0[:,-1,-1]
        b = self.B[:,-1,-1].reshape(-1,1)
        g0 = self.Inflation0[:,-1,-1]
        g = self.Inflation[:,-1,-1].reshape(-1,1)
        if X is None:
            X = self.X
            offset = self.offset
        return (1-self.sigmoid(g0 + X.dot(g)))*np.exp(b0 + X.dot(b) + np.log(offset))

## ============================================================================
class CrossValidatorZIP(object):
    def __init__(self, model, cv_scheme=None, workers=None):
        self.model = model
        self.cv_scheme = cv_scheme
        self.folds = cv_scheme.n_splits
        ## https://docs.dask.org/en/latest/scheduler-overview.html
        if workers is None:
            self.workers = 3
        else:
            self.workers = workers

    def offset_check(self, offset, y):
        '''confirms offset size matches y'''
        if np.size(offset) == 1:
            if offset == 0:
                return np.ones(y.shape)
            else:
                return offset * np.ones(y.shape)
        else:
            return np.ones(y.shape)

    def validation_zipdev_single(self, X, y, b0, b, g0, g, offset=1):
        m,n = np.shape(X)
        ofr = offset.reshape(len(offset),1,1)
        yr = y.reshape(len(y),1,1)
        gg = self.model.sigmoid(g0 + np.tensordot(X,g,1))
        bb = np.exp(b0 + np.tensordot(X,b,1) + np.log(ofr))
        l1 = -np.log(1-gg) + np.exp(bb) - yr*bb + np.log(factorial(yr))
        l2 = -np.log(gg + np.exp(-np.where(yr==0,l1,0)))
        LL = -2*l2.sum()
        return LL

    def validation_zipdev(self, X, y, b0, b, g0, g, offset=1):
        plam = b.shape[1]
        zlam = b.shape[2]
        errs = np.zeros((plam,zlam))
        for i in range(plam):
            for j in range(zlam):
                b0r = b0[:,i,j]
                g0r = g0[:,i,j]
                br = b[:,i,j]
                gr = g[:,i,j]
                gg = np.array(self.model.sigmoid(g0r + X.dot(gr)),ndmin=2)
                bb = np.array(np.exp(b0r + X.dot(br) + np.log(offset)),ndmin=2)
                l1 = -np.log(1-gg) + np.exp(bb) - y*bb + np.log(factorial(y))
                l2 = -np.log(gg + np.exp(-np.where(y==0,l1,0)))
                errs[i,j] = -2*l2.sum()
        return errs

    def fit(self, X, y, offset=1):
        if type(X) == pd.core.frame.DataFrame:
            self.model.param_names = X.columns
        else:
            self.model.param_names = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.model.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        output = []
        for cv, (ti, vi) in enumerate(self.cv_scheme.split(X)): ## ti=trainidx, vi=validx
            res = dask.delayed(self.in_par)(self.model, ti, vi, X, y, offset)
            output.append((cv+1,res))
        results = dask.compute(*output, num_workers=self.workers)
        res_dict = sorted(dict(results).items(), key=operator.itemgetter(0))
        self.results_dict = res_dict
        # return res_dict

    def in_par(self, model, trn_idx, val_idx, X, y, offset):
        xtrn = X[trn_idx, :]
        ytrn = y[trn_idx]
        otrn = offset[trn_idx]
        xval = X[val_idx, :]
        yval = y[val_idx]
        oval = offset[val_idx]
        model.fit(xtrn, ytrn)
        val_error = self.validation_zipdev(xval, yval, model.B0, model.B,
                                            model.Inflation0, model.Inflation,
                                            oval)
        min_cv_error = np.where(val_error == np.nanmin(val_error))[0]
        return model.B, model.B0, model.Inflation, model.Inflation0, min_cv_error, val_error

    def cv_data_agg(self, results=None):
        if results is None:
            results = self.results_dict
        p = self.folds
        mx, nx = np.shape(self.X)
        infl_depth = self.model.infl_depth
        poisson_depth = self.model.poisson_depth

        Bs = np.zeros((p, nx, poisson_depth, infl_depth))
        B0s = np.zeros((p, poisson_depth, infl_depth))
        Infs = np.zeros((p, nx, poisson_depth, infl_depth))
        Inf0s = np.zeros((p, poisson_depth, infl_depth))
        mod_err = np.zeros((p, poisson_depth, infl_depth))
        mindices = []

        for j in range(len(results)):
            Bs_res, B0s_res, Inf_res, Inf0_res, min_ind_res, mod_err_res = results[j][1]
            Bs[j,:,:,:] = Bs_res
            B0s[j,:,:] = B0s_res
            Infs[j,:,:,:] = Inf_res
            Inf0s[j,:,:] = Inf0_res
            max_mindx = np.max(min_ind_res)
            mindices.append(max_mindx)
            mod_err[j,:,:] = mod_err_res[max_mindx].flatten()

        self.Bs = Bs
        self.B0s = B0s
        self.Inflation = Infs
        self.Inflation0 = Inf0s
        self.mod_err = mod_err
        self.mindices = mindices

        return Bs, B0s, Infs, Inf0s, mod_err, mindices

    def coefficient_frequency(self, beta=None, inflation=None, min_cv_idx=None, param_names=None):
        if param_names is None:
            param_names = self.model.param_names
        if beta is None:
            beta = self.Bs
        if inflation is None:
            inflation = self.Inflation
        if min_cv_idx is None:
            min_cv_idx = self.mindices

        beta_list = []
        for i in range(beta.shape[0]):
            btemp = beta[i,:,-1,:].reshape(beta.shape[1], beta.shape[2])
            bdf = pd.DataFrame(btemp[:,min_cv_idx[i]], index=param_names)
            bdf = bdf[np.abs(bdf.values) > 1e-4].reset_index()
            beta_list.append(bdf)

        beta_concat = pd.concat(beta_list).dropna()
        beta_concat.columns = ['variable','coefficient']
        beta_concat['value_sign'] = ['pos' if i >= 0 else 'neg' for i in beta_concat.coefficient ]
        bmean_coefficients = beta_concat.groupby('variable')['coefficient'].mean()

        inf_list = []
        for i in range(inflation.shape[0]):
            itemp = beta[i,:,:,-1].reshape(inflation.shape[1], inflation.shape[2])
            idf = pd.DataFrame(itemp[:,min_cv_idx[i]], index=param_names)
            idf = idf[np.abs(idf.values) > 1e-4].reset_index()
            inf_list.append(idf)

        inf_concat = pd.concat(inf_list).dropna()
        inf_concat.columns = ['variable','coefficient']
        inf_concat['value_sign'] = ['pos' if i >= 0 else 'neg' for i in inf_concat.coefficient ]
        imean_coefficients = inf_concat.groupby('variable')['coefficient'].mean()

        bc_freq = beta_concat.stb.freq(['variable','value_sign'])
        ic_freq = inf_concat.stb.freq(['variable','value_sign'])
        return bc_freq, ic_freq, bmean_coefficients, imean_coefficients

## USAGE FOR NOTEBOOKS ========================================================
import statsmodels.discrete as smd
class ZIP_FNB(smd.count_model.ZeroInflatedPoisson):
    def __init__(self, endog, exog, exog_infl, loglike_method='nb2', offset=None,
                 exposure=None, missing='none', addconst=True):
        self.endog = endog.copy()
        self.exog = exog.copy() if addconst==False else sma.add_constant(exog)
        self.exog_infl = exog_inf.copy() if addconst==False else sma.add_constant(exog_infl)
        self.inflation = 'logit'
        self.llm = loglike_method
        self.ofs = offset
        self.addconst = addconst

        super(ZIP_FNB, self).__init__(self.endog, self.exog, self.exog_infl,
                                      self.llm, self.ofs, inflation=self.inflation)

    def fit_ZIP_FNB(self, start_params=None, method='lbfgs', maxiter=1000,
                    full_output=1, disp=1, callback=None, cov_type='nonrobust',
                    cov_kwds=None, use_t=None):

        results = self.fit(start_params, method, maxiter, full_output, disp,
                           callback, cov_type, cov_kwds, use_t)

        results.endog = self.endog
        results.exog = self.exog
        results.exog_infl = self.exog_infl
        results.inflation = self.inflation
        results.expos = self.expos
        results.ofs = self.ofs

        return NEGBIN_RESULTS_FNB(results)

class ZIP_RESULTS_FNB:
    def __init__(self, results):
        self.results = results

    def predict(self, x):
        yhat = self.results.predict(x)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x.index)
        return yhat

    def forecast(self, x, start_date):
        x0 = x[x.index > start_date]
        yhat = self.results.predict(x0)
        yhat = pd.DataFrame(yhat, columns=['yhat'], index=x0.index)
        return yhat

    def zip_stats(self):
        y = self.results.endog
        pred = self.results.predict(self.results.exog, exog_infl=self.exog_infl, offset=self.results.ofs)
        k = self.results.params[-1]
        num = (np.asarray(y).T - np.asarray(pred))**2
        den = np.asarray(pred) + k*np.asarray(pred)**2
        chi2 = ( num/den ).sum()

        import scipy.stats as sps
        pval = " < 0.001" if sps.chi2.sf(chi2, int(self.results.nobs)) < 0.001 else "%.4f" % sps.chi2.sf(chi2, int(self.results.nobs))
        tss1_pvalue = " < 0.001" if self.results.llr_pvalue < 0.001 else "%.4f" % self.results.llr_pvalue
        ftest = self.results.f_test(self.results.params)
        if np.isnan(self.results.llnull) == True:
            print( "=============================================================\n")
            print( "Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (chi2, pval, self.results.df_resid))
            print( "=============================================================\n")
            print( "The Pearson Chi Square is defined as the square difference \n")
            print( "between the observed and the predicted, divided by the variance \n")
            print( "of the predicted, and summed over all observations in the model.  \n")
            tar = [[chi2, pval, self.results.df_resid]]
            idx = ["Pearson Chi Square Test for Independence"]
            tdf = pd.DataFrame(tar, index=idx, columns=['Value','P-Value','DoF'])
            return chi2, pval, ftest, tdf
        else:
            print( "=============================================================\n")
            print( "Type 1 - Sum of Squares (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (self.results.llr, tss1_pvalue, self.results.df_model))
            print( "=============================================================\n")
            print( "Pearson Chi Square Test for Independence (Value | P-Value | DoF): ( %3.3f | %s | %d)\n" % (chi2, pval, self.results.df_resid))
            print( "=============================================================\n")
            print( "The Pearson Chi Square is defined as the square difference \n")
            print( "between the observed and the predicted, divided by the variance \n")
            print( "of the predicted, and summed over all observations in the model.  \n")
            tar = [ [self.results.llr, tss1_pvalue, self.results.df_model], [chi2, pval, self.results.df_resid]]
            idx = ["Type 1 - Sum of Squares", "Pearson Chi Square Test for Independence"]
            tdf = pd.DataFrame(tar, index=idx, columns=['Value','P-Value','DoF'])
            return chi2, pval, ftest, tdf

    # def finalize_model(self, pdsegment, series, user, password, dbname = "treasury", host="pdbsgarc.myfnb.us", comments = "" ):
    #     """
    #     pdsegment: String = pdsegment for which you are loading a model.
    #     series: String = description of dependent variable being models
    #     user: String = user name for database
    #     password: String = password for database
    #     comments: String = comments concerning the loaded model
    #     """
    #     lm(pdsegment, series, self, user, password, dbname, host, comments)

## ============================================================================
def lambda_seq_generator(X, y, offset=1, alpha=1, nlen=100, scaled=False):
    ''' lambda sequence generator - outside of the class as a utility
        alpha : regularization parameter (default 1)
        nlen : total length of lambda vector (default 100)
        scaled : default False - True allows for re-scaling of X and y if
            the sequence is too large for regularization
    '''
    m,n=np.shape(X)
    if scaled:
        y = y/np.std(y)
    if m>n: lratio = 1e-4
    else:   lratio = 1e-2
    lmax = np.max(np.abs(np.dot(X.T,y)))/m
    if alpha != 0: lmax = lmax/alpha
    else:          lmax = lmax/1e-2
    lmin = lratio*lmax
    llog = np.linspace(np.log(lmax), np.log(lmin), nlen)
    return np.exp(np.insert(llog,0,-10))
