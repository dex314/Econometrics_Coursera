'''
WES.2020.09.11
'''

import numpy as np
import numpy.random as npr
import numpy.matlib as npm
from scipy.special import psi
from scipy.special import gammaln
from collections import namedtuple
import matplotlib.pyplot as plt
import pandas as pd

import xgboost as xgb

from sklearn.base import RegressorMixin, BaseEstimator

class ElasticNetBase(BaseEstimator, RegressorMixin):
    def __init__(self):
        ''' Initialization for ElasticNet Base '''
        self.in_enet = True

    def lam_seq_generator(self, X, y, offset=1, alpha=1, nlen=100, scaled=False,
                          manual_lamseq=None):
        ''' lambda sequence generator
            alpha : regularization parameter (default 1)
            nlen : total length of lambda vector (default 100)
            scaled : default False - True allows for re-scaling of X and y if
                the sequence is too large for regularization
            manual_lamseq : default None
        '''
        if manual_lamseq is None:
            m,n=np.shape(X)
            if scaled:
                y = y/np.std(y)
            if m>n: lratio = 1e-4
            else:   lratio = 1e-2
            lmax = np.max(np.abs(np.dot(X.T,y)))/m
            if alpha != 0: lmax = lmax/alpha
            else:          lmax = lmax/1e-2
            lmin = lratio*lmax
            llog = np.linspace(np.log(lmax), np.log(lmin), nlen)
            return np.exp(np.insert(llog,0,-10))
        else:
            manual_lamseq = np.array(manual_lamseq)
            if type(manual_lamseq) != np.ndarray and type(manual_lamseq) != list:
                raise Exception('** Manual lambdas must be a list or an numpy array and must be of length >= 2! **')
            assert len(manual_lamseq) >= 2, "** Length of Manual Lam Seq Must Be >= 2. **"
            return manual_lamseq.astype(float)

    def score(self, X, y, offset=1, sample_weight=None):
        '''Added for inheritance from sklearn.'''
        from sklearn.metrics import r2_score
        y_pred = self.predict(X)
        return r2_score(y, y_pred, sample_weight=sample_weight)

    def offset_check(self, offset, y):
        '''confirms offset size matches y'''
        if np.size(offset) == 1:
            if offset == 0:
                return np.ones(y.shape)
            else:
                return offset * np.ones(y.shape)
        else:
            return np.ones(y.shape)

    def array_safety(self, X, y, offset):
        '''confirms that y has 2 dimensions'''
        if y.ndim <= 1:
            y = y.reshape(-1,1)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        offset = self.offset_check(offset, y)
        offset = np.reshape(offset, (my*ny,1), order='F')

        if ny > 1: self.multivariate_model = True
        X = npm.repmat(X, ny, 1)
        y = np.reshape(y, (my*ny,1), order='F')
        assert len(offset) == len(y), "Length of Offset != Length of y"
        return X, y, offset

## ============================================================================
class GBRegressor(ElasticNetBase):
    ''' Gradient Boosting Regressor Using XGBoost '''
    def __init__(self, eta=0.1, feat_frac=1.0, row_frac=1.0, l1_ratio=1.0, num_round=100,
                 model_type='reg', top_n_features=20, feature_type='cover'):
        self.eta = eta
        self.feat_frac = feat_frac
        self.row_frac = row_frac
        self.l1_ratio = l1_ratio
        self.num_round = num_round
        self.model_type = model_type
        self. top_n_features = top_n_features
        self.feature_type = feature_type
        super().__init__()

    def deviance(self, X, y, b0, b, offset=1, k=1):
        '''Gaussian Deviance Calculation'''
        m,n = np.shape(X)
        LL = np.subtract(y, X.dot(b) + b0)
        L = 0.5/len(y) * LL.T.dot(LL)
        return np.diag(L)

    def fit(self, X=None, y=None, offset=1):
        ''' Fit call for consistency with sklearn
            offset = 1 is not used for Gaussian or Logistic.
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        b_init = np.zeros((nx,1))
        b0_init = np.mean(y,axis=0)
        k_init, it_dummy = 1e-5, 0
        dev = np.mean(self.deviance(X, y, b0_init, b_init, offset, k_init))

        nlen=100
        ylam = y - b0_init
        lambdas = self.lam_seq_generator(X,ylam,offset,self.alpha,nlen,self.lscaled,
                                         self.manual_lamseq)
        self.lambdas = lambdas
        if self.manual_lamseq is not None:
            self.depth = len(self.manual_lamseq) - 1 ## to reflect appropiate sequence

        ##Storage Methods for Variables----------------------------------------
        minL = min(self.depth, 100)
        betas = np.zeros((nx, minL))
        beta0s = np.zeros((1, minL))
        ks = np.zeros((1, minL))
        yhats = np.zeros((minL, my))
        disp_iters = np.zeros((minL,1))
        mod_err = np.zeros((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = 1e-5, 0

            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.corddesc(x_nzb, y, b0_init, b_nzb, lambda1, offset,
                                     k, self.alpha, dev/mx, self.tol, 'Gauss')

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b[:]
            model_dev = self.deviance(X,y,b0_init,b_init,offset,k_init)
            r = (dev-model_dev)/dev ## these are scalars no need to numpy it
            if r > 0.9:  break
            yhat = b0_init + X.dot(b_init)

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)
        while beta_cnt_chk < 2 and min_errlm_idx < self.depth-1:
            self.min_errlm_idx_note = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            min_errlm_idx += 1
            beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)

        self.B = betas
        self.B0 = beta0s
        self.offset = offset
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None):
        ''' Predict call for consistency with SKLEARN '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
        return b0 + X.dot(b)

## ============================================================================
class NegBinRegressor(ElasticNetBase):
    ''' NegBinRegressor '''
    def __init__(self, alpha=1.0, depth=20, tol=1e-4, manual_lamseq=None, scaled_lambda=False):
        ''' alpha : regularization parameter (1.0 = Lasso)
            depth : early stopping depth for regularization (default=20)
            tol   : tolerance for convergence
            manual_lamseq : passable sequence for manually generated lambdas
            scaled_lambda : scaling argument if lamba sequence is too large
        '''
        self.alpha = alpha
        self.depth = depth
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.lscaled = scaled_lambda
        super().__init__()

    def deviance(self, X, y, b0, b, offset=1, k=1):
        '''NegBin Deviance Calculation'''
        m,n = np.shape(X)
        mu = np.exp(b0 + X.dot(b) + np.log(offset))
        LL = gammaln(y + 1/k) - gammaln(1/k) - gammaln(y + 1) - \
             (y + 1/k)*np.log(1 + k*mu) + y*np.log(k) + y*np.log(mu)
        L = -2.0*np.sum(LL, axis=0)
        return L

    def fit(self, X=None, y=None, offset=1):
        ''' Fit call for consistency with sklearn
            offset = 1 is not used for Gaussian or Logistic.
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        b_init = np.zeros((nx,1))
        b0_init = np.log(np.mean(y/offset, axis=0))
        k_init, dummy = self.disp_est(X, y, b0_init, b_init, offset, 1)
        dev = self.deviance(X, y, b0_init, b_init, offset)

        nlen=100
        ylam = y - np.exp(b0_init + np.log(offset))
        lambdas = self.lam_seq_generator(X,ylam,offset,self.alpha,nlen,self.lscaled,
                                         self.manual_lamseq)
        self.lambdas = lambdas
        if self.manual_lamseq is not None:
            self.depth = len(self.manual_lamseq) - 1 ## to reflect appropiate sequence

        ##Storage Methods for Variables----------------------------------------
        minL = min(self.depth, 100)
        betas = np.zeros((nx, minL))
        beta0s = np.zeros((1, minL))
        ks = np.zeros((1, minL))
        yhats = np.zeros((minL, my))
        disp_iters = np.zeros((minL,1))
        mod_err = np.zeros((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = self.disp_est(X, y, b0_init, b_init, offset, k_init)

            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.corddesc(x_nzb, y, b0_init, b_nzb, lambda1, offset,
                                     k, self.alpha, dev/mx, self.tol, 'NegBin')

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b[:]
            model_dev = self.deviance(X,y,b0_init,b_init,offset,k_init)
            r = (dev-model_dev)/dev ## these are scalars no need to numpy it
            if r > 0.9:  break
            yhat = np.exp(b0_init + X.dot(b_init) + np.log(offset))

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev

            if k_init <= 1e-4:
                self.DispersionNote = "Dispersion reached < 1e-4, consider running a Poisson."

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)
        while beta_cnt_chk < 2 and min_errlm_idx < self.depth-1:
            self.min_errlm_idx_note = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            min_errlm_idx += 1
            beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)

        self.B = betas
        self.B0 = beta0s
        self.offset = offset
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None, offset=1):
        ''' Predict call for consistency with sklearn. Must consider offset!
        '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
            offset = self.offset
        return np.exp(b0 + X.dot(b) + np.log(offset))

## ============================================================================
class LogisticRegressor(ElasticNetBase):
    ''' LogisticRegressor '''
    def __init__(self, alpha=1.0, depth=20, tol=1e-4, manual_lamseq=None, scaled_lambda=False):
        ''' alpha : regularization parameter (1.0 = Lasso)
            depth : early stopping depth for regularization (default=20)
            tol   : tolerance for convergence
            manual_lamseq : passable sequence for manually generated lambdas
            scaled_lambda : scaling argument if lamba sequence is too large
        '''
        self.alpha = alpha
        self.depth = depth
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.lscaled = scaled_lambda
        super().__init__()

    def sigmoid(self,z):
        ''' sigmoid function 1/(1+exp(-z)) for logit '''
        return 1.0/(1.0+np.exp(-z))

    def deviance(self, X, y, b0, b, offset=1, k=1):
        '''Logistic Deviance Calculation'''
        m,n = np.shape(X)
        mu = self.sigmoid(b0 + X.dot(b))
        LL = np.add(np.where(y>0, y*np.log(mu), 0), np.where(y<1, (1.0-y)*np.log(1.0-mu), 0))
        L = -2.0*np.sum(LL, axis=0)
        return L

    def fit(self, X=None, y=None, offset=1):
        ''' Fit call for consistency with sklearn
            offset = 1 is not used for Gaussian or Logistic.
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        b_init = np.zeros((nx,1))
        p0 = np.mean(y,axis=0)
        b0_init = np.log(p0/(1-p0))
        k_init, dummy = 1e-5, 0
        dev = self.deviance(X, y, b0_init, b_init, offset)

        nlen=100
        ylam = y - self.sigmoid(b0_init)
        lambdas = self.lam_seq_generator(X,ylam,offset,self.alpha,nlen,self.lscaled,
                                         self.manual_lamseq)
        self.lambdas = lambdas
        if self.manual_lamseq is not None:
            self.depth = len(self.manual_lamseq) - 1 ## to reflect appropiate sequence

        ##Storage Methods for Variables----------------------------------------
        minL = min(self.depth, 100)
        betas = np.zeros((nx, minL))
        beta0s = np.zeros((1, minL))
        ks = np.zeros((1, minL))
        yhats = np.zeros((minL, my))
        disp_iters = np.zeros((minL,1))
        mod_err = np.zeros((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = self.disp_est(X, y, b0_init, b_init, offset, k_init)

            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.corddesc(x_nzb, y, b0_init, b_nzb, lambda1, offset,
                                     k, self.alpha, dev/mx, self.tol, 'Logistic')

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b[:]
            model_dev = self.deviance(X,y,b0_init,b_init,offset,k_init)
            r = (dev-model_dev)/dev ## these are scalars no need to numpy it
            if r > 0.9:  break
            yhat = self.sigmoid(b0_init + X.dot(b_init))

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev

            if k_init <= 1e-4:
                self.DispersionNote = "Dispersion reached < 1e-4, consider running a Poisson."

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)
        while beta_cnt_chk < 2 and min_errlm_idx < self.depth-1:
            self.min_errlm_idx_note = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            min_errlm_idx += 1
            beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)

        self.B = betas
        self.B0 = beta0s
        self.offset = offset
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None):
        ''' Predict call for consistency with sklearn. '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
        return self.sigmoid(b0 + X.dot(b))

## ============================================================================
class PoissonRegressor(ElasticNetBase):
    ''' PoissonRegressor '''
    def __init__(self, alpha=1.0, depth=20, tol=1e-4, manual_lamseq=None, scaled_lambda=False):
        ''' alpha : regularization parameter (1.0 = Lasso)
            depth : early stopping depth for regularization (default=20)
            tol   : tolerance for convergence
            manual_lamseq : passable sequence for manually generated lambdas
            scaled_lambda : scaling argument if lamba sequence is too large
        '''
        self.alpha = alpha
        self.depth = depth
        self.tol = tol
        self.manual_lamseq = manual_lamseq
        self.lscaled = scaled_lambda
        super().__init__()

    def deviance(self, X, y, b0, b, offset=1, k=1):
        '''Poisson Deviance Calculation'''
        m,n = np.shape(X)
        # if offset.all() == 1.0:
        #     mu = np.array(np.exp(b0 + X.dot(b) + np.log(offset)))
        #     L = -2.0*np.sum(y*mu - gammaln(y+1), axis=0)
        # else:
        #     mu = np.array(np.exp(b0 + X.dot(b)))
        #     L = -2.0*( (y/offset).T * mu.T * (1/offset) )
        mu = np.exp(b0 + X.dot(b) + np.log(offset))
        LL = y*mu - gammaln(y+1)
        L = -2.0*np.sum(LL, axis=0)
        return L

    def fit(self, X=None, y=None, offset=1):
        ''' Fit call for consistency with sklearn
            offset = 1 is not used for Gaussian or Logistic.
        '''
        if type(X) == pd.core.frame.DataFrame:
            self.param_nm = X.columns
        else:
            self.param_nm = list(str('X'+str(xn)) for xn in range(X.shape[1]))
        X = np.array(X)
        X, y, offset = self.array_safety(X, np.array(y), offset)
        mx,nx=np.shape(X)
        my,ny=np.shape(y)
        self.offset = offset
        self.X = X
        self.y = y

        b_init = np.zeros((nx,1))
        b0_init = np.log( np.mean(y/offset, axis=0))
        k_init, dummy = 1e-5, 0
        dev = self.deviance(X, y, b0_init, b_init, offset)

        nlen=100
        ylam = y - np.exp(b0_init + np.log(offset))
        lambdas = self.lam_seq_generator(X,ylam,offset,self.alpha,nlen,self.lscaled,
                                         self.manual_lamseq)
        self.lambdas = lambdas
        if self.manual_lamseq is not None:
            self.depth = len(self.manual_lamseq) - 1 ## to reflect appropiate sequence

        ##Storage Methods for Variables----------------------------------------
        minL = min(self.depth, 100)
        betas = np.zeros((nx, minL))
        beta0s = np.zeros((1, minL))
        ks = np.zeros((1, minL))
        yhats = np.zeros((minL, my))
        disp_iters = np.zeros((minL,1))
        mod_err = np.zeros((minL,1))

        for j in range(minL):
            lambda1 = lambdas[j+1]
            lambda0 = lambdas[j]
            k, disp_iter = self.disp_est(X, y, b0_init, b_init, offset, k_init)

            nzb, jdum = np.nonzero( np.abs(X.T.dot(y)/mx) > self.alpha*(2.0*lambda1 - lambda0) )
            x_nzb = np.array(X[:,nzb])
            b_nzb = np.array(b_init[nzb])
            b0, b, npass = self.corddesc(x_nzb, y, b0_init, b_nzb, lambda1, offset,
                                     k, self.alpha, dev/mx, self.tol, 'Poisson')

            b0_init = np.copy(b0)
            k_init = np.copy(k)
            b_init[nzb] = b[:]
            model_dev = self.deviance(X,y,b0_init,b_init,offset,k_init)
            r = (dev-model_dev)/dev ## these are scalars no need to numpy it
            if r > 0.9:  break
            yhat = np.exp(b0_init + X.dot(b_init) + np.log(offset))

            betas[:,j] = np.copy(b_init.ravel())
            beta0s[:,j] = np.copy(b0_init)
            ks[:,j] = np.copy(k_init)
            yhats[j,:] = yhat.ravel()
            disp_iters[j] = disp_iter
            mod_err[j] = model_dev

        ## MIN OUT OF SAMPLE ERROR PREDICTION - PICKING LOWEST LAMBDA
        min_errlm_idx = np.where(mod_err == np.nanmin(mod_err))[0][0]
        beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)
        while beta_cnt_chk < 2 and min_errlm_idx < self.depth-1:
            self.min_errlm_idx_note = 'Min lambda error had no Betas - moving forward until there are at least 2.'
            min_errlm_idx += 1
            beta_cnt_chk = np.sum(betas[:,min_errlm_idx]!=0)

        self.B = betas
        self.B0 = beta0s
        self.offset = offset
        self.min_lam_idx = min_errlm_idx
        self.K = ks
        self.disp_iter = disp_iters
        self.yhat = yhats
        self.model_errors = mod_err

    def predict(self, X=None, offset=1):
        ''' Predict call for consistency with sklearn. Must consider offset!
        '''
        b0 = self.B0[-1,-1]
        b = self.B[:,-1].reshape(-1,1)
        if X is None:
            X = self.X
            offset = self.offset
        return np.exp(b0 + X.dot(b) + np.log(offset))
